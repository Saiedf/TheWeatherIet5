# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function ensures print() works as function in Python 2.7
from __future__ import print_function, absolute_import

from . import _
from .plugin_utils import _ensure_text, _format_temperature_text, _tw_temp_suffix

import datetime
import time
from time import strftime, localtime


def _clamp_line_diff(value, limit=15):
    value = int(value)
    if value > limit:
        return limit
    if value < -limit:
        return -limit
    return value


def _get_temperature_diff(data_days, day_index, key, current_temp):
    if (day_index + 1) >= len(data_days):
        return 0
    next_temp = int(round(float(data_days[day_index + 1][key])))
    return _clamp_line_diff(next_temp - current_temp)


def _get_curve_dot_y(temp_value, base_height, scale_factor, maxheightshift):
    return (base_height - (int(round(temp_value)) * scale_factor)) + maxheightshift


def _apply_curve_gap(max_dot_y, min_dot_y, scale_factor, min_gap, bottom_limit=None):
    if bottom_limit is not None and min_dot_y > bottom_limit:
        min_dot_y = int(bottom_limit)
    current_gap = int(min_dot_y - max_dot_y)
    target_gap = int(min_gap)
    if bottom_limit is not None:
        available_gap = int(bottom_limit - max_dot_y)
        if available_gap < 0:
            available_gap = 0
        if target_gap > available_gap:
            target_gap = available_gap
    if current_gap >= target_gap:
        return int(min_dot_y)
    gap_shortage = int(target_gap - current_gap)
    step_adjustment = int((gap_shortage + scale_factor - 1) / scale_factor)
    if step_adjustment < 1:
        step_adjustment = 1
    adjusted_dot_y = int(min_dot_y + (step_adjustment * scale_factor))
    if bottom_limit is not None and adjusted_dot_y > bottom_limit:
        adjusted_dot_y = int(bottom_limit)
    return int(adjusted_dot_y)


def _get_curve_diff_from_dots(current_dot_y, next_dot_y, scale_factor):
    diff_steps = int(round(float(current_dot_y - next_dot_y) / float(scale_factor)))
    return _clamp_line_diff(diff_steps)


def _get_temperature_line_layout(data_days, day_index, base_height, scale_factor, maxheightshift, min_gap, bottom_limit=None, blue_offset=0):
    day_data = data_days[day_index]
    max_temp = int(round(float(day_data["maxtemperature"])))
    min_temp = int(round(float(day_data["mintemperature"])))
    max_dot_y = _get_curve_dot_y(max_temp, base_height, scale_factor, maxheightshift)
    min_dot_y = _get_curve_dot_y(min_temp, base_height, scale_factor, maxheightshift)
    min_dot_y = _apply_curve_gap(max_dot_y, min_dot_y, scale_factor, min_gap, bottom_limit)
    min_dot_y -= blue_offset

    if (day_index + 1) < len(data_days):
        next_day_data = data_days[day_index + 1]
        next_max_dot_y = _get_curve_dot_y(float(next_day_data["maxtemperature"]), base_height, scale_factor, maxheightshift)
        next_min_dot_y = _get_curve_dot_y(float(next_day_data["mintemperature"]), base_height, scale_factor, maxheightshift)
        next_min_dot_y = _apply_curve_gap(next_max_dot_y, next_min_dot_y, scale_factor, min_gap, bottom_limit)
        next_min_dot_y -= blue_offset
        max_diff = _get_curve_diff_from_dots(max_dot_y, next_max_dot_y, scale_factor)
        min_diff = _get_curve_diff_from_dots(min_dot_y, next_min_dot_y, scale_factor)
        max_exact_height = abs(max_dot_y - next_max_dot_y)
        min_exact_height = abs(min_dot_y - next_min_dot_y)
        max_lineheight = max_exact_height if max_dot_y > next_max_dot_y else 0
        min_lineheight = min_exact_height if min_dot_y > next_min_dot_y else 0
    else:
        max_diff = 0
        min_diff = 0
        max_exact_height = 0
        min_exact_height = 0
        max_lineheight = 0
        min_lineheight = 0

    max_ypos = max_dot_y - max_lineheight
    min_ypos = min_dot_y - min_lineheight

    return {
        "max_temp": max_temp,
        "min_temp": min_temp,
        "max_diff": max_diff,
        "min_diff": min_diff,
        "max_lineheight": max_lineheight,
        "min_lineheight": min_lineheight,
        "max_ypos": max_ypos,
        "min_ypos": min_ypos,
        "max_dot_y": max_dot_y,
        "min_dot_y": min_dot_y,
        "max_exact_height": max_exact_height,
        "min_exact_height": min_exact_height,
    }


def _get_temperature_shift(data_days, base_height, scale_factor, label_offset, target_top):
    maxheightshift = base_height * 2
    for day_index in range(0, len(data_days)):
        day_data = data_days[day_index]
        max_temp = int(round(float(day_data["maxtemperature"])))
        max_diff = _get_temperature_diff(data_days, day_index, "maxtemperature", max_temp)
        lineheight = max(max_diff, 0) * scale_factor
        yposline = (base_height - (max_temp * scale_factor)) - lineheight
        yposline = (yposline + lineheight) - label_offset
        if yposline < maxheightshift:
            maxheightshift = yposline
    return target_top - maxheightshift


def _get_mapping_value(mapping, *keys):
    if not isinstance(mapping, dict):
        return None
    for key in keys:
        value = mapping.get(key)
        if value not in (None, ""):
            return value
    return None


def _extract_time_text(value, default="--:--"):
    text_value = _ensure_text(value).strip()
    if not text_value:
        return default
    if "T" in text_value:
        text_value = text_value.split("T", 1)[1]
    if len(text_value) >= 5 and text_value[2] == ":":
        return text_value[:5]
    return default


def _get_day_datetime(day_data):
    date_text = _ensure_text(_get_mapping_value(day_data, "date")).strip()
    if len(date_text) < 10:
        return None
    try:
        return datetime.datetime(int(date_text[:4]), int(date_text[5:7]), int(date_text[8:10]))
    except Exception:
        return None


def _get_day_label_parts(day_data, date_format="%d"):
    day_datetime = _get_day_datetime(day_data)
    if day_datetime is None:
        return "", ""
    unix_time = time.mktime(day_datetime.timetuple())
    day_name = _(str(strftime("%A", localtime(unix_time))).title()[:2])
    day_date = strftime(date_format, localtime(unix_time))
    return day_name, day_date


def _format_day_summary_label(day_data):
    day_name, day_date = _get_day_label_parts(day_data, "%d")
    if day_name and day_date:
        return day_name + " " + day_date
    return day_name or day_date


def _format_day_temperature_label(value, default="--"):
    return _format_temperature_text(value, 0, default) + _tw_temp_suffix()


def _get_day_sunrise_sunset_text(day_data):
    sunrise_text = _extract_time_text(_get_mapping_value(day_data, "sunrise"))
    sunset_text = _extract_time_text(_get_mapping_value(day_data, "sunset"))
    return sunrise_text + " - " + sunset_text


def _get_hour_value(hour_data):
    try:
        return int(_get_mapping_value(hour_data, "hour"))
    except Exception:
        return None


def _get_display_hour_for_day(day_data, day_index):
    hours = []
    if isinstance(day_data, dict):
        hours = list(day_data.get("hours") or [])
    if not hours:
        return {}
    if day_index == 0:
        current_hour = datetime.datetime.now().hour
        for hour_data in hours:
            hour_value = _get_hour_value(hour_data)
            if hour_value is not None and hour_value >= current_hour:
                return hour_data
        return hours[0]
    best_hour = None
    best_diff = None
    for hour_data in hours:
        hour_value = _get_hour_value(hour_data)
        if hour_value is None:
            continue
        current_diff = abs(hour_value - 12)
        if best_hour is None or current_diff < best_diff:
            best_hour = hour_data
            best_diff = current_diff
    if best_hour is not None:
        return best_hour
    return hours[0]


def icontotext(icon):
    text = ""
    icon = str(icon).lower()
    if icon == "a": text = _("Sunny / Clear")
    elif icon == "aa": text = _("Clear night")
    elif icon == "na": text = _("Partly cloudy night")
    elif icon == "b": text = _("Sunny few clouds")
    elif icon == "bb": text = _("Light cloudy")
    elif icon == "c": text = _("Heavy clouds")
    elif icon == "cc": text = _("Heavy clouds")
    elif icon == "d": text = _("Changeable and chance of mist")
    elif icon == "dd": text = _("Changeable and chance of mist")
    elif icon == "f": text = _("Sunny and chance of showers")
    elif icon == "ff": text = _("Cloudy and chance of showers")
    elif icon == "g": text = _("Sunny and chance of thundershowers")
    elif icon == "gg": text = _("Showers and chance of thunder")
    elif icon == "j": text = _("Mostly sunny")
    elif icon == "jj": text = _("Mostly clear")
    elif icon == "m": text = _("Heavy clouds showers possible")
    elif icon == "mm": text = _("Heavy clouds showers possible")
    elif icon in ("n", "nn"): text = _("Clear night")
    elif icon == "q": text = _("Heavy clouds heavy showers")
    elif icon == "qq": text = _("Heavy clouds heavy showers")
    elif icon == "r": text = _("Cloudy")
    elif icon == "rr": text = _("Cloudy")
    elif icon == "s": text = _("Heavy clouds thundershowers")
    elif icon == "ss": text = _("Heavy clouds thundershowers")
    elif icon == "t": text = _("Heavy clouds and heavy snowfall")
    elif icon == "tt": text = _("Heavy clouds and heavy snowfall")
    elif icon == "u": text = _("Changeable cloudy light snowfall")
    elif icon == "uu": text = _("Changeable cloudy light snowfall")
    elif icon == "v": text = _("Heavy clouds light snowfall")
    elif icon == "vv": text = _("Heavy clouds light snowfall")
    elif icon == "w": text = _("Heavy clouds winter rainfall")
    elif icon == "ww": text = _("Heavy clouds winter rainfall")
    else: text = _("No info")
    return text


def winddirtext(dirtext):
    text = ""
    if dirtext == "N":
        text = _("N")
    elif dirtext == "NE":
        text = _("NE")
    elif dirtext == "E":
        text = _("E")
    elif dirtext == "SE":
        text = _("SE")
    elif dirtext == "S":
        text = _("S")
    elif dirtext == "SW":
        text = _("SW")
    elif dirtext == "W":
        text = _("W")
    elif dirtext == "NW":
        text = _("NW")
    return text
