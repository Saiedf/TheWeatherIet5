# -*- coding: utf-8 -*-
"""Extended forecast screens and legacy skin aliases."""
from __future__ import print_function, absolute_import

# Shared helpers and runtime synchronization.
from .plugin_screen_common import (
    ActionMap,
    AddNewScreen,
    GRAPH_RAIN_BAR_MAX_HEIGHT_HD,
    GRAPH_RAIN_BAR_MAX_HEIGHT_SD,
    GRAPH_RAIN_SHIFT_Y_HD,
    GRAPH_RAIN_SHIFT_Y_SD,
    GRAPH_RED_LABEL_SHIFT_Y_HD,
    GRAPH_RED_LABEL_SHIFT_Y_SD,
    GRAPH_TEMP_LABEL_SHIFT_X_HD,
    GRAPH_TEMP_LABEL_SHIFT_X_SD,
    GRAPH_TOP_SHIFT_Y_HD,
    GRAPH_TOP_SHIFT_Y_SD,
    GRAPH_WIND_SHIFT_Y_HD,
    GRAPH_WIND_SHIFT_Y_SD,
    PY3,
    Pixmap,
    Screen,
    StaticText,
    _GRAPH_OPEN_REQUESTED,
    _apply_graph_shifts,
    _apply_skin_path,
    _background_skin_asset_path,
    _close_screen_instance,
    _fit_graph_scale,
    _forecast_day_column_offset,
    _forecast_graph_temp_unit_layout,
    _forecast_provider_name,
    _forecast_screen_day_count,
    _format_rain_text,
    _format_speed_text,
    _format_temperature_text,
    _get_day_label_parts,
    _get_mapping_value,
    _get_temperature_line_layout,
    _get_temperature_shift,
    _graph_visual_days,
    _is_dreambox_image,
    _round_half_up,
    _runtime_city_display_name,
    _set_component_text,
    _tuned,
    _tw_cfg,
    _tw_convert_temp,
    _tw_get_safe_wind_icon,
    _tw_log,
    _tw_temp_suffix,
    _use_fullhd_layout,
    bind_runtime,
    iconpath,
    time,
)

class fourteen(Screen):
    def __init__(self, session):
        build_started = time.time()
        bind_runtime()
        Screen.__init__(self, session)
        AddNewScreen(self)
        self._screen_closed = False
        global weatherData
        dataDays = list(weatherData.get("days") or [])
        visible_days = _forecast_screen_day_count(dataDays, 16, weatherData)
        provider = _forecast_provider_name(weatherData)
        if provider == "msn":
            screen_title = "10 Days Forecast"
            screen_name = "TenDays"
        elif provider == "buienradar":
            screen_title = "14 Days Forecast"
            screen_name = "FourteenDays"
        else:
            screen_title = "16 Days Forecast"
            screen_name = "SexteenDays"
        if _use_fullhd_layout():
            dayinfoblok = ""
            x_offset = _forecast_day_column_offset(True, visible_days)
            temp_unit_layout = _forecast_graph_temp_unit_layout(True)
            lines_size = {'-1.png': [122, 15], '-2.png': [122, 30], '-3.png': [122, 45], '-4.png': [122, 60],
                          '-5.png': [122, 75], '-6.png': [122, 90], '-7.png': [122, 105], '-8.png': [122, 120],
                          '-9.png': [122, 135], '-10.png': [122, 150], '-11.png': [122, 165], '-12.png': [122, 180],
                          '-13.png': [122, 195], '-14.png': [122, 210], '-15.png': [122, 225], '0.png': [122, 5],
                          '1.png': [122, 15], '2.png': [122, 30], '3.png': [122, 45], '4.png': [122, 60],
                          '5.png': [122, 75], '6.png': [122, 90], '7.png': [122, 105], '8.png': [122, 120],
                          '9.png': [122, 135], '10.png': [122, 150], '11.png': [122, 165], '12.png': [122, 180],
                          '13.png': [122, 195], '14.png': [122, 210], '15.png': [122, 225], 'b-1.png': [122, 15],
                          'b-2.png': [122, 30], 'b-3.png': [122, 45], 'b-4.png': [122, 60], 'b-5.png': [122, 75],
                          'b-6.png': [122, 90], 'b-7.png': [122, 105], 'b-8.png': [122, 120], 'b-9.png': [122, 135],
                          'b-10.png': [122, 150], 'b-11.png': [122, 165], 'b-12.png': [122, 180], 'b-13.png': [122, 195],
                          'b-14.png': [122, 210], 'b-15.png': [122, 225], 'b0.png': [122, 5], 'b1.png': [122, 15],
                          'b2.png': [122, 30], 'b3.png': [122, 45], 'b4.png': [122, 60], 'b5.png': [122, 75],
                          'b6.png': [122, 90], 'b7.png': [122, 105], 'b8.png': [122, 120], 'b9.png': [122, 135],
                          'b10.png': [122, 150], 'b11.png': [122, 165], 'b12.png': [122, 180], 'b13.png': [122, 195],
                          'b14.png': [122, 210], 'b15.png': [122, 225]}
            temp_list = [_round_half_up(d["maxtemperature"]) for d in dataDays[:visible_days]] + \
                        [_round_half_up(d["mintemperature"]) for d in dataDays[:visible_days]]
            temp_range = max(temp_list) - min(temp_list) if temp_list else 1
            if temp_range <= 0:
                temp_range = 1
            is_dreambox_py2 = _is_dreambox_image() and not PY3
            scale_factor, graph_extra_drop = _fit_graph_scale(dataDays, visible_days, True, is_dreambox_py2)
                    
            visual_data_days = _graph_visual_days(dataDays, visible_days)

            maxheightshift = _get_temperature_shift(visual_data_days, 1200, scale_factor, 12, 615 + GRAPH_TOP_SHIFT_Y_HD)
            
            blue_offset = 0
            max_blue_y = 0
            smallest_gap = 1000
            top_max_dot_y = 100000
            for day in range(0, visible_days):
                plot_temp = _get_temperature_line_layout(visual_data_days, day, 1200, scale_factor, maxheightshift, 0, None)
                if plot_temp["min_dot_y"] > max_blue_y:
                    max_blue_y = plot_temp["min_dot_y"]
                if plot_temp["max_dot_y"] < top_max_dot_y:
                    top_max_dot_y = plot_temp["max_dot_y"]
                gap = plot_temp["min_dot_y"] - plot_temp["max_dot_y"]
                if gap < smallest_gap:
                    smallest_gap = gap
            if max_blue_y > 675:
                blue_offset = max_blue_y - 675
                # Keep at least 50% of the smallest natural gap to preserve
                # flexible spacing proportional to actual temperature differences
                min_preserved_gap = max(80, int(smallest_gap * 0.5))
                max_allowed_offset = smallest_gap - min_preserved_gap
                if max_allowed_offset < 0:
                    max_allowed_offset = 0
                if blue_offset > max_allowed_offset:
                    blue_offset = max_allowed_offset
                if blue_offset < 0:
                    blue_offset = 0

            for day in range(0, visible_days):
                dagenbefore = dataDays[day]
                plot = _apply_graph_shifts(_get_temperature_line_layout(visual_data_days, day, 1200, scale_factor, maxheightshift, 80, None, blue_offset=blue_offset), True, graph_extra_drop)
                curtemp = plot["max_temp"]
                tempdiff = plot["max_diff"]
                lineheight = plot["max_lineheight"]
                yposline = plot["max_ypos"]
                # shiftstart = 130
                rainamount = int(float(dagenbefore["precipitationmm"]) * 2)
                if 1 < rainamount < 10:
                    rainamount = 10
                elif rainamount > 100:
                    rainamount = 100
                curtempcold = plot["min_temp"]
                tempdiffcold = plot["min_diff"]
                lineheightcold = plot["min_lineheight"]
                yposlinecold = plot["min_ypos"]
                if day < (visible_days - 1):
                    exact_lineheight = plot.get("max_exact_height", abs(tempdiff) * scale_factor)
                    exact_lineheightcold = plot.get("min_exact_height", abs(tempdiffcold) * scale_factor)
                    linesize = """size="113,%s\"""" % max(int(exact_lineheight), 5)
                    linesizeb = """size="113,%s\"""" % max(int(exact_lineheightcold), 5)
                    if is_dreambox_py2:
                        dayinfoblok += """
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/""" + str(tempdiff) + """.png" position=\"""" + str((40 + (113 * day)) + 59 + x_offset) + """,""" + str(yposline) + """\" """ + linesize + """ zPosition="10" transparent="0" alphatest="blend"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/b""" + str(tempdiffcold) + """.png" position=\"""" + str((40 + (113 * day)) + 59 + x_offset) + """,""" + str(yposlinecold) + """\" """ + linesizeb + """ zPosition="10" transparent="0" alphatest="blend"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/bar.png" position=\"""" + str((40 + (113 * day)) + 120 + x_offset) + """,140" size="10,900" zPosition="10" transparent="0" alphatest="blend"/>
                        """
                    else:
                        dayinfoblok += """
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/""" + str(tempdiff) + """.png" position=\"""" + str((40 + (113 * day)) + 59 + x_offset) + """,""" + str(yposline) + """\" """ + linesize + """ zPosition="10" transparent="1" alphatest="blend" scale="1"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/b""" + str(tempdiffcold) + """.png" position=\"""" + str((40 + (113 * day)) + 59 + x_offset) + """,""" + str(yposlinecold) + """\" """ + linesizeb + """ zPosition="10" transparent="1" alphatest="blend" scale="1"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/bar.png" position=\"""" + str((40 + (113 * day)) + 120 + x_offset) + """,140" size="10,900" zPosition="10" transparent="1" alphatest="blend" scale="1"/>
                        """
                closedrainbar = int(round(rainamount // 3) * 3)
                closedrainbar = min(closedrainbar, GRAPH_RAIN_BAR_MAX_HEIGHT_HD)
                dayinfoblok += """
                    <widget render="Label" source="rainfall""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,""" + str(530 + GRAPH_RAIN_SHIFT_Y_HD) + """" size="113,54" valign="center" halign="center" zPosition="20" font="Regular;24" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="windspeed""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,""" + str(435 + GRAPH_WIND_SHIFT_Y_HD) + """" size="113,54" valign="center" halign="center" zPosition="20" font="Regular;24" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="rainfallUnit""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,""" + str(530 + GRAPH_RAIN_SHIFT_Y_HD) + """" size="113,54" valign="center" halign="center" zPosition="20" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>"""
                if is_dreambox_py2:
                    dayinfoblok += """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rain_""" + str(closedrainbar) + """.png" position=\"""" + str((38 + (113 * day)) + 45 + x_offset) + """,""" + str((532 + GRAPH_RAIN_SHIFT_Y_HD) - closedrainbar) + """\" size="60,""" + str(closedrainbar) + """\" zPosition="12" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rainstond.png" position=\"""" + str((20 + (113 * day)) + 45 + x_offset) + """,""" + str((530 + GRAPH_RAIN_SHIFT_Y_HD)) + """\" size="70,10" zPosition="15" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rdot.png" position=\"""" + str(((40 + (113 * day)) + 59) - 12 + x_offset) + """,""" + str((plot["max_dot_y"] - 12)) + """\" size="25,25" zPosition="10" transparent="0" alphatest="blend"/>
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str((40 + (113 * day)) + 28 + x_offset) + """,267" size="72,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/""" + str(dagenbefore["iconcode"]) + """.png" zPosition="1" alphatest="blend"/>

                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/bdot.png" position=\"""" + str(((40 + (113 * day)) + 59) - 12 + x_offset) + """,""" + str((plot["min_dot_y"] - 12)) + """\" size="25,25" zPosition="10" transparent="0" alphatest="blend"/>"""
                else:
                    dayinfoblok += """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rain_""" + str(closedrainbar) + """.png" position=\"""" + str((38 + (113 * day)) + 45 + x_offset) + """,""" + str((532 + GRAPH_RAIN_SHIFT_Y_HD) - closedrainbar) + """\" size="60,""" + str(closedrainbar) + """\" zPosition="12" transparent="1" alphatest="blend" scale="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rainstond.png" position=\"""" + str((20 + (113 * day)) + 45 + x_offset) + """,""" + str((530 + GRAPH_RAIN_SHIFT_Y_HD)) + """\" size="70,10" zPosition="15" transparent="1" alphatest="blend" scale="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rdot.png" position=\"""" + str(((40 + (113 * day)) + 59) - 12 + x_offset) + """,""" + str((plot["max_dot_y"] - 12)) + """\" size="25,25" zPosition="10" transparent="1" alphatest="blend" scale="1"/>
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str((40 + (113 * day)) + 28 + x_offset) + """,267" size="72,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/""" + str(dagenbefore["iconcode"]) + """.png" zPosition="1" alphatest="blend"/>

                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/bdot.png" position=\"""" + str(((40 + (113 * day)) + 59) - 12 + x_offset) + """,""" + str((plot["min_dot_y"] - 12)) + """\" size="25,25" zPosition="10" transparent="1" alphatest="blend" scale="1"/>"""
                dayinfoblok += """
                    <widget name="wind""" + str(day) + """" position=\"""" + str((40 + (113 * day)) + 36 + x_offset) + """,""" + str(375 + GRAPH_WIND_SHIFT_Y_HD) + """" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windbig/""" + _tw_get_safe_wind_icon(iconpath, dagenbefore["winddirection"], "windbig") + """.png" zPosition="2" transparent="1" alphatest="blend"/>
                    <widget render="Label" source="dayOfWeek""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,""" + str(_tuned(147, 155)) + """" size="113,54" valign="center" halign="center" zPosition="15" font="Regular;""" + str(_tuned(38, 45)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dateOfWeek""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,""" + str(_tuned(201, 195)) + """" size="113,54" valign="center" halign="center" zPosition="15" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMax""" + str(day) + """" position=\"""" + str(((40 + (113 * day)) - 15) + 59 + _tuned(GRAPH_TEMP_LABEL_SHIFT_X_HD) + x_offset) + """,""" + str((plot["max_label_dot_y"] - 45) + _tuned(GRAPH_RED_LABEL_SHIFT_Y_HD)) + """\" size="62,54" zPosition="15" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMaxUnit""" + str(day) + """" position=\"""" + str(((40 + (113 * day)) - 15) + 98 + temp_unit_layout["x_shift"] + _tuned(GRAPH_TEMP_LABEL_SHIFT_X_HD) + x_offset) + """,""" + str((plot["max_label_dot_y"] - 45) + _tuned(GRAPH_RED_LABEL_SHIFT_Y_HD) + temp_unit_layout["y_shift"]) + """\" size=\"""" + str(temp_unit_layout["width"]) + """,""" + str(temp_unit_layout["height"]) + """\" zPosition="15" font="Regular;""" + str(temp_unit_layout["font"]) + """" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>

                    <widget render="Label" source="lineTempMin""" + str(day) + """" position=\"""" + str(((40 + (113 * day)) - 15) + 59 + _tuned(GRAPH_TEMP_LABEL_SHIFT_X_HD) + x_offset) + """,""" + str((plot["min_dot_y"] + 15)) + """\" size="62,54" zPosition="15" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMinUnit""" + str(day) + """" position=\"""" + str(((40 + (113 * day)) - 15) + 98 + temp_unit_layout["x_shift"] + _tuned(GRAPH_TEMP_LABEL_SHIFT_X_HD) + x_offset) + """,""" + str((plot["min_dot_y"] + 15) + temp_unit_layout["y_shift"]) + """\" size=\"""" + str(temp_unit_layout["width"]) + """,""" + str(temp_unit_layout["height"]) + """\" zPosition="15" font="Regular;""" + str(temp_unit_layout["font"]) + """" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    """
            skin = """
                    <screen name=\"""" + screen_name + """\" position="center,center" size="1920,1080" title=\"""" + screen_title + """\"""" + _tuned(' flags="wfNoBorder"', '') + """>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/bgbluhd.png" position="center,center" size="1920,1080" zPosition="0" alphatest="blend"/>
                    <widget source="global.CurrentTime" render="Label" position="1608,30" size="250,50" transparent="1" zPosition="1" font="Regular;38" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="1360,""" + str(_tuned(83, 76)) + """" size="500,38" transparent="1" zPosition="1" font="Regular;26" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget render="Label" source="city1" position="540,34" size="840,72" zPosition="3" valign="center" halign="center" font="Regular;54" transparent="1" />
                    """ + dayinfoblok + """
                    </screen>"""

            for day in range(0, visible_days):
                dagenbefore = dataDays[day]
                plot = _apply_graph_shifts(_get_temperature_line_layout(visual_data_days, day, 1200, scale_factor, maxheightshift, 80, None, blue_offset=blue_offset), True, graph_extra_drop)
                self["windspeed" + str(day)] = StaticText()
                _set_component_text(self["windspeed" + str(day)], _format_speed_text(dagenbefore["windspeed"]))
                self["rainfall" + str(day)] = StaticText()
                _set_component_text(self["rainfall" + str(day)], _format_rain_text(dagenbefore["precipitationmm"]))
                self["rainfallUnit" + str(day)] = StaticText()
                _set_component_text(self["rainfallUnit" + str(day)], "")
                day_name, day_date = _get_day_label_parts(dagenbefore, "%d-%m")
                self["lineTempMax" + str(day)] = StaticText()
                _set_component_text(self["lineTempMax" + str(day)], '{:>3}'.format(_format_temperature_text(_tw_convert_temp(_get_mapping_value(dagenbefore, "maxtemperature")), 0, "NA")))
                self["lineTempMaxUnit" + str(day)] = StaticText()
                _set_component_text(self["lineTempMaxUnit" + str(day)], _tw_temp_suffix())
                self["lineTempMin" + str(day)] = StaticText()
                _set_component_text(self["lineTempMin" + str(day)], '{:>3}'.format(_format_temperature_text(_tw_convert_temp(_get_mapping_value(dagenbefore, "mintemperature")), 0, "NA")))
                self["lineTempMinUnit" + str(day)] = StaticText()
                _set_component_text(self["lineTempMinUnit" + str(day)], _tw_temp_suffix())

                self["bigWeerIcon1" + str(day)] = Pixmap()
                self["wind" + str(day)] = Pixmap()
                self["city1"] = StaticText()
                _set_component_text(self["city1"], _runtime_city_display_name())
                self["dayOfWeek" + str(day)] = StaticText()
                _set_component_text(self["dayOfWeek" + str(day)], str(day_name).upper())
                self["dateOfWeek" + str(day)] = StaticText()
                _set_component_text(self["dateOfWeek" + str(day)], str(day_date))
        else:
            dayinfoblok = ""
            x_offset = _forecast_day_column_offset(False, visible_days)
            temp_unit_layout = _forecast_graph_temp_unit_layout(False)
            lines_size = {'-1.png': [82, 10], '-2.png': [82, 20], '-3.png': [82, 30], '-4.png': [82, 40],
                          '-5.png': [82, 50], '-6.png': [82, 60], '-7.png': [82, 70], '-8.png': [82, 80],
                          '-9.png': [82, 90], '-10.png': [82, 100], '-11.png': [82, 110], '-12.png': [82, 120],
                          '-13.png': [82, 130], '-14.png': [82, 140], '-15.png': [82, 150], '0.png': [82, 3],
                          '1.png': [82, 10], '2.png': [82, 20], '3.png': [82, 30], '4.png': [82, 40],
                          '5.png': [82, 50], '6.png': [82, 60], '7.png': [82, 70], '8.png': [82, 80],
                          '9.png': [82, 90], '10.png': [82, 100], '11.png': [82, 110], '12.png': [82, 120],
                          '13.png': [82, 130], '14.png': [82, 140], '15.png': [82, 150], 'b-1.png': [82, 10],
                          'b-2.png': [82, 20], 'b-3.png': [82, 30], 'b-4.png': [82, 40], 'b-5.png': [82, 50],
                          'b-6.png': [82, 60], 'b-7.png': [82, 70], 'b-8.png': [82, 80], 'b-9.png': [82, 90],
                          'b-10.png': [82, 110], 'b-11.png': [82, 110], 'b-12.png': [82, 120], 'b-13.png': [82, 130],
                          'b-14.png': [82, 140], 'b-15.png': [82, 150], 'b0.png': [82, 3], 'b1.png': [82, 10],
                          'b2.png': [82, 20], 'b3.png': [82, 30], 'b4.png': [82, 40], 'b5.png': [82, 50],
                          'b6.png': [82, 60], 'b7.png': [82, 70], 'b8.png': [82, 80], 'b9.png': [82, 90],
                          'b10.png': [82, 100], 'b11.png': [82, 110], 'b12.png': [82, 120], 'b13.png': [82, 130],
                          'b14.png': [82, 140], 'b15.png': [82, 150]}
            temp_list = [_round_half_up(d["maxtemperature"]) for d in dataDays[:visible_days]] + \
                        [_round_half_up(d["mintemperature"]) for d in dataDays[:visible_days]]
            temp_range = max(temp_list) - min(temp_list) if temp_list else 1
            if temp_range <= 0:
                temp_range = 1
            is_dreambox_py2 = _is_dreambox_image() and not PY3
            scale_factor, graph_extra_drop = _fit_graph_scale(dataDays, visible_days, False, is_dreambox_py2)
                    
            visual_data_days = _graph_visual_days(dataDays, visible_days)

            maxheightshift = _get_temperature_shift(visual_data_days, 800, scale_factor, 12, 430 + GRAPH_TOP_SHIFT_Y_SD)
            
            blue_offset = 0
            max_blue_y = 0
            smallest_gap = 1000
            top_max_dot_y = 100000
            for day in range(0, visible_days):
                plot_temp = _get_temperature_line_layout(visual_data_days, day, 800, scale_factor, maxheightshift, 0, None)
                if plot_temp["min_dot_y"] > max_blue_y:
                    max_blue_y = plot_temp["min_dot_y"]
                if plot_temp["max_dot_y"] < top_max_dot_y:
                    top_max_dot_y = plot_temp["max_dot_y"]
                gap = plot_temp["min_dot_y"] - plot_temp["max_dot_y"]
                if gap < smallest_gap:
                    smallest_gap = gap
            if max_blue_y > 480:
                blue_offset = max_blue_y - 480
                # Keep at least 50% of the smallest natural gap to preserve
                # flexible spacing proportional to actual temperature differences
                min_preserved_gap = max(52, int(smallest_gap * 0.5))
                max_allowed_offset = smallest_gap - min_preserved_gap
                if max_allowed_offset < 0:
                    max_allowed_offset = 0
                if blue_offset > max_allowed_offset:
                    blue_offset = max_allowed_offset
                if blue_offset < 0:
                    blue_offset = 0

            for day in range(0, visible_days):
                dagenbefore = dataDays[day]
                plot = _apply_graph_shifts(_get_temperature_line_layout(visual_data_days, day, 800, scale_factor, maxheightshift, 52, None, blue_offset=blue_offset), False, graph_extra_drop)
                curtemp = plot["max_temp"]
                tempdiff = plot["max_diff"]
                lineheight = plot["max_lineheight"]
                yposline = plot["max_ypos"]
                rainamount = int(float(dagenbefore["precipitationmm"]) * 2)
                if 1 < rainamount < 10:
                    rainamount = 10
                elif rainamount > 100:
                    rainamount = 100
                curtempcold = plot["min_temp"]
                tempdiffcold = plot["min_diff"]
                lineheightcold = plot["min_lineheight"]
                yposlinecold = plot["min_ypos"]
                if day < (visible_days - 1):
                    exact_lineheight = plot.get("max_exact_height", abs(tempdiff) * scale_factor)
                    exact_lineheightcold = plot.get("min_exact_height", abs(tempdiffcold) * scale_factor)
                    linesize = """size="74,%s\"""" % max(int(exact_lineheight), 3)
                    linesizeb = """size="74,%s\"""" % max(int(exact_lineheightcold), 3)
                    if is_dreambox_py2:
                        dayinfoblok += """
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/""" + str(tempdiff) + """.png" position=\"""" + str((30 + (74 * day)) + 39 + x_offset) + """,""" + str(yposline) + """\" """ + linesize + """ zPosition="10" transparent="0" alphatest="blend"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/b""" + str(tempdiffcold) + """.png" position=\"""" + str((30 + (74 * day)) + 39 + x_offset) + """,""" + str(yposlinecold) + """\" """ + linesizeb + """ zPosition="10" transparent="0" alphatest="blend"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/bar.png" position=\"""" + str((30 + (74 * day)) + 80 + x_offset) + """,93" size="3,590" zPosition="10" transparent="0" alphatest="blend"/>
                        """
                    else:
                        dayinfoblok += """
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/""" + str(tempdiff) + """.png" position=\"""" + str((30 + (74 * day)) + 39 + x_offset) + """,""" + str(yposline) + """\" """ + linesize + """ zPosition="10" transparent="1" alphatest="blend" scale="1"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/b""" + str(tempdiffcold) + """.png" position=\"""" + str((30 + (74 * day)) + 39 + x_offset) + """,""" + str(yposlinecold) + """\" """ + linesizeb + """ zPosition="10" transparent="1" alphatest="blend" scale="1"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/bar.png" position=\"""" + str((30 + (74 * day)) + 80 + x_offset) + """,93" size="3,590" zPosition="10" transparent="1" alphatest="blend" scale="1"/>
                        """

                closedrainbar = int(round(rainamount // 3) * 3)
                closedrainbar = min(closedrainbar, GRAPH_RAIN_BAR_MAX_HEIGHT_SD)
                dayinfoblok += """
                    <widget render="Label" source="rainfall""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,""" + str(355 + GRAPH_RAIN_SHIFT_Y_SD) + """" size="74,36" valign="center" halign="center" zPosition="20" font="Regular;16" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="windspeed""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,""" + str(290 + GRAPH_WIND_SHIFT_Y_SD) + """" size="74,36" valign="center" halign="center" zPosition="20" font="Regular;19" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="rainfallUnit""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,""" + str(355 + GRAPH_RAIN_SHIFT_Y_SD) + """" size="74,36" valign="center" halign="center" zPosition="20" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>"""
                if is_dreambox_py2:
                    dayinfoblok += """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rain_""" + str(closedrainbar) + """.png" position=\"""" + str((24 + (74 * day)) + 30 + x_offset) + """,""" + str((357 + GRAPH_RAIN_SHIFT_Y_SD) - closedrainbar) + """\" size="40,""" + str(closedrainbar) + """\" zPosition="12" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rainstond.png" position=\"""" + str((8 + (74 * day)) + 30 + x_offset) + """,""" + str((355 + GRAPH_RAIN_SHIFT_Y_SD)) + """\" size="64,7" zPosition="15" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rdot.png" position=\"""" + str(((31 + (74 * day)) + 39) - 8 + x_offset) + """,""" + str((plot["max_dot_y"] - 8)) + """\" size="18,18" zPosition="10" transparent="0" alphatest="blend"/>
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str((31 + (74 * day)) + 19 + x_offset) + """,178" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/""" + str(dagenbefore["iconcode"]) + """.png" zPosition="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/bdot.png" position=\"""" + str(((31 + (74 * day)) + 39) - 8 + x_offset) + """,""" + str((plot["min_dot_y"] - 8)) + """\" size="18,18" zPosition="10" transparent="0" alphatest="blend"/>"""
                else:
                    dayinfoblok += """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rain_""" + str(closedrainbar) + """.png" position=\"""" + str((24 + (74 * day)) + 30 + x_offset) + """,""" + str((357 + GRAPH_RAIN_SHIFT_Y_SD) - closedrainbar) + """\" size="40,""" + str(closedrainbar) + """\" zPosition="12" transparent="1" alphatest="blend" scale="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rainstond.png" position=\"""" + str((8 + (74 * day)) + 30 + x_offset) + """,""" + str((355 + GRAPH_RAIN_SHIFT_Y_SD)) + """\" size="64,7" zPosition="15" transparent="1" alphatest="blend" scale="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rdot.png" position=\"""" + str(((31 + (74 * day)) + 39) - 8 + x_offset) + """,""" + str((plot["max_dot_y"] - 8)) + """\" size="18,18" zPosition="10" transparent="1" alphatest="blend" scale="1"/>
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str((31 + (74 * day)) + 19 + x_offset) + """,178" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/""" + str(dagenbefore["iconcode"]) + """.png" zPosition="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/bdot.png" position=\"""" + str(((31 + (74 * day)) + 39) - 8 + x_offset) + """,""" + str((plot["min_dot_y"] - 8)) + """\" size="18,18" zPosition="10" transparent="1" alphatest="blend" scale="1"/>"""
                dayinfoblok += """
                    <widget name="wind""" + str(day) + """" position=\"""" + str((24 + (74 * day)) + 27 + x_offset) + """,""" + str(250 + GRAPH_WIND_SHIFT_Y_SD) + """" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/""" + _tw_get_safe_wind_icon(iconpath, dagenbefore["winddirection"], "windhd") + """.png" zPosition="2" transparent="1" alphatest="blend"/>
                    <widget render="Label" source="dayOfWeek""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,""" + str(_tuned(98, 103)) + """" size="74,36" valign="center" halign="center" zPosition="15" font="Regular;""" + str(_tuned(26, 30)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dateOfWeek""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,""" + str(_tuned(134, 130)) + """" size="74,36" valign="center" halign="center" zPosition="15" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMax""" + str(day) + """" position=\"""" + str(((47 + (74 * day)) - 10) + 26 + _tuned(GRAPH_TEMP_LABEL_SHIFT_X_SD) + x_offset) + """,""" + str((plot["max_label_dot_y"] - 35) + _tuned(GRAPH_RED_LABEL_SHIFT_Y_SD)) + """\" size="38,36" zPosition="15" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMaxUnit""" + str(day) + """" position=\"""" + str(((47 + (74 * day)) - 10) + 52 + temp_unit_layout["x_shift"] + _tuned(GRAPH_TEMP_LABEL_SHIFT_X_SD) + x_offset) + """,""" + str((plot["max_label_dot_y"] - 35) + _tuned(GRAPH_RED_LABEL_SHIFT_Y_SD) + temp_unit_layout["y_shift"]) + """\" size=\"""" + str(temp_unit_layout["width"]) + """,""" + str(temp_unit_layout["height"]) + """\" zPosition="15" font="Regular;""" + str(temp_unit_layout["font"]) + """" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMin""" + str(day) + """" position=\"""" + str(((50 + (74 * day)) - 10) + 26 + _tuned(GRAPH_TEMP_LABEL_SHIFT_X_SD) + x_offset) + """,""" + str((plot["min_dot_y"] + 10)) + """\" size="38,36" zPosition="15" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMinUnit""" + str(day) + """" position=\"""" + str(((50 + (74 * day)) - 10) + 52 + temp_unit_layout["x_shift"] + _tuned(GRAPH_TEMP_LABEL_SHIFT_X_SD) + x_offset) + """,""" + str((plot["min_dot_y"] + 10) + temp_unit_layout["y_shift"]) + """\" size=\"""" + str(temp_unit_layout["width"]) + """,""" + str(temp_unit_layout["height"]) + """\" zPosition="15" font="Regular;""" + str(temp_unit_layout["font"]) + """" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    """
            skin = """
                    <screen name=\"""" + screen_name + """\" position="center,center" size="1280,720" title=\"""" + screen_title + """\"""" + _tuned(' flags="wfNoBorder"', '') + """>
                    <ePixmap pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=False) + """\" position="center,center" size="1280,720" zPosition="0" alphatest="blend"/>
                    <widget source="global.CurrentTime" render="Label" position="1091,12" size="150,55" transparent="1" zPosition="1" font="Regular;24" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="941,""" + str(_tuned(36, 32)) + """" size="300,55" transparent="1" zPosition="1" font="Regular;16" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget render="Label" source="city1" position="406,30" size="470,43" zPosition="3" valign="center" halign="center" font="Regular;32" transparent="1" />
                    """ + dayinfoblok + """
                    </screen>"""
            for day in range(0, visible_days):
                dagenbefore = dataDays[day]
                plot = _apply_graph_shifts(_get_temperature_line_layout(visual_data_days, day, 800, scale_factor, maxheightshift, 52, None, blue_offset=blue_offset), False, graph_extra_drop)
                self["windspeed" + str(day)] = StaticText()
                _set_component_text(self["windspeed" + str(day)], _format_speed_text(dagenbefore["windspeed"]))
                self["rainfall" + str(day)] = StaticText()
                _set_component_text(self["rainfall" + str(day)], _format_rain_text(dagenbefore["precipitationmm"]))
                self["rainfallUnit" + str(day)] = StaticText()
                _set_component_text(self["rainfallUnit" + str(day)], "")
                day_name, day_date = _get_day_label_parts(dagenbefore, "%d-%m")
                self["lineTempMax" + str(day)] = StaticText()
                _set_component_text(self["lineTempMax" + str(day)], '{:>3}'.format(_format_temperature_text(_tw_convert_temp(_get_mapping_value(dagenbefore, "maxtemperature")), 0, "NA")))
                self["lineTempMaxUnit" + str(day)] = StaticText()
                _set_component_text(self["lineTempMaxUnit" + str(day)], _tw_temp_suffix())
                self["lineTempMin" + str(day)] = StaticText()
                _set_component_text(self["lineTempMin" + str(day)], '{:>3}'.format(_format_temperature_text(_tw_convert_temp(_get_mapping_value(dagenbefore, "mintemperature")), 0, "NA")))
                self["lineTempMinUnit" + str(day)] = StaticText()
                _set_component_text(self["lineTempMinUnit" + str(day)], _tw_temp_suffix())

                self["bigWeerIcon1" + str(day)] = Pixmap()
                self["wind" + str(day)] = Pixmap()
                self["city1"] = StaticText()
                _set_component_text(self["city1"], _runtime_city_display_name())
                self["dayOfWeek" + str(day)] = StaticText()
                _set_component_text(self["dayOfWeek" + str(day)], str(day_name).upper())
                self["dateOfWeek" + str(day)] = StaticText()
                _set_component_text(self["dateOfWeek" + str(day)], str(day_date))
        self.session = session
        self.skin = _apply_skin_path(skin)
        self["myActionMap"] = ActionMap(["SetupActions"], {"ok": self.dayseven, "cancel": self.cancel, "red": self.exit}, -1)
        self.onClose.append(self._cleanup)
        # Timing for slow receivers (plain log line, nothing is hooked into Enigma2).
        try:
            _tw_log("%s built in %d ms" % (self.__class__.__name__, int((time.time() - build_started) * 1000)))
        except Exception:
            pass
        self._first_show_logged = False
        self.onShow.append(self._log_first_show)

    def _log_first_show(self):
        # Runs when Enigma2 shows the screen: the skin is applied and every widget exists by then.
        if self._first_show_logged:
            return
        self._first_show_logged = True
        try:
            requested = _GRAPH_OPEN_REQUESTED[0]
            if requested:
                _tw_log("%s shown %d ms after the OK key" % (self.__class__.__name__, int((time.time() - requested) * 1000)))
            _GRAPH_OPEN_REQUESTED[0] = 0.0
        except Exception:
            pass

    def _cleanup(self):
        self._screen_closed = True

    def dayseven(self):
        if self._screen_closed:
            return
        self._screen_closed = True
        _close_screen_instance(self)

    def exit(self):
        if self._screen_closed:
            return
        self._screen_closed = True
        _close_screen_instance(self)

    def cancel(self):
        if self._screen_closed:
            return
        self._screen_closed = True
        _close_screen_instance(self)

class TenDays(fourteen):
    pass


class FourteenDays(fourteen):
    pass


class SixteenDays(fourteen):
    pass


# Keep the legacy class name for compatibility with older skins/imports.
SexteenDays = SixteenDays

