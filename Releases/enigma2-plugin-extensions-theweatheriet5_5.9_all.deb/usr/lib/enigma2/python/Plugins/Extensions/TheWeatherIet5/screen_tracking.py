# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function ensures print() works as function in Python 2.7
from __future__ import print_function, absolute_import
# Screen lifecycle tracker for TheWeatherIet5
# Works on Dreambox DM920+, Vu+ (FuturePlus/ENIGMA2), OpenATV, VTI, BlackHole, OpenPLi and all Enigma2 images

screens = []
_CLOSE_RESULT_SENTINEL = object()


def RemoveScreen(screen):
    # Enigma2 Screen inherits dict; equal widget dictionaries are different dialogs.
    screens[:] = [tracked for tracked in screens if tracked is not screen]


def _tracked_screens_snapshot(exclude=None):
    tracked = []
    seen = set()
    for screen in list(screens):
        if screen is exclude:
            continue
        screen_id = id(screen)
        if screen_id in seen:
            continue
        seen.add(screen_id)
        tracked.append(screen)
    return tracked


def _close_tracked_screens(exclude=None):
    for screen in _tracked_screens_snapshot(exclude):
        try:
            screen.close()
        except Exception as e:
            print("[TheWeather] screen close error: " + str(e))
        else:
            RemoveScreen(screen)


def AddNewScreen(screen):
    if not any(tracked is screen for tracked in screens):
        screens.append(screen)
    try:
        if not getattr(screen, "_theweather_screen_tracked", False):
            def _cleanup_screen():
                RemoveScreen(screen)

            screen.onClose.append(_cleanup_screen)
            screen._theweather_screen_tracked = True
    except Exception:
        pass


def ClosePlugin(screen=None, result=_CLOSE_RESULT_SENTINEL):
    if screen is not None:
        try:
            if result is _CLOSE_RESULT_SENTINEL:
                screen.close()
            else:
                screen.close(result)
        except Exception as e:
            print("[TheWeather] close plugin error: " + str(e))
            return False
        RemoveScreen(screen)
        return True
    _close_tracked_screens()
