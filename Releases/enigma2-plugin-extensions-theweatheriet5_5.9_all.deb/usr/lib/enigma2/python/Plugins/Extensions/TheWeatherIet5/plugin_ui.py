# -*- coding: utf-8 -*-
"""Pixmap animation, remote actions, keyboards and skin assets.

Runtime state remains in plugin.py and is resolved when each function runs.
This preserves shared locks, current settings and existing plugin imports.
"""
from __future__ import print_function, absolute_import


_RUNTIME = None


def _bind_runtime(runtime):
    """Bind the authoritative plugin module before startup calls any helpers."""
    global _RUNTIME
    _RUNTIME = runtime


def _get_runtime():
    """Use the bound module without importing plugin.py while it initializes."""
    if _RUNTIME is None:
        import sys
        runtime = sys.modules.get(__name__.rsplit(".", 1)[0] + ".plugin")
        if runtime is None:
            from . import plugin as runtime
        _bind_runtime(runtime)
    return _RUNTIME


def _store_pixmap_position(widget, x, y):
    try:
        widget._weather_last_position = (int(x), int(y))
    except Exception:
        pass


def _get_pixmap_position(widget, default_x, default_y):
    try:
        if getattr(widget, "instance", None) is not None:
            point = widget.instance.position()
            return int(point.x()), int(point.y())
    except Exception:
        pass
    try:
        stored = getattr(widget, "_weather_last_position", None)
        if stored:
            return int(stored[0]), int(stored[1])
    except Exception:
        pass
    return int(default_x), int(default_y)


def _direct_move_pixmap(widget, x, y):
    _runtime = _get_runtime()

    target_x = int(x)
    target_y = int(y)
    try:
        if getattr(widget, "instance", None) is not None:
            widget.instance.move(_runtime.ePoint(target_x, target_y))
            _runtime._store_pixmap_position(widget, target_x, target_y)
            return True
    except Exception:
        pass
    try:
        widget.moveTo(target_x, target_y, 0)
        widget.startMoving()
        _runtime._store_pixmap_position(widget, target_x, target_y)
        return True
    except Exception:
        return False


def _anim_connect_timer(timer, callback):
    _runtime = _get_runtime()

    _runtime._connect_timer(timer, callback)


def _anim_disconnect_timer(timer, callback):
    _runtime = _get_runtime()

    _runtime._disconnect_timer(timer, callback)


def _stop_pixmap_animation(widget):
    _runtime = _get_runtime()

    timer = getattr(widget, "_weather_anim_timer", None)
    callback = getattr(widget, "_weather_anim_callback", None)
    if timer is not None:
        try:
            timer.stop()
        except Exception:
            pass
        if callback is not None:
            _runtime._anim_disconnect_timer(timer, callback)
    try:
        widget._weather_anim_timer = None
        widget._weather_anim_callback = None
    except Exception:
        pass


def _pixmap_animation_duration(duration):
    _runtime = _get_runtime()

    adjusted_duration = int(duration or 0)
    if adjusted_duration <= 0:
        return 0
    if _runtime._is_openatv_image() or _runtime._is_open_source_image():
        adjusted_duration = max(1, int(round(float(adjusted_duration) * _runtime.FAST_PIXMAP_ANIMATION_FACTOR)))
    return adjusted_duration


def _manual_move_pixmap(widget, x, y, duration=0):
    _runtime = _get_runtime()

    target_x = int(x)
    target_y = int(y)
    if widget is None:
        return False
    _runtime._stop_pixmap_animation(widget)
    frame_duration = int(duration or 0)
    if frame_duration <= 0:
        return _runtime._direct_move_pixmap(widget, target_x, target_y)
    start_x, start_y = _runtime._get_pixmap_position(widget, target_x, target_y)
    if start_x == target_x and start_y == target_y:
        return _runtime._direct_move_pixmap(widget, target_x, target_y)
    if _runtime.eTimer is None:
        return _runtime._direct_move_pixmap(widget, target_x, target_y)
    frame_count = max(6, min(24, frame_duration))
    frame_interval = 20
    state = {
        "step": 0,
        "steps": frame_count,
        "start_x": start_x,
        "start_y": start_y,
        "target_x": target_x,
        "target_y": target_y,
        "instance_waits": 0,
    }
    timer = _runtime.eTimer()

    def _animate_step():
        try:
            if getattr(widget, "instance", None) is None:
                state["instance_waits"] += 1
                if state["instance_waits"] > 8:
                    _runtime._stop_pixmap_animation(widget)
                    _runtime._direct_move_pixmap(widget, target_x, target_y)
                    return
                _runtime._start_timer(timer, 30)
                return
            state["step"] += 1
            progress = float(state["step"]) / float(state["steps"])
            next_x = int(round(state["start_x"] + ((state["target_x"] - state["start_x"]) * progress)))
            next_y = int(round(state["start_y"] + ((state["target_y"] - state["start_y"]) * progress)))
            _runtime._direct_move_pixmap(widget, next_x, next_y)
            if state["step"] >= state["steps"]:
                _runtime._stop_pixmap_animation(widget)
                return
            _runtime._start_timer(timer, frame_interval)
        except Exception:
            _runtime._stop_pixmap_animation(widget)
            _runtime._direct_move_pixmap(widget, target_x, target_y)

    _runtime._anim_connect_timer(timer, _animate_step)
    widget._weather_anim_timer = timer
    widget._weather_anim_callback = _animate_step
    _runtime._start_timer(timer, frame_interval)
    return True


def _move_pixmap(widget, x, y, duration=0):
    _runtime = _get_runtime()

    target_x = int(x)
    target_y = int(y)
    adjusted_duration = _runtime._pixmap_animation_duration(duration)
    if widget is None:
        return False
    if _runtime.USE_SAFE_PIXMAP_MOVE:
        return _runtime._manual_move_pixmap(widget, target_x, target_y, adjusted_duration)
    if not _runtime.USE_SAFE_PIXMAP_MOVE:
        try:
            widget.moveTo(target_x, target_y, adjusted_duration)
            widget.startMoving()
            _runtime._store_pixmap_position(widget, target_x, target_y)
            return True
        except Exception:
            pass
    return _runtime._manual_move_pixmap(widget, target_x, target_y, adjusted_duration)


def safe_get_desktop_width(default=1280):
    _runtime = _get_runtime()

    try:
        if _runtime.getDesktop is None:
            return default
        desktop = _runtime.getDesktop(0)
        if desktop is not None:
            size = desktop.size()
            if size is not None:
                width = int(size.width())
                if width > 0:
                    return width
    except Exception:
        pass
    return int(default)


def _normalize_action_contexts(contexts, text_converter):
    _runtime = _get_runtime()

    def _normalize_value(value):
        value = text_converter(value)
        # On Python 2 only: ActionMap contexts must be byte strings (str), not unicode.
        # On Python 3: str is already correct - do not encode.
        if not _runtime.PY3:
            try:
                if isinstance(value, _runtime.unicode):
                    return value.encode("utf-8", "ignore")
            except Exception:
                pass
        return value

    if isinstance(contexts, _runtime.STRING_TYPES):
        return [_normalize_value(contexts)]
    if contexts is None:
        return []
    if isinstance(contexts, (list, tuple)):
        result = []
        for context in contexts:
            if context is None:
                continue
            result.append(_normalize_value(context))
        return result
    return [_normalize_value(contexts)]


def _mapping_requires_helpable(mapping):
    try:
        iterator = mapping.values()
    except Exception:
        return False
    for value in iterator:
        if isinstance(value, (list, tuple)) and value:
            return True
    return False


def _normalize_action_mapping(mapping, keep_help_entries):
    normalized = {}
    try:
        iterator = mapping.items()
    except Exception:
        return normalized
    for key, value in iterator:
        if keep_help_entries:
            normalized[key] = value
            continue
        if isinstance(value, (list, tuple)) and value:
            normalized[key] = value[0]
            continue
        normalized[key] = value
    return normalized


def _ensure_menu_keymap():
    _runtime = _get_runtime()

    if _runtime._MENU_KEYMAP_LOADED:
        return True
    try:
        from keymapparser import readKeymap
        readKeymap(_runtime.os.path.join(_runtime.PLUGIN_ROOT, "keymap.xml"))
        _runtime._MENU_KEYMAP_LOADED = True
        return True
    except Exception as error:
        _runtime._tw_log("Plugin MENU keymap load failed: %s" % str(error))
        return False


def build_action_map(owner, contexts, mapping, priority=-1, helpable=False, text_converter=None):
    _runtime = _get_runtime()

    if text_converter is None:
        text_converter = lambda value: value
    context_list = _runtime._normalize_action_contexts(contexts, text_converter)
    if not context_list:
        context_list = ["WizardActions"]
    use_helpable = bool(helpable and _runtime.HelpableActionMap is not None and _runtime._use_helpable_actions() and _runtime._mapping_requires_helpable(mapping))
    action_mapping = _runtime._normalize_action_mapping(mapping, use_helpable)
    if use_helpable:
        try:
            return _runtime.HelpableActionMap(owner, context_list, action_mapping, priority)
        except Exception:
            pass
        for context in context_list:
            try:
                return _runtime.HelpableActionMap(owner, context, action_mapping, priority)
            except Exception:
                pass
    try:
        return _runtime.ActionMap(context_list, action_mapping, priority)
    except Exception:
        pass
    for context in context_list:
        try:
            return _runtime.ActionMap([context], action_mapping, priority)
        except Exception:
            pass
    return _runtime.ActionMap(["WizardActions"], action_mapping, priority)


def open_virtual_keyboard(session, callback, title, text="", text_converter=None, unavailable_message=None):
    _runtime = _get_runtime()

    if text_converter is None:
        text_converter = lambda value: value
    if unavailable_message is None:
        unavailable_message = "Keyboard screen is not available on this image."
    if _runtime.VirtualKeyBoard is None:
        if session is not None:
            session.open(_runtime.MessageBox, unavailable_message, _runtime.MESSAGEBOX_TYPE_INFO)
        return False
    last_error = None
    keyboard_title = text_converter(title)
    keyboard_text = text_converter(text)
    if not _runtime.PY3:
        keyboard_title = _runtime._ui_text(keyboard_title)
        keyboard_text = _runtime._ui_text(keyboard_text)
    attempts = []
    if _runtime._is_dreambox_image():
        attempts.extend((
            {"title": keyboard_title, "text": keyboard_text},
            {"windowTitle": keyboard_title, "text": keyboard_text},
        ))
    if _runtime._is_vti_image() or _runtime._is_vuplus_box():
        attempts.extend((
            {"text": keyboard_text, "title": keyboard_title},
            {"text": keyboard_text},
        ))
    if _runtime._is_openatv_image() or _runtime._is_open_source_image():
        attempts.extend((
            {"title": keyboard_title, "text": keyboard_text},
            {"title": keyboard_title},
        ))
    attempts.extend((
        {"title": keyboard_title, "text": keyboard_text},
        {"windowTitle": keyboard_title, "text": keyboard_text},
        {"title": keyboard_title},
        {"text": keyboard_text},
        {},
    ))
    for kwargs in attempts:
        try:
            session.openWithCallback(callback, _runtime.VirtualKeyBoard, **kwargs)
            return True
        except Exception as e:
            last_error = e
    if last_error is not None:
        raise last_error
    return False


def _normalize_icon_pack_name(icon_pack):
    _runtime = _get_runtime()

    normalized_pack = _runtime._ensure_text(icon_pack).strip().strip("/\\").replace("\\", "/")
    if not normalized_pack:
        return ""
    return _runtime.ICON_PACK_ALIASES.get(normalized_pack, normalized_pack)


def _icon_pack_has_files(icon_pack):
    _runtime = _get_runtime()

    normalized_pack = _runtime._normalize_icon_pack_name(icon_pack)
    if not normalized_pack:
        return False
    pack_dir = _runtime.os.path.join(_runtime.PLUGIN_ROOT, normalized_pack.replace("/", _runtime.os.sep))
    if not _runtime.os.path.isdir(pack_dir):
        return False
    for root_dir, _dirnames, filenames in _runtime.os.walk(pack_dir):
        for filename in filenames:
            if filename and not filename.startswith("."):
                return True
    return False


def _sanitize_icon_pack(icon_pack):
    _runtime = _get_runtime()

    normalized_pack = _runtime._normalize_icon_pack_name(icon_pack)
    if normalized_pack and _runtime._icon_pack_has_files(normalized_pack):
        return normalized_pack
    return _runtime.DEFAULT_ICON_PACK


def _available_icon_packs(preferred_pack=None):
    _runtime = _get_runtime()

    available_packs = []
    for candidate in (preferred_pack, _runtime.iconpath, _runtime.DEFAULT_ICON_PACK) + _runtime.AVAILABLE_ICON_PACKS:
        if not candidate:
            continue
        candidate = _runtime._normalize_icon_pack_name(candidate)
        if not candidate or candidate in available_packs:
            continue
        if candidate == _runtime.DEFAULT_ICON_PACK or _runtime._icon_pack_has_files(candidate):
            available_packs.append(candidate)
    if _runtime.DEFAULT_ICON_PACK not in available_packs:
        available_packs.insert(0, _runtime.DEFAULT_ICON_PACK)
    return tuple(available_packs)


def _icon_pack_display_name(icon_pack):
    _runtime = _get_runtime()

    display_names = {
        "Images": _runtime._("Default"),
        "Images/Default": _runtime._("Default"),
        "Images/Extra1": _runtime._("Extra1"),
        "Images/Extra2": _runtime._("Extra2"),
        "Images/Extra3": _runtime._("Extra3"),
    }
    return display_names.get(icon_pack, _runtime._ensure_text(_runtime.os.path.basename(icon_pack)).strip() or _runtime._("Default"))


def _icon_pack_choices(preferred_pack=None):
    _runtime = _get_runtime()

    return [(pack, _runtime._icon_pack_display_name(pack)) for pack in _runtime._available_icon_packs(preferred_pack)]


def _icon_pack_candidates(preferred_pack=None):
    _runtime = _get_runtime()

    candidates = []
    for candidate in _runtime._available_icon_packs(preferred_pack):
        if not candidate:
            continue
        candidate = _runtime._normalize_icon_pack_name(candidate)
        if not candidate or candidate in candidates:
            continue
        if _runtime._icon_pack_has_files(candidate):
            candidates.append(candidate)
    return candidates


def _read_saved_icon_pack():
    _runtime = _get_runtime()

    iconpack_lines = _runtime._read_non_empty_lines_with_fallback(_runtime.ICONPACK_FILE, _runtime.LEGACY_ICONPACK_FILES)
    if not iconpack_lines:
        return ""
    return _runtime._sanitize_icon_pack(iconpack_lines[-1])


def _write_saved_icon_pack(icon_pack):
    _runtime = _get_runtime()

    safe_icon_pack = _runtime._sanitize_icon_pack(icon_pack)
    _runtime._write_text_file(_runtime.ICONPACK_FILE, safe_icon_pack)
    return safe_icon_pack


def _skin_needs_legacy_color_cleanup():
    _runtime = _get_runtime()

    image_family = _runtime._runtime_image_family()
    device_family = _runtime._runtime_device_family()
    return image_family in ("dreamos", "vti", "openatv", "open-source") or device_family in ("vuplus", "dreambox")


def _normalize_skin_color_value(color_value):
    _runtime = _get_runtime()

    normalized_color = _runtime._ensure_text(color_value).strip()
    if len(normalized_color) == 9 and normalized_color.startswith("#") and _runtime._skin_needs_legacy_color_cleanup():
        return "#" + normalized_color[-6:]
    return normalized_color


def _plugin_relative_path(path):
    _runtime = _get_runtime()

    normalized_path = _runtime._ensure_text(path).replace("\\", "/").strip()
    if not normalized_path:
        return ""
    prefixes = sorted([_runtime.PLUGIN_SKIN_PREFIX, _runtime.LEGACY_PLUGIN_SKIN_PREFIX], key=len, reverse=True)
    for prefix in prefixes:
        prefix_clean = prefix.rstrip("/")
        if normalized_path.startswith(prefix_clean):
            if len(normalized_path) == len(prefix_clean):
                return ""
            if normalized_path[len(prefix_clean)] == "/":
                return normalized_path[len(prefix_clean) + 1:]
    plugin_prefixes = (
        _runtime.PLUGIN_SKIN_PATH.rstrip("/"),
        _runtime.PLUGIN_ROOT.replace("\\", "/").rstrip("/"),
    )
    for plugin_prefix in plugin_prefixes:
        marker = plugin_prefix + "/"
        if normalized_path.startswith(marker):
            return normalized_path[len(marker):]
    return normalized_path.lstrip("/")


def _plugin_absolute_path(relative_path):
    _runtime = _get_runtime()

    return _runtime.os.path.join(_runtime.PLUGIN_ROOT, relative_path.replace("/", _runtime.os.sep))


def _plugin_skin_path(relative_path):
    _runtime = _get_runtime()

    return _runtime.os.path.join(_runtime.PLUGIN_SKIN_PATH, relative_path).replace("\\", "/")


def _runtime_supports_scaled_pixmaps():
    _runtime = _get_runtime()

    image_family = _runtime._runtime_image_family()
    device_family = _runtime._runtime_device_family()
    return bool(
        device_family in ("dreambox", "vuplus") or
        image_family in ("dreamos", "vti", "openatv", "open-source", "generic-enigma2")
    )


def _asset_directory_candidates(relative_dir):
    _runtime = _get_runtime()

    normalized_dir = _runtime._ensure_text(relative_dir).strip().strip("/")
    if not normalized_dir:
        return []
    parts = [part for part in normalized_dir.split("/") if part]
    if not parts:
        return []
    dir_name = parts[-1]
    dir_prefix = "/".join(parts[:-1])
    canonical_dir = _runtime.LEGACY_ASSET_DIR_TO_CANONICAL.get(dir_name, dir_name)
    family_dirs = list(_runtime.CANONICAL_ASSET_DIR_ALIASES.get(canonical_dir, (dir_name,)))
    ordered_dirs = []
    if _runtime._runtime_supports_scaled_pixmaps() and canonical_dir in family_dirs:
        ordered_dirs.append(canonical_dir)
    if dir_name not in ordered_dirs:
        ordered_dirs.append(dir_name)
    for family_dir in family_dirs:
        if family_dir not in ordered_dirs:
            ordered_dirs.append(family_dir)
    if canonical_dir not in ordered_dirs:
        ordered_dirs.append(canonical_dir)
    candidates = []
    for candidate_dir in ordered_dirs:
        if dir_prefix:
            candidates.append(dir_prefix + "/" + candidate_dir)
        else:
            candidates.append(candidate_dir)
    return candidates


def _background_skin_asset_path(background_value=None, use_fullhd=False):
    _runtime = _get_runtime()

    normalized_background = _runtime._normalize_background_value(background_value, _runtime._configured_background())
    relative_path = "Images/background/backgroundhd+%s.png" % normalized_background
    if use_fullhd:
        stem, ext = _runtime.os.path.splitext(relative_path)
        fhd_relative_path = stem + "_fhd" + ext
        try:
            if _runtime.os.path.exists(_runtime._plugin_absolute_path(fhd_relative_path)):
                return _runtime._plugin_skin_path(fhd_relative_path)
        except Exception:
            pass
    return _runtime._plugin_skin_path(relative_path)


def _png_files_in_dir(relative_dir):
    _runtime = _get_runtime()

    cached_listing = _runtime._PNG_DIR_CACHE.get(relative_dir)
    if cached_listing is None:
        cached_listing = _runtime._png_files_in_dir_uncached(relative_dir)
        _runtime._PNG_DIR_CACHE[relative_dir] = cached_listing
    return list(cached_listing)


def _png_files_in_dir_uncached(relative_dir):
    _runtime = _get_runtime()

    try:
        directory = _runtime._plugin_absolute_path(relative_dir)
        if not _runtime.os.path.isdir(directory):
            return []
        return sorted([
            filename for filename in _runtime.os.listdir(directory)
            if filename and filename.lower().endswith(".png") and _runtime.os.path.isfile(_runtime.os.path.join(directory, filename))
        ])
    except Exception:
        return []


def _fallback_asset_filenames(relative_dir, filename):
    _runtime = _get_runtime()

    relative_dir = _runtime._ensure_text(relative_dir).strip().strip("/")
    dir_name = relative_dir.split("/")[-1] if relative_dir else ""
    filename = _runtime._ensure_text(filename).strip()
    if not filename:
        return []
    stem, ext = _runtime.os.path.splitext(filename)
    ext = ext or ".png"
    candidates = []
    shared_asset_fallbacks = {
        "sunupdownhd": ("sunupdownsd", "a"),
        "sunupdownsd": ("sunupdownhd", "a"),
        "sunpchd": ("sunpcsd", "N"),
        "sunpcsd": ("sunpchd", "N"),
        "rainhd": ("rainsd", "N"),
        "rainsd": ("rainhd", "N"),
        "rhhd": ("rhsd", "N"),
        "rhhd+": ("rhhd", "rhsd", "N"),
        "rhsd": ("rhhd", "N"),
        "turbinehd": ("turbine", "N"),
        "turbine": ("turbinehd", "N"),
        "tempcold": ("tempeven", "temphot", "N"),
        "tempeven": ("tempcold", "temphot", "N"),
        "temphot": ("tempeven", "tempcold", "N"),
    }
    if stem in shared_asset_fallbacks:
        for candidate_stem in shared_asset_fallbacks.get(stem, ()):
            candidates.append(candidate_stem + ext)
    if dir_name in ("icon", "iconhd", "iconbigsd", "iconbighd"):
        candidates.extend(["nodata" + ext, "na" + ext, "a" + ext])
    elif dir_name in ("wind", "windhd", "windbig"):
        candidates.extend(["N" + ext, "NO" + ext])
    elif dir_name in ("lines", "linessd"):
        if stem.startswith("rain_"):
            candidates.append("rain_0" + ext)
        if stem.startswith("b") and stem[1:].lstrip("-").isdigit():
            candidates.append("b0" + ext)
        if stem.lstrip("-").isdigit():
            candidates.append("0" + ext)
        candidates.extend(["bar" + ext, "rdot" + ext, "bdot" + ext])
    elif dir_name == "background":
        candidates.extend(["backgroundhd+1" + ext, "backgroundhd" + ext])
    extra_pngs = _runtime._png_files_in_dir(relative_dir)
    if extra_pngs:
        candidates.append(extra_pngs[0])
    ordered = []
    seen = set()
    for candidate in candidates:
        candidate = _runtime._ensure_text(candidate).strip()
        if candidate and candidate not in seen:
            ordered.append(candidate)
            seen.add(candidate)
    return ordered


def _candidate_asset_relative_paths(relative_path):
    _runtime = _get_runtime()

    normalized_relative = _runtime._plugin_relative_path(relative_path)
    if not normalized_relative:
        return []
    parts = [part for part in normalized_relative.split("/") if part]
    if not parts:
        return []
    candidate_paths = [normalized_relative]
    if len(parts) >= 2:
        pack_name = _runtime._normalize_icon_pack_name(parts[0]) or parts[0]
        relative_inside_pack = "/".join(parts[1:])
        directory_inside_pack = "/".join(parts[1:-1])
        filename = parts[-1]
        pack_candidates = []
        for candidate_pack in (pack_name, _runtime.DEFAULT_ICON_PACK):
            candidate_pack = _runtime._normalize_icon_pack_name(candidate_pack)
            if candidate_pack and candidate_pack not in pack_candidates:
                pack_candidates.append(candidate_pack)
        for candidate_pack in list(_runtime._icon_pack_candidates(pack_name)):
            if candidate_pack and candidate_pack not in pack_candidates:
                pack_candidates.append(candidate_pack)
        for candidate_pack in pack_candidates:
            candidate_dir = candidate_pack
            if directory_inside_pack:
                candidate_dir += "/" + directory_inside_pack
            for resolved_dir in _runtime._asset_directory_candidates(candidate_dir):
                candidate_paths.append(resolved_dir + "/" + filename)
                for fallback_filename in _runtime._fallback_asset_filenames(resolved_dir, filename):
                    candidate_paths.append(resolved_dir + "/" + fallback_filename)
    ordered = []
    seen = set()
    for candidate_path in candidate_paths:
        candidate_path = _runtime._ensure_text(candidate_path).strip().strip("/")
        if candidate_path and candidate_path not in seen:
            ordered.append(candidate_path)
            seen.add(candidate_path)
    return ordered


def _resolve_skin_asset_path(path):
    # Skin text contains hundreds of pixmap paths; the files never change while the plugin runs,
    # so each path is resolved against the file system only once per icon pack.
    _runtime = _get_runtime()

    cache_key = (_runtime._ensure_text(path), _runtime.iconpath)
    resolved = _runtime._ASSET_PATH_CACHE.get(cache_key)
    if resolved is None:
        resolved = _runtime._resolve_skin_asset_path_uncached(path)
        _runtime._ASSET_PATH_CACHE[cache_key] = resolved
    return resolved


def _resolve_skin_asset_path_uncached(path):
    _runtime = _get_runtime()

    normalized_path = _runtime._ensure_text(path).replace("\\", "/")
    relative_candidates = _runtime._candidate_asset_relative_paths(normalized_path)
    for candidate_relative in relative_candidates:
        if _runtime.os.path.exists(_runtime._plugin_absolute_path(candidate_relative)):
            return _runtime._plugin_skin_path(candidate_relative)
    relative_path = _runtime._plugin_relative_path(normalized_path)
    if relative_path and _runtime.os.path.exists(_runtime._plugin_absolute_path(relative_path)):
        return _runtime._plugin_skin_path(relative_path)
    return normalized_path


def _runtime_font_scale():
    _runtime = _get_runtime()

    image_family = _runtime._runtime_image_family()
    device_family = _runtime._runtime_device_family()
    if device_family == "dreambox" or image_family == "dreamos":
        return 0.92
    if image_family == "openatv":
        return 1.10
    if image_family == "open-source":
        return 1.08
    if image_family == "vti":
        return 1.00
    return 1.00


def _scale_font_size_for_runtime(font_size, minimum=10):
    _runtime = _get_runtime()

    try:
        base_size = int(font_size)
    except Exception:
        return font_size
    scaled_size = int(round(float(base_size) * _runtime._runtime_font_scale()))
    if minimum is not None and scaled_size < int(minimum):
        return int(minimum)
    return scaled_size


def _normalize_skin_markup(skin):
    _runtime = _get_runtime()

    skin = _runtime._ensure_text(skin)

    def _replace_pixmap(match):
        return '%s="%s"' % (match.group("attr"), _runtime._resolve_skin_asset_path(match.group("path")))

    def _replace_color(match):
        return '%s="%s"' % (match.group("attr"), _runtime._normalize_skin_color_value(match.group("value")))

    # One skin holds ~450 font and ~430 pixmap tags: what they depend on is decided once per call, not per tag.
    font_choice = {}
    font_sizes = {}
    scaled_pixmaps = _runtime._runtime_supports_scaled_pixmaps()

    def _replace_font(match):
        size_text = match.group("size")
        scaled_size = font_sizes.get(size_text)
        if scaled_size is None:
            scaled_size = font_sizes[size_text] = _runtime._scale_font_size_for_runtime(size_text)
        font_name = match.group("name")
        if font_name == _runtime.DEFAULT_FONT_NAME:
            if "name" not in font_choice:
                font_choice["name"] = _runtime._tw_font_name()
            font_name = font_choice["name"]
        return 'font="%s;%s"' % (font_name, scaled_size)

    def _replace_pixmap_tag(match):
        attrs = match.group("attrs")
        if not scaled_pixmaps:
            return match.group(0)
        if _runtime.re.search(r'\bscale\s*=', attrs, _runtime.re.IGNORECASE):
            return match.group(0)
        return "<%s%s scale=\"1\"%s>" % (match.group("tag"), attrs, match.group("closing"))

    skin = _runtime.SKIN_EMPTY_PIXMAP_PATTERN.sub("", skin)
    skin = _runtime.SKIN_PIXMAP_PATTERN.sub(_replace_pixmap, skin)
    skin = _runtime.SKIN_PIXMAP_TAG_PATTERN.sub(_replace_pixmap_tag, skin)
    skin = _runtime.SKIN_COLOR_PATTERN.sub(_replace_color, skin)
    skin = _runtime.SKIN_FONT_PATTERN.sub(_replace_font, skin)
    return skin.replace("Format:%-H:%M", "Format:%H:%M")


def _apply_skin_path(skin):
    _runtime = _get_runtime()

    return _runtime._normalize_skin_markup(skin)


def _plugin_descriptor_icon():
    # PluginDescriptor icons are most reliable when exposed from the plugin
    # root, while some older layouts still keep the source icon in Images/.
    _runtime = _get_runtime()

    for candidate in _runtime.PLUGIN_DESCRIPTOR_ICON_CANDIDATES:
        try:
            candidate_path = _runtime.os.path.join(_runtime.PLUGIN_ROOT, candidate.replace("/", _runtime.os.sep))
            if _runtime.os.path.isfile(candidate_path):
                return candidate.replace("\\", "/")
        except Exception:
            pass
    return "plugin.png"


def _use_fullhd_layout():
    # Read the desktop size on every call so a resolution change while Enigma2 runs is honoured.
    _runtime = _get_runtime()

    return _runtime.FORCE_FULLHD_LAYOUT or _runtime.safe_get_desktop_width(_runtime.sz_w) > 1800
