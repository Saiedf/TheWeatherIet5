"""Receiver-free regression checks for plugin startup and shared runtime binding."""
from __future__ import print_function, absolute_import

import builtins
import importlib
import sys
import tempfile
import types
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]


def module(name):
    if name in sys.modules:
        return sys.modules[name]
    value = types.ModuleType(name)
    value.__path__ = []
    sys.modules[name] = value
    if "." in name:
        parent, attr = name.rsplit(".", 1)
        setattr(module(parent), attr, value)
    return value


class Widget(object):
    def __init__(self, *args, **kwargs):
        self.args, self.kwargs = args, kwargs


class ConfigItem(object):
    def __init__(self, default=None, choices=None, **kwargs):
        self.value, self.choices = default, choices

    def save(self):
        pass

    def setChoices(self, choices, default=None):
        self.choices = choices


class Descriptor(Widget):
    WHERE_EXTENSIONSMENU = 1
    WHERE_PLUGINMENU = 2
    WHERE_SESSIONSTART = 3


class Screen(dict):
    pass


def receiver_stubs():
    for name, attrs in {
        "Components.Pixmap": {"Pixmap": Widget, "MovingPixmap": Widget},
        "Components.Label": {"Label": Widget},
        "Components.ActionMap": {"ActionMap": Widget, "HelpableActionMap": Widget},
        "Components.ConfigList": {"ConfigListScreen": Widget},
        "Components.MenuList": {"MenuList": Widget},
        "Components.Sources.StaticText": {"StaticText": Widget},
        "Components.MultiContent": {"MultiContentEntryText": lambda **kwargs: kwargs},
        "Components.config": {
            "ConfigSelection": ConfigItem, "ConfigSubsection": types.SimpleNamespace,
            "ConfigText": ConfigItem, "ConfigYesNo": ConfigItem,
            "config": types.SimpleNamespace(plugins=types.SimpleNamespace())},
        "Screens.Screen": {"Screen": Screen},
        "Screens.MessageBox": {"MessageBox": Widget},
        "Screens.VirtualKeyBoard": {"VirtualKeyBoard": Widget},
        "Plugins.Plugin": {"PluginDescriptor": Descriptor},
        "Tools.Directories": {
            "resolveFilename": lambda scope, path: str(ROOT / path), "SCOPE_PLUGINS": 0},
        "enigma": {
            "eTimer": Widget, "ePoint": lambda x, y: (x, y),
            "getDesktop": lambda index: types.SimpleNamespace(
                size=lambda: types.SimpleNamespace(width=lambda: 1280)),
            "RT_HALIGN_LEFT": 0, "RT_HALIGN_RIGHT": 1,
            "eListboxPythonMultiContent": Widget, "gFont": Widget},
    }.items():
        target = module(name)
        for key, value in attrs.items():
            setattr(target, key, value)


class PluginLoadingTests(unittest.TestCase):
    def test_startup_without_relative_self_import(self):
        # Some older loaders cannot import the package's plugin attribute until
        # initialization has completed. Exercise this restriction explicitly.
        for dreambox in (False, True):
            for first in ("plugin", "plugin_ui", "plugin_weather"):
                with self.subTest(dreambox=dreambox, first=first):
                    prefix = "weather_loading_%s_%s" % (dreambox, first)
                    receiver_stubs()
                    pkg = module(prefix)
                    pkg.__path__ = [str(ROOT)]
                    pkg._ = lambda text: text
                    pkg.isDreambox = dreambox
                    with tempfile.TemporaryDirectory(prefix=".weather_loading_", dir=str(ROOT)) as directory:
                        self.assertEqual(Path(directory).resolve().parent, ROOT)
                        utils = importlib.import_module(prefix + ".plugin_utils")
                        utils.THEWEATHERIET5_DATA_DIR = directory
                        utils.THEWEATHERIET5_LOG_FILE = str(Path(directory) / "log.txt")
                        utils._tw_log = lambda *args: None
                        utils._is_dreambox_image = lambda: dreambox
                        utils._is_openatv_image = lambda: not dreambox
                        utils._is_open_source_image = lambda: not dreambox
                        original_import = builtins.__import__
                        blocked = []

                        def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
                            if level == 1 and name == "" and "plugin" in (fromlist or ()):
                                caller = (globals or {}).get("__package__", "")
                                if caller == prefix:
                                    plugin = sys.modules.get(prefix + ".plugin")
                                    spec = getattr(plugin, "__spec__", None)
                                    if plugin is not None and getattr(spec, "_initializing", False):
                                        blocked.append(caller)
                                        raise ImportError("cannot import name plugin")
                            return original_import(name, globals, locals, fromlist, level)

                        builtins.__import__ = guarded_import
                        try:
                            importlib.import_module(prefix + "." + first)
                            plugin = importlib.import_module(prefix + ".plugin")
                        finally:
                            builtins.__import__ = original_import
                        self.assertEqual(blocked, [])
                        ui = importlib.import_module(prefix + ".plugin_ui")
                        weather = importlib.import_module(prefix + ".plugin_weather")
                        self.assertIs(ui._get_runtime(), plugin)
                        self.assertIs(weather._get_runtime(), plugin)
                        self.assertEqual(plugin.safe_get_desktop_width(), 1280)
                        self.assertEqual(plugin._normalize_icon_pack_name("Default"), "Images")
                        self.assertEqual(plugin._normalized_weather_service_value("msn"), "msn")
                        descriptors = plugin.Plugins(str(ROOT))
                        self.assertEqual(len(descriptors), 2)
                        self.assertIs(descriptors[0].kwargs["fnc"], plugin.main)
                        self.assertIs(descriptors[1].kwargs["fnc"], plugin.sessionstart)
                        plugin._bind_screen_runtime()
                        screens = importlib.import_module(prefix + ".plugin_screens")
                        self.assertIs(screens._move_pixmap, plugin._move_pixmap)
                        plugin.weatherData = {"provider": "msn", "days": []}
                        plugin._bind_screen_runtime()
                        self.assertIs(screens.weatherData, plugin.weatherData)
                        context = plugin._weather_request_context()
                        plugin._invalidate_weather_requests(context)
                        self.assertFalse(plugin._weather_request_current(context))

    def test_late_helper_binding_uses_registered_module(self):
        # Cover direct helper use while the plugin is already registered, without
        # requiring the parent package's plugin attribute to exist yet.
        for helper in ("plugin_ui", "plugin_weather"):
            with self.subTest(helper=helper):
                prefix = "weather_late_binding_" + helper
                pkg = module(prefix)
                pkg.__path__ = [str(ROOT)]
                registered = types.ModuleType(prefix + ".plugin")
                sys.modules[registered.__name__] = registered
                imported = importlib.import_module(prefix + "." + helper)
                self.assertIs(imported._get_runtime(), registered)


if __name__ == "__main__":
    unittest.main(verbosity=2)
