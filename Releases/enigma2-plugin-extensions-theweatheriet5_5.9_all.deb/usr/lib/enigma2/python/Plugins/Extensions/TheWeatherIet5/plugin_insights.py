# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function and absolute_import are required for Python 2.7 and 3.x
from __future__ import print_function, absolute_import

# Smart summary + local learning for TheWeatherIet5.
# - Learning: remembers what was forecast for tomorrow, later compares it with what really
#   happened (Open-Meteo "past_days=1" values) and keeps the typical error of this location.
#   The learned error is only REPORTED; the temperatures shown on the screens are never altered.
# - Summary: a few short rule based lines (tomorrow, wind, rain, hottest day, accuracy).
# No third-party libraries; works on Python 2.7 and 3.x; all network work runs in a thread.

import json
import os
import threading
import time
import datetime
try:
    import _strptime  # loaded up front: strptime is not thread-safe on its first use in Python 2
except ImportError:
    _strptime = None

from . import _
from .plugin_utils import (
    _round_half_up,
    THEWEATHERIET5_DATA_DIR,
    _ensure_text,
    _format_speed_text,
    _format_temperature_text,
    _is_plausible_temperature,
    _location_compare_key,
    _parse_precise_location,
    _read_json_url,
    _start_background_thread,
    _tw_cfg,
    _tw_convert_temp,
    _tw_log,
    _tw_temp_suffix,
    _tw_temp_unit,
    _write_text_file,
)
from .weather_display import _format_day_summary_label

LEARNING_FILE = os.path.join(THEWEATHERIET5_DATA_DIR, "theweatheriet5_learning.json")
MAX_LOCATIONS = 12
MAX_ERROR_RECORDS = 30
MIN_RECORDS_FOR_INSIGHT = 3
ACTUAL_TIMEOUT = 10
ACTUAL_URL = (
    "https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&"
    "daily=temperature_2m_max,temperature_2m_min&timezone=auto&past_days=1&forecast_days=1"
)

_FILE_LOCK = threading.Lock()
_WORKER_LOCK = threading.Lock()
_worker_running = [False]


def smart_info_enabled():
    return bool(_tw_cfg("smartinfo", True))


def _float_or_none(value):
    try:
        number = float(value)
    except Exception:
        return None
    return number if _is_plausible_temperature(number) else None


def _date_plus(date_text, days):
    parsed = datetime.datetime.strptime(_ensure_text(date_text)[:10], "%Y-%m-%d")
    return (parsed + datetime.timedelta(days=int(days))).strftime("%Y-%m-%d")


def _today_text(utc_offset_seconds):
    try:
        if utc_offset_seconds is not None:
            return time.strftime("%Y-%m-%d", time.gmtime(time.time() + int(utc_offset_seconds)))
    except Exception:
        pass
    return time.strftime("%Y-%m-%d")


def _load_store():
    try:
        if os.path.exists(LEARNING_FILE):
            with open(LEARNING_FILE, "rb") as handle:
                store = json.loads(_ensure_text(handle.read()))
            if isinstance(store, dict) and isinstance(store.get("locations"), dict):
                # Ignore malformed individual entries without losing other cities.
                store["locations"] = dict((key, value) for key, value in store["locations"].items()
                                          if isinstance(value, dict))
                return store
    except Exception as e:
        _tw_log("Learning file ignored (unreadable): %s" % str(e))
    return {"version": 1, "locations": {}}


def _save_store(store):
    def _updated_at(item):
        try:
            return int(item[1].get("updated", 0))
        except (TypeError, ValueError, OverflowError):
            return 0

    locations = store.get("locations", {})
    if len(locations) > MAX_LOCATIONS:
        ordered = sorted(locations.items(), key=_updated_at, reverse=True)
        store["locations"] = dict(ordered[:MAX_LOCATIONS])
    try:
        _write_text_file(LEARNING_FILE, json.dumps(store))
    except Exception as e:
        _tw_log("Learning file could not be saved: %s" % str(e))


def _entry_for(store, location):
    key = _location_compare_key(location)
    entry = store["locations"].setdefault(key, {"pending": {}, "errors": [], "last_check": "", "updated": 0})
    entry.setdefault("pending", {})
    entry.setdefault("errors", [])
    if not isinstance(entry["pending"], dict):
        entry["pending"] = {}
    if not isinstance(entry["errors"], list):
        entry["errors"] = []
    entry["errors"] = [record for record in entry["errors"] if isinstance(record, dict)][-MAX_ERROR_RECORDS:]
    return entry


def snapshot_payload(payload):
    # Plain copy of what the learning code needs, taken on the calling thread so that later
    # changes to the live payload cannot affect the worker.
    days = []
    if isinstance(payload, dict):
        for day in list(payload.get("days") or [])[:3]:
            if isinstance(day, dict):
                days.append((_ensure_text(day.get("date", ""))[:10], day.get("maxtemperature"), day.get("mintemperature")))
        return {"days": days, "offset": payload.get("utc_offset_seconds")}
    return {"days": days, "offset": None}


def _fetch_actual(latitude, longitude):
    url = ACTUAL_URL.format(lat=latitude, lon=longitude)
    data = _read_json_url(url, ACTUAL_TIMEOUT)
    daily = (data or {}).get("daily") or {}
    dates = daily.get("time") or []
    highs = daily.get("temperature_2m_max") or []
    lows = daily.get("temperature_2m_min") or []
    if not dates or not highs or not lows:
        return None
    high = _float_or_none(highs[0])
    low = _float_or_none(lows[0])
    if high is None or low is None:
        return None
    return _ensure_text(dates[0])[:10], high, low


def _learn(location, snapshot):
    latitude, longitude, _label = _parse_precise_location(location)
    days = snapshot.get("days") or []
    if latitude is None or longitude is None or len(days) < 2:
        return
    today = _today_text(snapshot.get("offset"))
    tomorrow = _date_plus(today, 1)
    yesterday = _date_plus(today, -1)

    with _FILE_LOCK:
        store = _load_store()
        entry = _entry_for(store, location)
        entry["pending"] = dict((date_text, values) for date_text, values in entry["pending"].items()
                                if yesterday <= date_text <= tomorrow and isinstance(values, dict))
        for date_text, high, low in days:
            high = _float_or_none(high)
            low = _float_or_none(low)
            if date_text == tomorrow and high is not None and low is not None:
                entry["pending"][tomorrow] = {"max": high, "min": low, "made": today}
        pending_yesterday = entry["pending"].get(yesterday)
        need_actual = bool(pending_yesterday) and entry.get("last_check") != today
        entry["updated"] = int(time.time())
        _save_store(store)

    if not need_actual:
        return
    actual = _fetch_actual(latitude, longitude)
    if actual is None or actual[0] != yesterday:
        return

    with _FILE_LOCK:
        store = _load_store()
        entry = _entry_for(store, location)
        pending = entry["pending"].get(yesterday)
        if pending:
            try:
                lead = (datetime.datetime.strptime(yesterday, "%Y-%m-%d") -
                        datetime.datetime.strptime(pending.get("made", yesterday), "%Y-%m-%d")).days
            except Exception:
                lead = 1
            if 1 <= lead <= 2:
                entry["errors"].append({
                    "date": yesterday,
                    "emax": round(float(pending["max"]) - actual[1], 2),
                    "emin": round(float(pending["min"]) - actual[2], 2),
                })
                entry["errors"] = entry["errors"][-MAX_ERROR_RECORDS:]
        for date_text in list(entry["pending"].keys()):
            if date_text < yesterday:
                del entry["pending"][date_text]
        entry["last_check"] = today
        entry["updated"] = int(time.time())
        _save_store(store)
        _tw_log("Learning updated for %s (%d records)" % (_ensure_text(location), len(entry["errors"])))


def _learning_worker(location, snapshot):
    try:
        _learn(location, snapshot)
    except Exception as e:
        _tw_log("Learning update failed: %s" % str(e))
    finally:
        _worker_running[0] = False


def schedule_learning_update(location, payload):
    # Called after a successful live download; never blocks and never raises.
    try:
        if not smart_info_enabled():
            return False
        with _WORKER_LOCK:
            if _worker_running[0]:
                return False
            _worker_running[0] = True
        if _start_background_thread(_learning_worker, (location, snapshot_payload(payload))) is None:
            _worker_running[0] = False
            return False
        return True
    except Exception as e:
        _worker_running[0] = False
        _tw_log("Learning scheduling failed: %s" % str(e))
        return False


def get_insight(location):
    # {"n": records, "mae": mean absolute error, "bias": mean (forecast - actual)} or None.
    try:
        with _FILE_LOCK:
            store = _load_store()
        entry = store["locations"].get(_location_compare_key(location))
        errors = list((entry or {}).get("errors") or [])
        if len(errors) < MIN_RECORDS_FOR_INSIGHT:
            return None
        values = []
        for record in errors:
            values.append(float(record.get("emax", 0)))
            values.append(float(record.get("emin", 0)))
        return {
            "n": len(errors),
            "mae": sum(abs(v) for v in values) / len(values),
            "bias": sum(values) / len(values),
        }
    except Exception as e:
        _tw_log("Learning insight unavailable: %s" % str(e))
        return None


def _temp_text(celsius_value):
    return _ensure_text(_format_temperature_text(_tw_convert_temp(celsius_value), 0, "--")) + _ensure_text(_tw_temp_suffix())


def _delta_text(celsius_delta):
    # Temperature DIFFERENCES scale by 9/5 only (no +32 offset) when Fahrenheit is selected.
    factor = 1.8 if _tw_temp_unit() == "Fahrenheit" else 1.0
    return _ensure_text(_round_half_up(abs(celsius_delta) * factor)) + _ensure_text(_tw_temp_suffix())


def build_summary_lines(payload, location=None):
    lines = []
    days = list((payload or {}).get("days") or []) if isinstance(payload, dict) else []
    if len(days) < 2:
        return lines
    today = days[0]
    tomorrow = days[1]
    high_today = _float_or_none(today.get("maxtemperature"))
    high_tomorrow = _float_or_none(tomorrow.get("maxtemperature"))
    low_tomorrow = _float_or_none(tomorrow.get("mintemperature"))
    if high_tomorrow is None or low_tomorrow is None:
        return lines

    lines.append(_ensure_text(_("Tomorrow: %(high)s / %(low)s")) % {
        "high": _temp_text(high_tomorrow), "low": _temp_text(low_tomorrow)})
    if high_today is not None:
        delta = high_tomorrow - high_today
        if delta >= 2:
            lines.append(_ensure_text(_("%(n)s warmer than today")) % {"n": _delta_text(delta)})
        elif delta <= -2:
            lines.append(_ensure_text(_("%(n)s cooler than today")) % {"n": _delta_text(delta)})
        else:
            lines.append(_ensure_text(_("Similar to today")))

    try:
        wind = float(tomorrow.get("windspeed"))
    except Exception:
        wind = None
    if wind is not None:
        if wind >= 40:
            wind_label = _("Strong wind")
        elif wind >= 25:
            wind_label = _("Breezy")
        else:
            wind_label = _("Light wind")
        lines.append(_ensure_text(wind_label) + u" - " + _ensure_text(_format_speed_text(wind, "")))

    try:
        rain = float(tomorrow.get("precipitationmm"))
    except Exception:
        rain = None
    if rain is not None:
        if rain >= 5:
            lines.append(_ensure_text(_("Rain expected")))
        elif rain >= 0.5:
            lines.append(_ensure_text(_("Chance of light rain")))
        else:
            lines.append(_ensure_text(_("No rain expected")))

    hottest = None
    for day in days[:7]:
        high = _float_or_none(day.get("maxtemperature"))
        if high is not None and (hottest is None or high > hottest[0]):
            hottest = (high, day)
    if hottest is not None:
        lines.append(_ensure_text(_("Hottest: %(day)s %(t)s")) % {
            "day": _ensure_text(_format_day_summary_label(hottest[1])), "t": _temp_text(hottest[0])})

    insight = get_insight(location) if location else None
    if insight is not None:
        unit_factor = 1.8 if _tw_temp_unit() == "Fahrenheit" else 1.0
        error_text = "%.1f" % (insight["mae"] * unit_factor)
        lines.append(_ensure_text(_("Forecast error here: about %(e)s")) % {
            "e": _ensure_text(error_text) + _ensure_text(_tw_temp_suffix())})
        if abs(insight["bias"]) >= 1.0:
            bias_text = "%.1f" % (abs(insight["bias"]) * unit_factor)
            if insight["bias"] > 0:
                lines.append(_ensure_text(_("Forecasts ran %(b)s too warm")) % {"b": _ensure_text(bias_text) + _ensure_text(_tw_temp_suffix())})
            else:
                lines.append(_ensure_text(_("Forecasts ran %(b)s too cold")) % {"b": _ensure_text(bias_text) + _ensure_text(_tw_temp_suffix())})
    return lines


def get_summary_text(payload, location=None):
    if not smart_info_enabled():
        return u""
    try:
        return u"\n".join(build_summary_lines(payload, location))
    except Exception as e:
        _tw_log("Smart summary failed: %s" % str(e))
        return u""
