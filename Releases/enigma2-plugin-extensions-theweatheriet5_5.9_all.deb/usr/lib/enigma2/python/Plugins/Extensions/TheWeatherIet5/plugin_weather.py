# -*- coding: utf-8 -*-
"""Forecast validation, weather requests and cache management.

Runtime state remains in plugin.py and is resolved when each function runs.
This preserves shared locks, current settings and existing plugin imports.
"""
from __future__ import print_function, absolute_import


_RUNTIME = None


def _bind_runtime(runtime):
    """Bind the authoritative plugin module before startup calls any helpers."""
    global _RUNTIME
    _RUNTIME = runtime


def _get_runtime():
    """Use the bound module without importing plugin.py while it initializes."""
    if _RUNTIME is None:
        import sys
        runtime = sys.modules.get(__name__.rsplit(".", 1)[0] + ".plugin")
        if runtime is None:
            from . import plugin as runtime
        _bind_runtime(runtime)
    return _RUNTIME


def _normalized_weather_service_value(service_name=None):
    _runtime = _get_runtime()

    requested_service = _runtime._ensure_text(service_name if service_name is not None else _runtime._tw_cfg("weatherservice", _runtime.DEFAULT_WEATHER_SERVICE)).strip().lower()
    valid_values = [choice[0] for choice in _runtime.WEATHER_SERVICE_CHOICES]
    if requested_service in valid_values:
        return requested_service
    return _runtime.DEFAULT_WEATHER_SERVICE


def _legacy_cache_location_key(location_name):
    _runtime = _get_runtime()

    normalized_location = _runtime._normalize_location_input(location_name)
    return _runtime.hashlib.md5(_runtime._ensure_binary(normalized_location)).hexdigest()


def _cache_location_key(location_name, service_name=None):
    _runtime = _get_runtime()

    normalized_location = _runtime._normalize_location_input(location_name)
    normalized_service = _runtime._normalized_weather_service_value(service_name)
    return _runtime.hashlib.md5(_runtime._ensure_binary("%s|%s" % (normalized_service, normalized_location))).hexdigest()


def _get_weather_cache_file(location_name, service_name=None):
    _runtime = _get_runtime()

    return _runtime.os.path.join(_runtime.WEATHER_CACHE_DIR, "theweatheriet5_" + _runtime._cache_location_key(location_name, service_name) + ".json")


def _get_legacy_current_cache_file(location_name):
    _runtime = _get_runtime()

    return _runtime.os.path.join(_runtime.WEATHER_CACHE_DIR, "theweatheriet5_" + _runtime._legacy_cache_location_key(location_name) + ".json")


def _get_weather_cache_candidates(location_name, service_name=None, include_all_services=False):
    _runtime = _get_runtime()

    candidates = []
    if include_all_services:
        for weather_service_value, _weather_service_label in _runtime.WEATHER_SERVICE_CHOICES:
            specific_cache = _runtime._get_weather_cache_file(location_name, weather_service_value)
            if specific_cache and specific_cache not in candidates:
                candidates.append(specific_cache)
    else:
        specific_cache = _runtime._get_weather_cache_file(location_name, service_name)
        if specific_cache:
            candidates.append(specific_cache)
    legacy_current_cache = _runtime._get_legacy_current_cache_file(location_name)
    if legacy_current_cache not in candidates:
        candidates.append(legacy_current_cache)
    cache_key = _runtime._legacy_cache_location_key(location_name)
    for legacy_dir in _runtime.LEGACY_WEATHER_CACHE_DIRS:
        if legacy_dir:
            legacy_file = _runtime.os.path.join(legacy_dir, cache_key + ".json")
            if legacy_file not in candidates:
                candidates.append(legacy_file)
    # Keep the legacy shared cache only as a read-only migration fallback.
    # Runtime writes now stay separated per provider and per location.
    if _runtime.os.path.exists(_runtime.DEFAULT_WEATHER_CACHE_FILE) and _runtime.DEFAULT_WEATHER_CACHE_FILE not in candidates:
        candidates.append(_runtime.DEFAULT_WEATHER_CACHE_FILE)
    return candidates


def _remove_file_quietly(path):
    _runtime = _get_runtime()

    try:
        if path and _runtime.os.path.exists(path):
            _runtime.os.remove(path)
            return True
    except Exception:
        pass
    return False


def _cache_file_matches_location(cache_file, location_name):
    _runtime = _get_runtime()

    try:
        if not cache_file or not _runtime.os.path.exists(cache_file):
            return False
        with open(cache_file, "rb") as handle:
            payload = _runtime.json.loads(_runtime._ensure_text(handle.read()))
        payload_location = _runtime._canonicalize_embedded_default_location(payload.get("location", ""))
        return bool(payload_location and _runtime._location_compare_key(payload_location) == _runtime._location_compare_key(location_name))
    except Exception:
        return False


def _purge_location_from_config_storage(location_name, replacement_location=None):
    _runtime = _get_runtime()

    target_location = _runtime._canonicalize_embedded_default_location(location_name)
    replacement_location = _runtime._canonicalize_embedded_default_location(replacement_location)
    if not target_location:
        return False

    target_key = _runtime._location_compare_key(target_location)
    changed = False

    try:
        current_locations = []
        for saved_location in _runtime._read_non_empty_lines(_runtime.LOCATIONS_FILE):
            normalized_location = _runtime._canonicalize_embedded_default_location(saved_location)
            if not normalized_location or _runtime._location_compare_key(normalized_location) == target_key:
                changed = True
                continue
            current_locations.append(normalized_location)
        _runtime._write_non_empty_lines(_runtime.LOCATIONS_FILE, current_locations)
    except Exception:
        pass

    try:
        last_locations = _runtime._read_non_empty_lines(_runtime.LAST_LOCATION_FILE)
        last_location = _runtime._canonicalize_embedded_default_location(last_locations[-1]) if last_locations else ""
        if last_location and _runtime._location_compare_key(last_location) == target_key:
            _runtime._write_text_file(_runtime.LAST_LOCATION_FILE, replacement_location or "")
            changed = True
    except Exception:
        pass

    try:
        settings_map = _runtime._read_saved_settings_map()
        saved_weather_location = _runtime._canonicalize_embedded_default_location(settings_map.get("weatherlocation", ""))
        if saved_weather_location and _runtime._location_compare_key(saved_weather_location) == target_key:
            settings_map["weatherlocation"] = replacement_location or ""
            _runtime._write_saved_settings_map(settings_map)
            changed = True
    except Exception:
        pass

    try:
        configured_location = _runtime._configured_weather_location()
        if configured_location and _runtime._location_compare_key(configured_location) == target_key:
            _runtime._tw_set_cfg("weatherlocation", replacement_location or "")
            changed = True
    except Exception:
        pass

    try:
        for cache_file in _runtime._get_weather_cache_candidates(target_location, include_all_services=True):
            if cache_file == _runtime.DEFAULT_WEATHER_CACHE_FILE:
                if _runtime._cache_file_matches_location(cache_file, target_location):
                    if _runtime._remove_file_quietly(cache_file):
                        changed = True
                continue
            if _runtime._remove_file_quietly(cache_file):
                changed = True
    except Exception:
        pass

    if changed:
        try:
            _runtime._persist_runtime_settings()
        except Exception:
            pass
        try:
            _runtime._tw_log("Purged location from config storage: %s" % str(target_location))
        except Exception:
            pass
    return changed


def _forecast_payload_provider(payload=None, service_name=None):
    _runtime = _get_runtime()

    provider_name = service_name
    if isinstance(payload, dict):
        provider_name = payload.get("provider", payload.get("service", provider_name))
    return _runtime._normalized_weather_service_value(provider_name)


def _forecast_expected_day_count(payload=None, service_name=None):
    _runtime = _get_runtime()

    try:
        provider_name = _runtime._forecast_payload_provider(payload, service_name)
        expected_days = int(_runtime.WEATHER_SERVICE_DAY_LIMITS.get(provider_name, _runtime.FORECAST_DAYS))
    except Exception:
        expected_days = int(_runtime.FORECAST_DAYS)
    if isinstance(payload, dict):
        for payload_key in ("screen_days", "forecast_days"):
            try:
                payload_days = int(payload.get(payload_key, 0) or 0)
            except Exception:
                payload_days = 0
            if payload_days > 0:
                expected_days = min(expected_days, payload_days)
                break
        try:
            days = payload.get("days")
            if isinstance(days, list) and days:
                expected_days = min(expected_days, len(days))
        except Exception:
            pass
    if expected_days <= 0:
        expected_days = int(_runtime.FORECAST_DAYS)
    return expected_days


def _forecast_date_key(day_data):
    _runtime = _get_runtime()

    if not isinstance(day_data, dict):
        return ""
    date_text = _runtime._ensure_text(day_data.get("date", "")).strip()
    if len(date_text) >= 10:
        return date_text[:10]
    return date_text


def _forecast_rounded_temperature(value):
    _runtime = _get_runtime()

    try:
        if not _runtime._is_plausible_temperature(value):
            return None
        return _runtime._round_half_up(value)
    except Exception:
        return None


def _forecast_temperature_pair(day_data):
    _runtime = _get_runtime()

    if not isinstance(day_data, dict):
        return None
    max_temp = _runtime._forecast_rounded_temperature(day_data.get("maxtemperature"))
    min_temp = _runtime._forecast_rounded_temperature(day_data.get("mintemperature"))
    if max_temp is None or min_temp is None:
        return None
    return (max_temp, min_temp)


def _forecast_temperature_map(payload, limit=None):
    _runtime = _get_runtime()

    result = {}
    if not isinstance(payload, dict):
        return result
    days = payload.get("days")
    if not isinstance(days, list):
        return result
    if limit is None:
        limit = len(days)
    for day_data in list(days or [])[:int(limit or 0)]:
        date_key = _runtime._forecast_date_key(day_data)
        temp_pair = _runtime._forecast_temperature_pair(day_data)
        if date_key and temp_pair is not None:
            result[date_key] = temp_pair
    return result


def _forecast_payload_temperatures_ready(payload, service_name=None):
    _runtime = _get_runtime()

    if not isinstance(payload, dict):
        return False, "payload-not-dict"
    days = payload.get("days")
    if not isinstance(days, list):
        return False, "days-not-list"
    expected_days = _runtime._forecast_expected_day_count(payload, service_name)
    if len(days) < expected_days:
        return False, "only-%s-days-required-%s" % (str(len(days)), str(expected_days))
    previous_date = None
    for index in range(0, expected_days):
        day_data = days[index]
        date_key = _runtime._forecast_date_key(day_data)
        temp_pair = _runtime._forecast_temperature_pair(day_data)
        if not date_key:
            return False, "missing-date-at-%s" % str(index)
        if temp_pair is None:
            return False, "missing-temp-at-%s-%s" % (str(index), str(date_key))
        if float(day_data["mintemperature"]) > float(day_data["maxtemperature"]):
            return False, "inverted-temperature-range-at-%s" % str(index)
        try:
            parsed_date = _runtime.datetime.date(int(date_key[:4]), int(date_key[5:7]), int(date_key[8:10]))
        except Exception:
            return False, "invalid-date-at-%s" % str(index)
        if previous_date is not None and parsed_date != previous_date + _runtime.datetime.timedelta(days=1):
            return False, "nonconsecutive-date-at-%s" % str(index)
        previous_date = parsed_date
    return True, ""


def _forecast_payload_ready_for_apply(payload, service_name=None):
    _runtime = _get_runtime()

    expected_days = _runtime._forecast_expected_day_count(payload, service_name)
    min_main_days = min(7, max(5, expected_days))
    if not _runtime._weather_payload_ready(payload, min_main_days):
        return False, "main-screen-data-incomplete"
    return _runtime._forecast_payload_temperatures_ready(payload, service_name)


def _current_weather_matches_location(location_name):
    _runtime = _get_runtime()

    try:
        # "localCity" is the *selected* city and changes before its data is downloaded, so the
        # city that the stored forecast really belongs to is tracked separately.
        if not _runtime._weatherDataLocation or not location_name:
            return False
        return _runtime._location_compare_key(_runtime._weatherDataLocation) == _runtime._location_compare_key(location_name)
    except Exception:
        return False


def _log_forecast_payload_apply(location_name, payload, source_name):
    _runtime = _get_runtime()

    try:
        days = list((payload or {}).get("days") or [])
        provider_name = _runtime._forecast_payload_provider(payload)
        first_day = _runtime._forecast_date_key(days[0]) if days else ""
        last_day = _runtime._forecast_date_key(days[-1]) if days else ""
        _runtime._tw_log(
            "Forecast payload applied source=%s provider=%s location=%s days=%s first=%s last=%s runtime=%s/%s" %
            (
                _runtime._ensure_text(source_name or "unknown"),
                provider_name,
                _runtime._ensure_text(location_name),
                str(len(days)),
                first_day,
                last_day,
                _runtime._runtime_device_family(),
                _runtime._runtime_image_family(),
            )
        )
    except Exception:
        pass


def _log_forecast_temperature_changes(location_name, old_payload, new_payload, source_name):
    _runtime = _get_runtime()

    try:
        if not isinstance(old_payload, dict) or not isinstance(new_payload, dict):
            return
        if not _runtime._current_weather_matches_location(location_name):
            return
        provider_name = _runtime._forecast_payload_provider(new_payload)
        expected_days = _runtime._forecast_expected_day_count(new_payload, provider_name)
        old_map = _runtime._forecast_temperature_map(old_payload, expected_days)
        new_map = _runtime._forecast_temperature_map(new_payload, expected_days)
        for date_key in sorted(new_map.keys()):
            if date_key not in old_map:
                continue
            old_pair = old_map.get(date_key)
            new_pair = new_map.get(date_key)
            if old_pair == new_pair:
                continue
            _runtime._tw_log(
                "Forecast date temperature changed source=%s provider=%s location=%s date=%s max/min %s/%s -> %s/%s" %
                (
                    _runtime._ensure_text(source_name or "unknown"),
                    provider_name,
                    _runtime._ensure_text(location_name),
                    date_key,
                    str(old_pair[0]),
                    str(old_pair[1]),
                    str(new_pair[0]),
                    str(new_pair[1]),
                )
            )
    except Exception as e:
        _runtime._tw_log("Forecast temperature comparison error: %s" % str(e))


def _format_last_update_label():
    # Time of the data in the cache/live fetch; the date is added when it is not today and the
    # label says "cached" whenever the forecast came from disk instead of a fresh download.
    _runtime = _get_runtime()

    try:
        stamp = int(_runtime._lastUpdateEpoch or _runtime.time.time())
    except Exception:
        stamp = int(_runtime.time.time())
    stamp_time = _runtime.time.localtime(stamp)
    label = _runtime.time.strftime("%I:%M %p", stamp_time).upper()
    if _runtime.time.strftime("%Y%m%d", stamp_time) != _runtime.time.strftime("%Y%m%d"):
        label = _runtime.time.strftime("%d/%m ", stamp_time) + label
    if _runtime.lastUpdateIsCached and (_runtime.time.time() - stamp) >= _runtime.OPEN_REFRESH_MIN_INTERVAL:
        label += " (" + _runtime._("cached") + ")"
    return label


def _location_today_text(payload):
    # ISO date of "today" at the forecast location (UTC offset when the provider supplied it).
    _runtime = _get_runtime()

    try:
        offset = payload.get("utc_offset_seconds") if isinstance(payload, dict) else None
        if offset is not None:
            return _runtime.time.strftime("%Y-%m-%d", _runtime.time.gmtime(_runtime.time.time() + int(offset)))
    except Exception:
        pass
    return _runtime.time.strftime("%Y-%m-%d")


def _prepare_cached_payload(data, timestamp=0):
    # A cached forecast must never pretend that its first day is today: drop days that are
    # already in the past and drop "current" readings that no longer describe the present.
    _runtime = _get_runtime()

    try:
        days = data.get("days")
        if not isinstance(days, list):
            return data
        today_text = _runtime._location_today_text(data)
        kept_days = [day for day in days if isinstance(day, dict) and _runtime._forecast_date_key(day) >= today_text]
        trimmed = len(kept_days) != len(days)
        if trimmed:
            data["days"] = kept_days
            data["forecast_days"] = len(kept_days)
            data["screen_days"] = len(kept_days)
        age = int(_runtime.time.time()) - int(timestamp or 0) if timestamp else None
        if kept_days and (trimmed or age is None or age > _runtime.CACHED_CURRENT_TEMPERATURE_MAX_AGE):
            for stale_key in ("temperature", "currenttemperature", "currentfeeltemperature"):
                kept_days[0].pop(stale_key, None)
    except Exception as e:
        _runtime._tw_log("Cached payload preparation error: %s" % str(e))
    return data


def _weather_request_context():
    _runtime = _get_runtime()

    with _runtime._STATE_LOCK:
        return (_runtime._LOCATION_GENERATION[0], _runtime._normalized_weather_service_value())


def _weather_request_current(context):
    _runtime = _get_runtime()

    return context is None or context == _runtime._weather_request_context()


def _invalidate_weather_requests(context):
    _runtime = _get_runtime()

    with _runtime._STATE_LOCK:
        if _runtime._weather_request_current(context):
            _runtime._LOCATION_GENERATION[0] += 1


def _apply_weather_payload(location_name, data, display_name, source_name="unknown", update_timestamp=None, request_context=None):
    _runtime = _get_runtime()

    ready, reason = _runtime._forecast_payload_ready_for_apply(data)
    if not ready:
        _runtime._tw_log(
            "Forecast payload rejected source=%s location=%s reason=%s" %
            (_runtime._ensure_text(source_name or "unknown"), _runtime._ensure_text(location_name), _runtime._ensure_text(reason))
        )
        return False
    previous_payload = _runtime.weatherData if isinstance(_runtime.weatherData, dict) else None
    try:
        for day_data in list((data or {}).get("days") or []):
            if not isinstance(day_data, dict):
                continue
            day_icon = _runtime._ensure_text(day_data.get("iconcode", "")).strip().lower()
            if day_icon in ("a", "j", "n"):
                day_data["iconcode"] = "a"
            elif day_icon in ("aa", "jj", "nn"):
                day_data["iconcode"] = "aa"
            for hour_data in list(day_data.get("hours") or []):
                if not isinstance(hour_data, dict):
                    continue
                hour_icon = _runtime._ensure_text(hour_data.get("iconcode", "")).strip().lower()
                if hour_icon in ("a", "j", "n"):
                    hour_data["iconcode"] = "a"
                elif hour_icon in ("aa", "jj", "nn"):
                    hour_data["iconcode"] = "aa"
    except Exception:
        pass
    _runtime._log_forecast_temperature_changes(location_name, previous_payload, data, source_name)
    with _runtime._STATE_LOCK:
        if not _runtime._weather_request_current(request_context):
            _runtime._tw_log("Discarded weather response after location/provider changed")
            return False
        _runtime.weatherData = data
        _runtime.localCity = _runtime._normalize_location_input(location_name)
        _runtime._weatherDataLocation = _runtime.localCity
        _runtime.cityNameDisplay = _runtime._ensure_text(display_name or location_name)
        try:
            _runtime._lastUpdateEpoch = int(update_timestamp) if update_timestamp else int(_runtime.time.time())
        except Exception:
            _runtime._lastUpdateEpoch = int(_runtime.time.time())
        _runtime.lastUpdateIsCached = (source_name == "cache")
        _runtime.lastUpdateTime = _runtime._format_last_update_label()
    _runtime._log_forecast_payload_apply(location_name, data, source_name)
    return True


def _get_weather_days(payload=None):
    _runtime = _get_runtime()

    if payload is None:
        payload = _runtime.weatherData
    if not isinstance(payload, dict):
        return []
    days = payload.get("days")
    if not isinstance(days, list):
        return []
    return days


def _day_payload_ready(day_data):
    _runtime = _get_runtime()

    if not isinstance(day_data, dict):
        return False
    if day_data.get("maxtemperature") is None or day_data.get("mintemperature") is None:
        return False
    if not _runtime._ensure_text(day_data.get("iconcode", "")).strip():
        return False
    if not _runtime._ensure_text(day_data.get("sunrise", "")).strip():
        return False
    if not _runtime._ensure_text(day_data.get("sunset", "")).strip():
        return False
    hours = day_data.get("hours")
    if not isinstance(hours, list) or not hours:
        return False
    for hour_data in hours:
        if isinstance(hour_data, dict) and hour_data.get("temperature") is not None:
            return True
    return False


def _weather_payload_ready(payload=None, min_days=7):
    _runtime = _get_runtime()

    days = _runtime._get_weather_days(payload)
    if len(days) < min_days:
        return False
    for day_index in range(0, min(7, len(days))):
        if not _runtime._day_payload_ready(days[day_index]):
            return False
    return True


def _save_weather_cache(location_name, data, display_name, service_name=None):
    _runtime = _get_runtime()

    try:
        _runtime._ensure_directory(_runtime.WEATHER_CACHE_DIR)
        weather_service_value = _runtime._normalized_weather_service_value(service_name)
        ready, reason = _runtime._forecast_payload_ready_for_apply(data, weather_service_value)
        if not ready:
            _runtime._tw_log(
                "Forecast cache save skipped location=%s service=%s reason=%s" %
                (_runtime._ensure_text(location_name), weather_service_value, _runtime._ensure_text(reason))
            )
            return False
        payload = {
            "timestamp": int(_runtime.time.time()),
            "location": _runtime._normalize_location_input(location_name),
            "service": weather_service_value,
            "display_name": _runtime._ensure_text(display_name or location_name),
            "weather": data,
        }
        payload_text = _runtime.json.dumps(payload)
        _runtime._write_text_file(_runtime._get_weather_cache_file(location_name, weather_service_value), payload_text)
        return True
    except Exception as e:
        print("[TheWeather] cache save error: " + str(e))
    return False


def _load_weather_cache(location_name, max_age=None, allow_stale=False, request_context=None):
    _runtime = _get_runtime()

    if not _runtime._weather_request_current(request_context):
        return False
    requested_key = _runtime._location_compare_key(location_name)
    requested_service = _runtime._normalized_weather_service_value()
    for cache_file in _runtime._get_weather_cache_candidates(location_name, requested_service):
        if not _runtime.os.path.exists(cache_file):
            continue
        try:
            with open(cache_file, "rb") as handle:
                payload = _runtime.json.loads(_runtime._ensure_text(handle.read()))
            payload_location = _runtime._normalize_location_input(payload.get("location", ""))
            if payload_location and requested_key and _runtime._location_compare_key(payload_location) != requested_key:
                continue
            payload_service_raw = _runtime._ensure_text(payload.get("service", "")).strip().lower()
            payload_service = _runtime._normalized_weather_service_value(payload_service_raw or _runtime.DEFAULT_WEATHER_SERVICE)
            if payload_service_raw:
                if payload_service != requested_service:
                    continue
            elif requested_service != _runtime.DEFAULT_WEATHER_SERVICE:
                continue
            timestamp = int(payload.get("timestamp", 0) or 0)
            if max_age is not None and not timestamp:
                continue
            age = int(_runtime.time.time()) - timestamp if timestamp else 0
            if timestamp and age > _runtime.WEATHER_CACHE_STALE_AGE:
                continue
            if max_age is not None and timestamp and age > max_age and not allow_stale:
                continue
            data = payload.get("weather")
            if not isinstance(data, dict) or not data.get("days"):
                continue
            data = _runtime._prepare_cached_payload(data, timestamp)
            ready, reason = _runtime._forecast_payload_ready_for_apply(data, payload_service)
            if not ready:
                _runtime._tw_log(
                    "Forecast cache skipped file=%s location=%s service=%s reason=%s" %
                    (_runtime._ensure_text(cache_file), _runtime._ensure_text(location_name), payload_service, _runtime._ensure_text(reason))
                )
                continue
            if cache_file == _runtime.DEFAULT_WEATHER_CACHE_FILE:
                try:
                    _runtime._write_text_file(_runtime._get_weather_cache_file(location_name, requested_service), _runtime.json.dumps(payload))
                    _runtime._tw_log("Migrated legacy shared cache into provider-specific cache for %s" % str(requested_service))
                except Exception:
                    pass
            if _runtime._apply_weather_payload(location_name, data, payload.get("display_name") or payload_location or location_name, "cache", timestamp, request_context):
                return True
        except Exception as e:
            print("[TheWeather] cache read error: " + str(e))
    return False


def _refresh_weather_cache_worker(location_name):
    _runtime = _get_runtime()

    try:
        if not _runtime._tw_auto_update_enabled():
            _runtime._tw_log("Background weather refresh skipped: automatic update disabled")
            return False
        normalized_location = _runtime._normalize_location_input(location_name)
        if not normalized_location:
            return False
        cache_max_age = _runtime._tw_cache_max_age_seconds()
        if cache_max_age > 0 and _runtime._load_weather_cache(normalized_location, cache_max_age, False):
            _runtime._tw_log("Background weather refresh skipped: valid cache still active for %s seconds" % str(cache_max_age))
            return True
        return bool(_runtime.getLocalWeather(normalized_location))
    except Exception as e:
        print("[TheWeather] async refresh error: " + str(e))
    return False


def _fetch_key(location_name):
    _runtime = _get_runtime()

    return "%s|%s" % (_runtime._location_compare_key(location_name), _runtime._normalized_weather_service_value())


def _background_refresh_candidate(location_name=None, respect_throttle=True):
    # Returns the location that may be refreshed now, or "" when a recent attempt/success
    # makes another request pointless (protects the provider's rate limits when the plugin is
    # opened and closed repeatedly).
    _runtime = _get_runtime()

    location = _runtime._normalize_location_input(location_name or _runtime.localCity)
    if not location:
        return ""
    if respect_throttle:
        fetch_key = _runtime._fetch_key(location)
        now = _runtime.time.time()
        if (now - _runtime._LAST_FETCH_ATTEMPT.get(fetch_key, 0)) < _runtime.OPEN_REFRESH_ATTEMPT_INTERVAL:
            return ""
        if (now - _runtime._LAST_LIVE_FETCH.get(fetch_key, 0)) < _runtime.OPEN_REFRESH_MIN_INTERVAL:
            return ""
    return location


def getLocalWeather(iscity=None, request_context=None):
    _runtime = _get_runtime()

    if not iscity:
        return False
    normalized_location = _runtime._normalize_location_input(iscity)
    request_context = request_context or _runtime._weather_request_context()
    fetch_key = "%s|%s" % (_runtime._location_compare_key(normalized_location), request_context[1])
    with _runtime._FETCH_LOCK:
        if not _runtime._weather_request_current(request_context):
            return False
        # A fetch that finished while this call was waiting for the lock already delivered
        # fresh data for the same location: reuse it instead of sending another request.
        last_live = _runtime._LAST_LIVE_FETCH.get(fetch_key, 0)
        if last_live and (_runtime.time.time() - last_live) < _runtime.LIVE_FETCH_DEDUPE_SECONDS and not _runtime.lastUpdateIsCached:
            if _runtime._current_weather_matches_location(normalized_location) and _runtime._forecast_payload_ready_for_apply(_runtime.weatherData)[0]:
                return True
        _runtime._LAST_FETCH_ATTEMPT[fetch_key] = _runtime.time.time()
        return _runtime._get_local_weather_locked(normalized_location, fetch_key, request_context)


def _get_local_weather_locked(normalized_location, fetch_key, request_context=None):
    _runtime = _get_runtime()

    request_context = request_context or _runtime._weather_request_context()
    try:
        from .WeatherProviders import get_weather
        data, disp_name = get_weather(normalized_location, request_context[1])
        if data:
            ready, reason = _runtime._forecast_payload_ready_for_apply(data)
            if ready:
                if _runtime._apply_weather_payload(normalized_location, data, disp_name, "live", request_context=request_context):
                    _runtime._LAST_LIVE_FETCH[fetch_key] = _runtime.time.time()
                    _runtime._save_weather_cache(normalized_location, data, disp_name, request_context[1])
                    try:
                        from .plugin_insights import schedule_learning_update
                        schedule_learning_update(normalized_location, data)
                    except Exception as insight_error:
                        _runtime._tw_log("Learning hook failed: %s" % str(insight_error))
                    _runtime._tw_log("Successfully fetched weather for " + str(normalized_location))
                    return True
            else:
                _runtime._tw_log(
                    "Live weather payload incomplete for %s reason=%s" %
                    (_runtime._ensure_text(normalized_location), _runtime._ensure_text(reason))
                )
        if data and _runtime._weather_request_current(request_context):
            print("[TheWeather] incomplete weather payload for: " + normalized_location)
    except Exception as e:
        print("[TheWeather] error getting weather: " + str(e))

    if not _runtime._weather_request_current(request_context):
        return False
    if _runtime._current_weather_matches_location(normalized_location):
        current_ready, current_reason = _runtime._forecast_payload_ready_for_apply(_runtime.weatherData)
        if current_ready:
            _runtime._tw_log("Keeping current weather data for %s because live refresh did not provide a complete replacement" % str(normalized_location))
            return True
        _runtime._tw_log("Current weather data for %s is not reusable reason=%s" % (str(normalized_location), _runtime._ensure_text(current_reason)))

    if _runtime._load_weather_cache(normalized_location, None, True, request_context) and _runtime._weather_payload_ready():
        return True
    return False
