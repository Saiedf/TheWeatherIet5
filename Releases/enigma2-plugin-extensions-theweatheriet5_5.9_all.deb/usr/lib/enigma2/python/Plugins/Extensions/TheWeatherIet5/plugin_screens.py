# -*- coding: utf-8 -*-
"""Seven-day weather screen and backward-compatible exports for all screens.

Shared helpers and runtime state live in plugin_screen_common; extended forecasts
and location/loading screens live in their respective modules.
"""
from __future__ import print_function, absolute_import

# Preserve existing imports of private helpers as well as screen classes.
from .plugin_screen_common import *
from .plugin_screen_forecast import (
    fourteen,
    TenDays,
    FourteenDays,
    SixteenDays,
    SexteenDays,
)
from .plugin_screen_locations import (
    weatherloading,
    locationsearchresultscreen,
    localcityscreen,
)

class sevendays(Screen):
    def __init__(self, session):
        main_build_started = time.time()
        bind_runtime()
        Screen.__init__(self, session)
        AddNewScreen(self)
        self["lastUpdate"] = StaticText()
        self["providerName"] = StaticText()
        self["background"] = Pixmap()
        dayinfoblok = ""
        global weatherData
        dataDays = list((weatherData or {}).get("days") or [])
        self.selected = 0
        self._built_hour = _screen_current_hour()
        self._return_action_block_until = 0.0
        self._settings_open_timer = None
        self._settings_open_pending = False
        self._settings_open_callback = None
        self._plugin_close_timer = None
        self._plugin_close_pending = False
        self._plugin_close_callback = None
        protemp = []
        peocpic = ""
        try:
            for procdays in dataDays:
                for prochours in procdays["hours"]:
                    protemp.append(_round_half_up(prochours["temperature"]))
                if len(protemp) > 3:
                    break
        except Exception:
            pass
        try:
            if protemp[0] > protemp[1]:
                peocpic = "tempcold.png"
            elif protemp[0] < protemp[1]:
                peocpic = "temphot.png"
            else:
                peocpic = "tempeven.png"
        except Exception:
            pass
        _tw_log("Sevendays main screen initializing")
        layout_hd = _sevendays_header_layout(True)
        layout_sd = _sevendays_header_layout(False)
        card_temp_layout_hd = _sevendays_day_temp_layout(True)
        card_temp_layout_sd = _sevendays_day_temp_layout(False)
        sunrise_label_text = _get_day_sunrise_sunset_text(dataDays[0]) if dataDays else "--:-- - --:--"
        if _use_fullhd_layout():
            for day in range(0, min(7, len(dataDays))):
                hourCount = 0
                day_data = dataDays[day]
                representative_hour = _get_display_hour_for_day(day_data, day, _screen_current_hour())
                _raw_wind = _get_mapping_value(representative_hour, "winddirection") or _get_mapping_value(day_data, "winddirection") or "na"
                windForce = _tw_get_safe_wind_icon(iconpath, _raw_wind, "windhd")
                dataHour = _ensure_text(_get_mapping_value(representative_hour, "iconcode") or _get_mapping_value(day_data, "iconcode") or "nodata")
                losticon = _ensure_text(_get_mapping_value(day_data, "iconcode") or "nodata")
                middle_icon_x, middle_icon_y, middle_icon_size = _sevendays_middle_icon_geometry(day, True)
                dayinfoblok += """
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str(layout_hd["main_icon"][0]) + """,""" + str(layout_hd["main_icon"][1]) + """\" size="153,153" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconbighd/""" + str(dataHour) + """.png" zPosition="1" alphatest="blend"/>
                    <widget name="bigDirIcon1""" + str(day) + """" position=\"""" + str(layout_hd["wind_icon"][0]) + """,""" + str(layout_hd["wind_icon"][1]) + """\" size="52,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/""" + str(windForce) + """.png" zPosition="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/""" + str(losticon) + """.png" position=\"""" + str(middle_icon_x) + """,""" + str(middle_icon_y) + """\" size=\"""" + str(middle_icon_size) + """,""" + str(middle_icon_size) + """\" zPosition="3" transparent="0" alphatest="blend"/>
                    <widget render="Label" source="smallday2""" + str(day) + """" position=\"""" + str(138 + (248 * day)) + """,461" size="135,40" zPosition="3" valign="center" halign="left" font="Regular;34" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="maxtemp2""" + str(day) + """" position=\"""" + str(130 + card_temp_layout_hd["max_x_shift"] + (248 * day)) + """,571" size=\"""" + str(card_temp_layout_hd["max_width"]) + """,""" + str(card_temp_layout_hd["max_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_hd["max_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
                    <widget render="Label" source="maxtemp2Unit""" + str(day) + """" position=\"""" + str(130 + card_temp_layout_hd["max_unit_x_shift"] + (248 * day)) + """,571" size=\"""" + str(card_temp_layout_hd["max_unit_width"]) + """,""" + str(card_temp_layout_hd["max_unit_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_hd["max_unit_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="minitemp2""" + str(day) + """" position=\"""" + str(240 + card_temp_layout_hd["min_x_shift"] + (248 * day)) + """,587" size=\"""" + str(card_temp_layout_hd["min_width"]) + """,""" + str(card_temp_layout_hd["min_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_hd["min_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="weathertype""" + str(day) + """" position=\"""" + str(105 + (248 * day)) + """,617" size="220,86" zPosition="3" valign="center" halign="center" font="Regular;24" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="sunriseLabel" position=\"""" + str(layout_hd["sun_label"][0]) + """,""" + str(layout_hd["sun_label"][1]) + """\" size="240,44" zPosition="3" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/sunupdownhd.png" zPosition="3" position=\"""" + str(layout_hd["sun_icon"][0]) + """,""" + str(layout_hd["sun_icon"][1]) + """\" size="132,66" alphatest="blend"/>"""
                dataHour = _get_hourly_strip_entries(day_data, day, 8)
                self["bigWeerIcon1" + str(day)] = MovingPixmap()
                self["bigDirIcon1" + str(day)] = Pixmap()
                self["smallday2" + str(day)] = StaticText()
                self["maxtemp2" + str(day)] = StaticText()
                self["maxtemp2Unit" + str(day)] = StaticText()
                self["minitemp2" + str(day)] = StaticText()
                self["weathertype" + str(day)] = StaticText()
                self["sunriseLabel" + str(day)] = StaticText()
                for hourCount in range(8):
                    if hourCount < len(dataHour):
                        data = dataHour[hourCount]
                    else:
                        data = {"iconcode": "nodata"}
                    bottom_icon_x, bottom_icon_y = _sevendays_bottom_icon_position(hourCount, True)
                    dayinfoblok += """<widget name="dayIcon""" + str(day) + "" + str(hourCount) + """" position=\"""" + str(bottom_icon_x) + """,""" + str(bottom_icon_y) + """\" size="72,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/""" + data.get("iconcode", "nodata") + """.png" zPosition="1" alphatest="blend"/>"""
                    self["dayIcon" + str(day) + str(hourCount)] = Pixmap()
            # Note: sunriseLabel and sun_icon are added per-day inside the day loop above.
            # No duplicate entry needed here outside the loop.

            for hour in range(0, 8):
                dayinfoblok += """
                    <widget render="Label" source="dayHour""" + str(hour) + """" position=\"""" + str(195 + (216 * hour)) + """,757" size="90,36" zPosition="3" valign="center" halign="right" font="Regular;33" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dayTemp""" + str(hour) + """" position=\"""" + str(120 + (216 * hour)) + """,820" size="180,54" zPosition="3" valign="center" halign="left" font="Regular;""" + str(_tuned(SEVENDAYS_HOUR_TEMP_FONT_HD, 48)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="sunPercent""" + str(hour) + """" position=\"""" + str(168 + (216 * hour)) + """,883" size="123,32" zPosition="3" valign="center" halign="left" font="Regular;27" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dayPercent""" + str(hour) + """" position=\"""" + str(168 + (216 * hour)) + """,922" size="120,30" zPosition="3" valign="center" halign="left" font="Regular;27" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="humidityPercent""" + str(hour) + """" position=\"""" + str(168 + (216 * hour)) + """,961" size="123,32" zPosition="3" valign="center" halign="left" font="Regular;27" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="daySpeed""" + str(hour) + """" position=\"""" + str(168 + (216 * hour)) + """,1000" size="123,32" zPosition="3" valign="center" halign="left" font="Regular;27" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/sunpchd.png" position=\"""" + str(114 + (216 * hour)) + """,879" size="36,36" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/rainhd.png" position=\"""" + str(116 + (216 * hour)) + """,921" size="30,30" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/rhhd.png" position=\"""" + str(120 + (216 * hour)) + """,960" size="23,30" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/turbinehd.png" position=\"""" + str(119 + (216 * hour)) + """,997" size="38,38" zPosition="3" alphatest="blend"/>"""
                self["dayHour" + str(hour)] = StaticText()
                self["dayTemp" + str(hour)] = StaticText()
                self["sunPercent" + str(hour)] = StaticText()
                self["dayPercent" + str(hour)] = StaticText()
                self["humidityPercent" + str(hour)] = StaticText()
                self["daySpeed" + str(hour)] = StaticText()
            skin = """
                    <screen name="sevenday" title="seven" flags="wfNoBorder" position="center,center" size="1920,1080">
                    <widget name="background" position="center,center" size="1920,1080" pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=True) + """\" zPosition="0" alphatest="blend"/>
                    <widget render="Label" source="providerName" position="60,35" size="600,45" transparent="1" zPosition="1" font="Regular;34" valign="center" halign="left" foregroundColor=\"""" + _summary_color()[0] + """\"/>
                    <widget render="Label" source="lastUpdate" position="60,75" size="600,40" transparent="1" zPosition="1" font="Regular;30" valign="center" halign="left" foregroundColor=\"""" + _summary_color()[0] + """\"/>
                    <widget render="Label" source="smartInfo" position="60,125" size="500,300" transparent="1" zPosition="1" font="Regular;27" valign="top" halign="left" foregroundColor=\"""" + _summary_color()[0] + """\"/>
                    <widget source="global.CurrentTime" render="Label" position="1608,30" size="250,50" transparent="1" zPosition="1" font="Regular;38" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="1360,76" size="500,38" transparent="1" zPosition="1" font="Regular;26" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget name="yellowdot" position=\"""" + str(285 + SEVENDAYS_SELECT_DOT_SHIFT_X_HD) + """,468" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/buttons/yeldothd.png" zPosition="3" alphatest="blend"/>
                    <widget render="Label" source="city1" position=\"""" + str(layout_hd["city"][0]) + """,""" + str(layout_hd["city"][1]) + """\" size="840,72" zPosition="3" valign="center" halign="center" font="Regular;42" transparent="1"/>
                    <widget render="Label" source="bigTempValue" position=\"""" + str(layout_hd["temp"][0]) + """,""" + str(layout_hd["temp"][1]) + """\" size="280,128" zPosition="3" valign="center" halign="left" font="Regular;""" + str(_tuned(SEVENDAYS_BIG_TEMP_FONT_HD, 118)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigTempDegree" position=\"""" + str(layout_hd["temp_degree"][0]) + """,""" + str(layout_hd["temp_degree"][1]) + """\" size="40,72" zPosition="3" valign="center" halign="left" font="Regular;""" + str(_tuned(SEVENDAYS_BIG_TEMP_DEGREE_FONT_HD, 100)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigTempUnit" position=\"""" + str(layout_hd["temp_unit"][0]) + """,""" + str(layout_hd["temp_unit"][1]) + """\" size="110,110" zPosition="3" valign="center" halign="left" font="Regular;""" + str(_tuned(SEVENDAYS_BIG_TEMP_UNIT_FONT_HD, 104)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigWeatherType" position=\"""" + str(layout_hd["weather_type"][0]) + """,""" + str(layout_hd["weather_type"][1]) + """\" size="560,44" zPosition="3" valign="center" halign="left" font="Regular;32" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="feelsLikeTemp" position=\"""" + str(layout_hd["feels"][0]) + """,""" + str(layout_hd["feels"][1]) + """\" size="420,44" zPosition="3" valign="center" halign="left" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="windDir" position=\"""" + str(layout_hd["wind_text"][0]) + """,""" + str(layout_hd["wind_text"][1]) + """\" size="420,44" zPosition="3" valign="center" halign="left" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>""" + dayinfoblok + """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/menubutton.png" position="1500,42" size="85,54" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/okbutton.png" position="1610,42" size="54,54" alphatest="blend"/>
                    </screen>"""
        else:
            for day in range(0, min(7, len(dataDays))):
                hourCount = 0
                day_data = dataDays[day]
                representative_hour = _get_display_hour_for_day(day_data, day, _screen_current_hour())
                _raw_wind = _get_mapping_value(representative_hour, "winddirection") or _get_mapping_value(day_data, "winddirection") or "na"
                windForce = _tw_get_safe_wind_icon(iconpath, _raw_wind, "wind")
                dataHour = _ensure_text(_get_mapping_value(representative_hour, "iconcode") or _get_mapping_value(day_data, "iconcode") or "nodata")
                losticon = _ensure_text(_get_mapping_value(day_data, "iconcode") or "nodata")
                middle_icon_x, middle_icon_y, middle_icon_size = _sevendays_middle_icon_geometry(day, False)
                dayinfoblok += """
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str(layout_sd["main_icon"][0]) + """,""" + str(layout_sd["main_icon"][1]) + """\" size="90,90" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconbigsd/""" + str(dataHour) + """.png" zPosition="1" alphatest="blend"/>
                    <widget name="bigDirIcon1""" + str(day) + """" position=\"""" + str(layout_sd["wind_icon"][0]) + """,""" + str(layout_sd["wind_icon"][1]) + """\" size="28,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/""" + str(windForce) + """.png" zPosition="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/""" + str(losticon) + """.png" position=\"""" + str(middle_icon_x) + """,""" + str(middle_icon_y) + """\" size=\"""" + str(middle_icon_size) + """,""" + str(middle_icon_size) + """\" zPosition="3" transparent="0" alphatest="blend"/>
                    <widget render="Label" source="smallday2""" + str(day) + """" position=\"""" + str(92 + (165 * day)) + """,308" size="90,24" zPosition="3" valign="center" halign="left" font="Regular;22" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="maxtemp2""" + str(day) + """" position=\"""" + str(92 + card_temp_layout_sd["max_x_shift"] + (165 * day)) + """,382" size=\"""" + str(card_temp_layout_sd["max_width"]) + """,""" + str(card_temp_layout_sd["max_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_sd["max_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
                    <widget render="Label" source="maxtemp2Unit""" + str(day) + """" position=\"""" + str(92 + card_temp_layout_sd["max_unit_x_shift"] + (165 * day)) + """,382" size=\"""" + str(card_temp_layout_sd["max_unit_width"]) + """,""" + str(card_temp_layout_sd["max_unit_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_sd["max_unit_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="minitemp2""" + str(day) + """" position=\"""" + str(160 + card_temp_layout_sd["min_x_shift"] + (165 * day)) + """,395" size=\"""" + str(card_temp_layout_sd["min_width"]) + """,""" + str(card_temp_layout_sd["min_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_sd["min_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="weathertype""" + str(day) + """" position=\"""" + str(77 + (165 * day)) + """,416" size="138,44" zPosition="3" valign="center" halign="center" font="Regular;16" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="sunriseLabel" position=\"""" + str(layout_sd["sun_label"][0]) + """,""" + str(layout_sd["sun_label"][1]) + """\" size="200,40" zPosition="3" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/sunupdownsd.png" zPosition="3" position=\"""" + str(layout_sd["sun_icon"][0]) + """,""" + str(layout_sd["sun_icon"][1]) + """\" size="80,40" alphatest="blend"/>"""
                dataHour = _get_hourly_strip_entries(day_data, day, 8)
                self["bigWeerIcon1" + str(day)] = MovingPixmap()
                self["bigDirIcon1" + str(day)] = Pixmap()
                self["smallday2" + str(day)] = StaticText()
                self["maxtemp2" + str(day)] = StaticText()
                self["maxtemp2Unit" + str(day)] = StaticText()
                self["minitemp2" + str(day)] = StaticText()
                self["weathertype" + str(day)] = StaticText()
                self["sunriseLabel" + str(day)] = StaticText()
                for hourCount in range(8):
                    if hourCount < len(dataHour):
                        data = dataHour[hourCount]
                    else:
                        data = {"iconcode": "nodata"}
                    bottom_icon_x, bottom_icon_y = _sevendays_bottom_icon_position(hourCount, False)
                    dayinfoblok += """<widget name="dayIcon""" + str(day) + "" + str(hourCount) + """" position=\"""" + str(bottom_icon_x) + """,""" + str(bottom_icon_y) + """\" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/""" + data.get("iconcode", "nodata") + """.png" zPosition="1" alphatest="blend"/>"""
                    self["dayIcon" + str(day) + str(hourCount)] = Pixmap()
            dayinfoblok += """
                    <widget render="Label" source="sunriseLabel" position=\"""" + str(layout_sd["sun_label"][0]) + """,""" + str(layout_sd["sun_label"][1]) + """\" size="200,40" zPosition="3" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/sunupdownsd.png" zPosition="3" position=\"""" + str(layout_sd["sun_icon"][0]) + """,""" + str(layout_sd["sun_icon"][1]) + """\" size="80,40" alphatest="blend"/>"""

            for hour in range(0, 8):
                dayinfoblok += """
                    <widget render="Label" source="dayHour""" + str(hour) + """" position=\"""" + str(130 + (144 * hour)) + """,506" size="60,24" zPosition="3" valign="center" halign="right" font="Regular;22" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dayTemp""" + str(hour) + """" position=\"""" + str(80 + (144 * hour)) + """,540" size="120,36" zPosition="3" valign="center" halign="left" font="Regular;""" + str(_tuned(SEVENDAYS_HOUR_TEMP_FONT_SD, 32)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="sunPercent""" + str(hour) + """" position=\"""" + str(112 + (144 * hour)) + """,580" size="82,21" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dayPercent""" + str(hour) + """" position=\"""" + str(112 + (144 * hour)) + """,606" size="80,20" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="humidityPercent""" + str(hour) + """" position=\"""" + str(112 + (144 * hour)) + """,632" size="80,20" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="daySpeed""" + str(hour) + """" position=\"""" + str(112 + (144 * hour)) + """,658" size="82,21" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/sunpcsd.png" position=\"""" + str(76 + (144 * hour)) + """,578" size="24,24" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/rainsd.png" position=\"""" + str(77 + (144 * hour)) + """,605" size="20,20" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/rhsd.png" position=\"""" + str(79 + (144 * hour)) + """,632" size="16,20" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/turbine.png" position=\"""" + str(79 + (144 * hour)) + """,656" size="25,25" zPosition="3" alphatest="blend"/>"""
                self["dayHour" + str(hour)] = StaticText()
                self["dayTemp" + str(hour)] = StaticText()
                self["sunPercent" + str(hour)] = StaticText()
                self["dayPercent" + str(hour)] = StaticText()
                self["humidityPercent" + str(hour)] = StaticText()
                self["daySpeed" + str(hour)] = StaticText()
            skin = """
                    <screen name="sevenday" title="seven" flags="wfNoBorder" position="center,center" size="1280,720">
                    <widget name="background" position="center,center" size="1280,720" pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=False) + """\" zPosition="0" alphatest="blend"/>
                    <widget render="Label" source="providerName" position="40,15" size="400,30" transparent="1" zPosition="1" font="Regular;24" valign="center" halign="left" foregroundColor=\"""" + _summary_color()[0] + """\"/>
                    <widget render="Label" source="lastUpdate" position="40,45" size="400,30" transparent="1" zPosition="1" font="Regular;22" valign="center" halign="left" foregroundColor=\"""" + _summary_color()[0] + """\"/>
                    <widget render="Label" source="smartInfo" position="40,85" size="340,200" transparent="1" zPosition="1" font="Regular;18" valign="top" halign="left" foregroundColor=\"""" + _summary_color()[0] + """\"/>
                    <widget source="global.CurrentTime" render="Label" position="1091,12" size="150,55" transparent="1" zPosition="1" font="Regular;24" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="941,32" size="300,55" transparent="1" zPosition="1" font="Regular;16" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget name="yellowdot" position=\"""" + str(184 + SEVENDAYS_SELECT_DOT_SHIFT_X_SD) + """,307" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/buttons/yeldot.png" zPosition="3" alphatest="blend"/>
                    <widget render="Label" source="city1" position=\"""" + str(layout_sd["city"][0]) + """,""" + str(layout_sd["city"][1]) + """\" size="470,42" zPosition="3" valign="center" halign="center" font="Regular;24" transparent="1"/>
                    <widget render="Label" source="bigTempValue" position=\"""" + str(layout_sd["temp"][0]) + """,""" + str(layout_sd["temp"][1]) + """\" size="160,76" zPosition="3" valign="center" halign="left" font="Regular;""" + str(_tuned(SEVENDAYS_BIG_TEMP_FONT_SD, 72)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigTempDegree" position=\"""" + str(layout_sd["temp_degree"][0]) + """,""" + str(layout_sd["temp_degree"][1]) + """\" size="28,44" zPosition="3" valign="center" halign="left" font="Regular;""" + str(_tuned(SEVENDAYS_BIG_TEMP_DEGREE_FONT_SD, 64)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigTempUnit" position=\"""" + str(layout_sd["temp_unit"][0]) + """,""" + str(layout_sd["temp_unit"][1]) + """\" size="72,68" zPosition="3" valign="center" halign="left" font="Regular;""" + str(_tuned(SEVENDAYS_BIG_TEMP_UNIT_FONT_SD, 68)) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigWeatherType" position=\"""" + str(layout_sd["weather_type"][0]) + """,""" + str(layout_sd["weather_type"][1]) + """\" size="320,30" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="feelsLikeTemp" position=\"""" + str(layout_sd["feels"][0]) + """,""" + str(layout_sd["feels"][1]) + """\" size="236,30" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="windDir" position=\"""" + str(layout_sd["wind_text"][0]) + """,""" + str(layout_sd["wind_text"][1]) + """\" size="230,30" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>""" + dayinfoblok + """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/menubuttonsd.png" position="1015,29" size="55,36" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/okbuttonsd.png" position="1085,29" size="36,36" alphatest="blend"/>
                    </screen>"""

        self["smartInfo"] = StaticText()
        try:
            from .plugin_insights import get_summary_text
            _set_component_text(self["smartInfo"], get_summary_text(weatherData, _runtime_local_city()))
        except Exception as insight_error:
            _tw_log("Smart summary unavailable: %s" % str(insight_error))
        self["city1"] = StaticText()
        _set_component_text(self["city1"], _runtime_city_display_name())
        self["bigTempValue"] = StaticText()
        self["bigTempDegree"] = StaticText()
        self["bigTempUnit"] = StaticText()
        self["bigWeatherType"] = StaticText()
        self["feelsLikeTemp"] = StaticText()
        self["windDir"] = StaticText()
        self["yellowdot"] = MovingPixmap()
        for hour in range(0, 8):
            self["dayHour" + str(hour)] = StaticText()
            _set_component_text(self["dayHour" + str(hour)], "00h")
            self["dayTemp" + str(hour)] = StaticText()
            _set_component_text(self["dayTemp" + str(hour)], "--" + _tw_temp_suffix())
            self["sunPercent" + str(hour)] = StaticText()
            _set_component_text(self["sunPercent" + str(hour)], "--%")
            self["dayPercent" + str(hour)] = StaticText()
            _set_component_text(self["dayPercent" + str(hour)], "--%")
            self["humidityPercent" + str(hour)] = StaticText()
            _set_component_text(self["humidityPercent" + str(hour)], "--%")
            self["daySpeed" + str(hour)] = StaticText()
            _set_component_text(self["daySpeed" + str(hour)], "--Km/h")
            for day in range(0, min(7, len(dataDays))):
                try:
                    self["dayIcon" + str(day) + str(hour)].hide()
                except Exception:
                    pass
        dataDays = list((weatherData or {}).get("days") or [])
        self["sunriseLabel"] = StaticText()
        _set_component_text(self["sunriseLabel"], sunrise_label_text)
        try:
            p_name = _forecast_provider_name(weatherData)
            _set_component_text(self["providerName"], str(p_name or "N/A").upper())
        except Exception:
            pass
        for day in range(0, min(7, len(dataDays))):
            day_data = dataDays[day]
            iconclass = _ensure_text(_get_mapping_value(day_data, "iconcode") or "nodata")
            info1 = _format_day_summary_label(day_data)
            _raw_min = _get_mapping_value(day_data, "mintemp", "mintemperature")
            _raw_max = _get_mapping_value(day_data, "maxtemp", "maxtemperature")
            info2 = '{:>3}'.format(_format_day_temperature_label(_tw_convert_temp(_raw_min)))
            info3_value, info3_unit = _day_card_max_temp_parts(_tw_convert_temp(_raw_max), "--")
            info3 = '{:>3}'.format(info3_value)

            self["smallday2" + str(day)] = StaticText()
            _set_component_text(self["smallday2" + str(day)], info1)
            self["maxtemp2" + str(day)] = StaticText()
            _set_component_text(self["maxtemp2" + str(day)], info3)
            self["maxtemp2Unit" + str(day)] = StaticText()
            _set_component_text(self["maxtemp2Unit" + str(day)], info3_unit)
            self["minitemp2" + str(day)] = StaticText()
            _set_component_text(self["minitemp2" + str(day)], info2)
            self["weathertype" + str(day)] = StaticText()
            _set_component_text(self["weathertype" + str(day)], icontotext(iconclass))
        _ensure_menu_keymap()
        if PY3 and (_is_openatv_image() or _is_open_source_image()):
            # OpenATV/open-source keeps the older 5.3 ActionMap path because it
            # behaved correctly there before the Dreambox-specific menu changes.
            self["myActionMap"] = ActionMap(
                ["TheWeatherIet5MenuActions", "SetupActions", "ColorActions", "MenuActions"],
                {
                    "weatherSettings": self.KeyMenu,
                    "menu": self.KeyMenu,
                    "openMenu": self.KeyMenu,
                    "left": self.left,
                    "right": self.right,
                    "yellow": self.keyYellow,
                    "blue": self.keyBlue,
                    "ok": self.fourteendays,
                    "cancel": self.cancel,
                    "red": self.exit,
                },
                -1
            )
        else:
            self["myActionMap"] = build_action_map(
                self,
                ["TheWeatherIet5MenuActions", "TheWeatherIet5Actions", "SetupActions", "ColorActions", "MenuActions"],
                {
                    "weatherSettings": self.KeyMenu,
                    "menu": self.KeyMenu,
                    "openMenu": self.KeyMenu,
                    "left": self.left,
                    "right": self.right,
                    "yellow": self.keyYellow,
                    "blue": self.keyBlue,
                    "ok": self.fourteendays,
                    "cancel": self.cancel,
                    "red": self.exit,
                },
                -1
            )
        self.skin = _apply_skin_path(skin)
        self._main_icon_paths = dict(re.findall(r'<widget name="([^"]+)"[^>]*pixmap="([^"]+)"', self.skin))
        try:
            _sync_active_background()
        except Exception:
            pass
        self._screen_closed_flag = False
        self._shown_signature = _data_signature(weatherData)
        # The day card icons are fixed pictures; remember which ones this screen shows.
        self._shown_day_icons = _day_card_icon_codes(weatherData)
        # the background picture the skin loads by itself (compared with the configured one at layout finish)
        loaded_background = re.search(r'<widget name="background"[^>]*?pixmap="([^"]+)"', self.skin)
        self._loaded_background_path = loaded_background.group(1) if loaded_background else ""
        self._bg_refresh_timer = None
        self._bg_refresh_callback = None
        self._city_poll_ref = None
        self.onLayoutFinish.append(self._refresh_background_pixmap)
        self.updateFrameselect()
        self._auto_refresh_timer = None
        self.onClose.append(self._cleanup_all)
        self._start_auto_update_timer()
        self.onLayoutFinish.append(self._start_open_refresh)
        # Timing for slow receivers: python build time, and the moment Enigma2 shows the screen.
        try:
            _tw_log("Sevendays built in %d ms" % int((time.time() - main_build_started) * 1000))
        except Exception:
            pass
        self.onShow.append(self._log_main_first_show)

    def _log_main_first_show(self):
        started = _PLUGIN_OPEN_STARTED[0]
        if not started:
            return
        _PLUGIN_OPEN_STARTED[0] = 0.0
        try:
            _tw_log("Sevendays shown %d ms after the plugin was started" % int((time.time() - started) * 1000))
        except Exception:
            pass

    def _refresh_background_pixmap(self):
        try:
            background_path = _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=_use_fullhd_layout())
            background_widget = self["background"]
        except Exception:
            return False
        # On OpenATV the skin has just loaded this very picture. Decoding a 1920x1080 PNG a second time right after
        # the first drawing made the first opening flicker, so it is only reloaded when the background setting changed.
        if self._background_already_loaded(background_path):
            return True
        try:
            background_instance = getattr(background_widget, "instance", None)
            if background_instance is not None and hasattr(background_instance, "setPixmapFromFile"):
                background_instance.setPixmapFromFile(_ui_text(background_path))
                self._loaded_background_path = _resolve_skin_asset_path(background_path)
                try:
                    background_widget.show()
                except Exception:
                    pass
                return True
        except Exception as e:
            _tw_log("Background pixmap refresh error: %s" % str(e))
        return False

    def _background_already_loaded(self, background_path):
        if _screen_switch_mode() != "openatv":
            return False
        loaded_path = getattr(self, "_loaded_background_path", "")
        if not loaded_path:
            return False
        try:
            return loaded_path == _resolve_skin_asset_path(background_path)
        except Exception as e:
            _tw_log("Background comparison skipped: %s" % str(e))
            return False

    def updateFrameselect(self, animate=True):
        global weatherData
        dataDays = list((weatherData or {}).get("days") or [])
        visible_days = min(7, len(dataDays))
        if visible_days < 1:
            return
        _refresh_screen_city_label(self)
        if self.selected < 0:
            self.selected = visible_days - 1
        elif self.selected >= visible_days:
            self.selected = 0

        if _use_fullhd_layout():
            _move_pixmap(self["yellowdot"], 285 + SEVENDAYS_SELECT_DOT_SHIFT_X_HD + (248 * self.selected), 468, 10)
        else:
            _move_pixmap(self["yellowdot"], 184 + SEVENDAYS_SELECT_DOT_SHIFT_X_SD + (165 * self.selected), 307, 10)
        selected_day = dataDays[self.selected]
        # Icons are fixed when the screen is built, so the hour used here must be the same one.
        shown_hour = getattr(self, "_built_hour", None)
        if shown_hour is None:
            shown_hour = _screen_current_hour()
        dataPerHour = _get_hourly_strip_entries(selected_day, self.selected, 8, shown_hour)
        selected_hour = _get_display_hour_for_day(selected_day, self.selected, shown_hour)
        try:
            _set_component_text(self["sunriseLabel"], _get_day_sunrise_sunset_text(selected_day))
        except Exception:
            pass
        _set_component_text(self["lastUpdate"], _("Last update: ") + lastUpdateTime)

        _degree_text, _unit_text = _main_temp_unit_parts()
        _set_component_text(self["bigTempValue"], "NA")
        _set_component_text(self["bigTempDegree"], _degree_text)
        _set_component_text(self["bigTempUnit"], _unit_text)
        _set_component_text(self["bigWeatherType"], "na")
        _set_component_text(self["feelsLikeTemp"], _("Feels Like: ") + "NA" + _tw_temp_suffix())
        _set_component_text(self["windDir"], _("Wind direction: ") + "NA")
        try:
            display_temp = None
            if self.selected == 0:
                display_temp = _get_mapping_value(selected_day, "temperature", "currenttemperature")
            if display_temp is None:
                display_temp = _get_mapping_value(selected_hour, "temperature")
            if display_temp is None:
                display_temp = _get_mapping_value(selected_day, "maxtemperature")
            display_feels = None
            if self.selected == 0:
                display_feels = _get_mapping_value(selected_day, "currentfeeltemperature")
            if display_feels is None:
                display_feels = _get_mapping_value(selected_hour, "feeltemperature", "temperature")
            display_wind = _get_mapping_value(selected_hour, "winddirection") or _get_mapping_value(selected_day, "winddirection")
            display_icon = _get_mapping_value(selected_hour, "iconcode") or _get_mapping_value(selected_day, "iconcode") or "nodata"
            _conv_temp   = _tw_convert_temp(display_temp)
            _conv_feels  = _tw_convert_temp(display_feels)
            _degree_text, _unit_text = _main_temp_unit_parts()
            _unit_sfx    = _tw_temp_suffix()
            _set_component_text(self["bigTempValue"], '{:>4}'.format(_format_temperature_text(_conv_temp, 1, "NA")))
            _set_component_text(self["bigTempDegree"], _degree_text)
            _set_component_text(self["bigTempUnit"], _unit_text)
            _set_component_text(self["feelsLikeTemp"], _("Feels Like: ") + _format_temperature_text(_conv_feels, 1, "NA") + _unit_sfx)
            _set_component_text(self["windDir"], _("Wind direction: ") + str(winddirtext(display_wind)))
            _set_component_text(self["bigWeatherType"], icontotext(str(display_icon)))
        except Exception:
            pass

        for day in range(0, visible_days):
            self["bigWeerIcon1" + str(day)].hide()
            self["bigDirIcon1" + str(day)].hide()

        try:
            use_fullhd = _use_fullhd_layout()
            target_layout = _sevendays_header_layout(use_fullhd)
            target_x = target_layout["main_icon"][0]
            target_y = target_layout["main_icon"][1]
            start_x, start_y = _sevendays_main_icon_animation_start(target_x, target_y, use_fullhd)

            sel_icon = self["bigWeerIcon1" + str(self.selected)]
            if animate:
                _move_pixmap(sel_icon, start_x, start_y, 0)
            self["bigWeerIcon1" + str(self.selected)].show()
            _move_pixmap(sel_icon, target_x, target_y, 20 if animate else 0)
        except Exception:
            pass

        self["bigWeerIcon1" + str(self.selected)].show()
        self["bigDirIcon1" + str(self.selected)].show()

        for perHourUpdate in range(0, 8):
            for day in range(0, visible_days):
                self["dayIcon" + str(day) + str(perHourUpdate)].hide()
            try:
                if perHourUpdate < len(dataPerHour):
                    self["dayIcon" + str(self.selected) + str(perHourUpdate)].show()
                    _populate_hour_slot(self, perHourUpdate, dataPerHour[perHourUpdate])
                else:
                    _populate_hour_slot(self, perHourUpdate, None)
            except Exception:
                # Could not update hour slot - safely skip and leave defaults
                pass

    def KeyMenu(self):
        if getattr(self, "_screen_switch_in_progress", False):
            return 1
        self._screen_switch_in_progress = True
        # Open Theweather setting screen on MENU button press.
        try:
            _tw_log("[Sevendays] MENU key pressed, attempting to open settings")
            if eTimer is not None:
                # Finish dispatching MENU before changing the active dialog.
                self._schedule_settings_open(delay_ms=120)
            else:
                self._open_settings_screen()
        except Exception as e:
            _tw_log("[Sevendays] KeyMenu error: " + str(e))
            print("[TheWeather] KeyMenu error: " + str(e))
            self._screen_switch_in_progress = False
            try:
                self.session.open(MessageBox, _("Settings screen could not be opened."), MESSAGEBOX_TYPE_INFO)
            except Exception:
                pass
        return 1

    def _cleanup_settings_open_timer(self):
        timer = getattr(self, "_settings_open_timer", None)
        callback = getattr(self, "_settings_open_callback", None)
        try:
            if timer is not None:
                timer.stop()
        except Exception:
            pass
        try:
            if timer is not None and callback is not None:
                _disconnect_timer(timer, callback)
        except Exception:
            pass
        self._settings_open_timer = None
        self._settings_open_pending = False
        self._settings_open_callback = None

    def _cleanup_plugin_close_timer(self):
        timer = getattr(self, "_plugin_close_timer", None)
        callback = getattr(self, "_plugin_close_callback", None)
        try:
            if timer is not None:
                timer.stop()
        except Exception:
            pass
        try:
            if timer is not None and callback is not None:
                _disconnect_timer(timer, callback)
        except Exception:
            pass
        self._plugin_close_timer = None
        self._plugin_close_pending = False
        self._plugin_close_callback = None

    def _defer_ui_actions_on_current_image(self):
        return bool(
            _is_dreambox_image() and not PY3
        )

    def _open_settings_screen(self):
        self._settings_open_pending = False
        self._settings_open_timer = None
        self._settings_open_callback = None
        if getattr(self, "_screen_closed_flag", True):
            self._screen_switch_in_progress = False
            return
        current_dialog = getattr(self.session, "current_dialog", self)
        if current_dialog is not None and current_dialog is not self:
            self._screen_switch_in_progress = False
            return
        from .TheWeatherSetting import TheweatherSetting
        _tw_log("[Sevendays] Imported TheweatherSetting, opening screen...")
        self.session.openWithCallback(self._return_from_settings, TheweatherSetting)
        _tw_log("[Sevendays] openWithCallback executed")

    def _schedule_settings_open(self, delay_ms=120):
        if getattr(self, "_settings_open_pending", False):
            return True
        try:
            timer = eTimer()
            self._settings_open_timer = timer
            self._settings_open_pending = True

            def _run():
                self._cleanup_settings_open_timer()
                try:
                    self._open_settings_screen()
                except Exception as e:
                    self._screen_switch_in_progress = False
                    _tw_log("[Sevendays] Deferred settings open error: %s" % str(e))
                    try:
                        self.session.open(MessageBox, _("Settings screen could not be opened."), MESSAGEBOX_TYPE_INFO)
                    except Exception:
                        pass

            self._settings_open_callback = _run
            _connect_timer(timer, _run)
            _start_timer(timer, int(delay_ms))
            return True
        except Exception as e:
            _tw_log("[Sevendays] Failed to schedule settings open: %s" % str(e))
            self._cleanup_settings_open_timer()
            self._open_settings_screen()
            return True

    def _close_plugin_screen_now(self):
        self._plugin_close_pending = False
        self._plugin_close_timer = None
        self._plugin_close_callback = None
        _close_plugin_safely(self)

    def _schedule_plugin_close(self, delay_ms=120):
        if getattr(self, "_plugin_close_pending", False):
            return True
        try:
            timer = eTimer()
            self._plugin_close_timer = timer
            self._plugin_close_pending = True

            def _run():
                self._cleanup_plugin_close_timer()
                try:
                    self._close_plugin_screen_now()
                except Exception as e:
                    _tw_log("[Sevendays] Deferred plugin close error: %s" % str(e))
                    try:
                        _close_plugin_safely(self)
                    except Exception:
                        pass

            self._plugin_close_callback = _run
            _connect_timer(timer, _run)
            _start_timer(timer, int(delay_ms))
            return True
        except Exception as e:
            _tw_log("[Sevendays] Failed to schedule plugin close: %s" % str(e))
            self._cleanup_plugin_close_timer()
            self._close_plugin_screen_now()
            return True

    def _cleanup_all(self):
        _tw_log("[Sevendays] performing full cleanup on close")
        remember_last_city = _runtime_plugin_value("_remember_last_city_on_exit")
        if callable(remember_last_city):
            remember_last_city()
        try:
            from .plugin import _stop_pixmap_animation
            # Stop yellow dot animation
            _stop_pixmap_animation(self["yellowdot"])
            # Stop all main icon animations
            for day in range(7):
                icon_name = "bigWeerIcon1" + str(day)
                if icon_name in self:
                    _stop_pixmap_animation(self[icon_name])
        except Exception as e:
            _tw_log("[Sevendays] Animation cleanup error: %s" % str(e))
        
        # Stop timers
        self._screen_closed_flag = True
        self._stop_auto_update_timer()
        self._stop_bg_refresh_timer()
        self._stop_city_poll_timer()
        self._cleanup_settings_open_timer()
        self._cleanup_plugin_close_timer()
        self._cleanup_post_settings_action()

    def _return_from_locations(self, selected_location=None):
        _tw_log("Returning from Locations screen, refreshing main UI")
        """Refresh display after Location management or selection."""
        try:
            _load_saved_locations()
            target_location = _normalize_location_input(selected_location)
            
            if not target_location:
                target_location = _normalize_location_input(_tw_cfg("weatherlocation", ""))

            if target_location:
                if _replace_screen(self, lambda session_: _open_weather_screen(session_, target_location, allow_async=True)):
                    return
            
            _refresh_screen_city_label(self)
            self.updateFrameselect()
        except Exception:
            pass

    def _cleanup_post_settings_action(self):
        timer = getattr(self, "_post_settings_action_timer", None)
        callback = getattr(self, "_post_settings_action_callback", None)
        self._post_settings_action_timer = None
        self._post_settings_action_callback = None
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            if callback is not None:
                _disconnect_timer(timer, callback)

    def _schedule_post_settings_action(self, callback, delay_ms=450):
        self._cleanup_post_settings_action()
        try:
            timer = eTimer()
            self._post_settings_action_timer = timer

            def _run():
                self._cleanup_post_settings_action()
                if getattr(self, "_screen_closed_flag", True):
                    return
                try:
                    callback()
                except Exception as e:
                    _tw_log("Post-settings action error: %s" % str(e))

            self._post_settings_action_callback = _run
            _connect_timer(timer, _run)
            _start_timer(timer, int(delay_ms))
            return True
        except Exception as e:
            _tw_log("Failed to schedule post-settings action: %s" % str(e))
            self._cleanup_post_settings_action()
            if self._screen_closed_flag:
                return False
            try:
                callback()
                return True
            except Exception as cb_err:
                _tw_log("Immediate post-settings action error: %s" % str(cb_err))
                return False

    def _open_city_search_from_settings(self):
        try:
            _open_virtual_keyboard(self.session, self._on_settings_city_search_text, _("Enter cityname e.g. london or cairo"), "")
            return True
        except Exception as e:
            _tw_log("Failed to open city search from settings: %s" % str(e))
            try:
                self.session.open(MessageBox, _("Keyboard screen is not available on this image."), MESSAGEBOX_TYPE_INFO)
            except Exception:
                pass
            return False

    def _on_settings_city_search_text(self, searchterm=None):
        searchterm = _ensure_text(searchterm).strip()
        if searchterm and not self._screen_closed_flag:
            _start_city_search(self, searchterm, self._return_from_locations)

    def _open_manage_favorites_from_settings(self):
        from .plugin_screen_locations import localcityscreen

        try:
            self.session.openWithCallback(self._return_from_locations, localcityscreen, reopen_via_callback=True)
            return True
        except Exception as e:
            _tw_log("Failed to open favorites from settings: %s" % str(e))
            try:
                self.session.open(MessageBox, _("Favorites screen could not be opened."), MESSAGEBOX_TYPE_INFO)
            except Exception:
                pass
            return False

    def _reload_main_weather_view(self, target_city=None, add_to_favorites=False):
        target_city = _normalize_location_input(target_city)
        if not target_city:
            target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))
        if not target_city:
            target_city = _runtime_local_city()
        if not target_city:
            return False

        try:
            _sync_active_location(target_city, add_to_favorites=bool(add_to_favorites))
        except Exception as e:
            _tw_log("Reload main weather sync error: %s" % str(e))

        loaded = False
        try:
            # The day cards and icons are baked into the skin when the screen is built, so a
            # rebuilt screen is the only way to show a different data set correctly. The
            # loader screen fetches in a worker thread and never blocks the GUI.
            if _replace_screen(self, lambda session_: _open_weather_screen(session_, target_city, allow_async=True)):
                return True
        except Exception as e:
            _tw_log("Reload main weather reopen error: %s" % str(e))

        try:
            self.selected = 0
        except Exception:
            pass
        _refresh_screen_city_label(self)
        try:
            self.updateFrameselect()
        except Exception as e:
            _tw_log("Reload main weather refresh error: %s" % str(e))
        return loaded

    def _return_from_settings(self, result=None, *args):
        self._screen_switch_in_progress = False
        self._block_return_action()
        _tw_log("Returning from Settings screen, checking for updates. Result: %s" % str(result))

        if result == "RESTART_PLUGIN":
            target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))
            _tw_log("[Sevendays] Restart signal received, closing plugin and scheduling delayed re-open for city: %s" % str(target_city))
            try:
                if _schedule_plugin_restart(self.session, target_city, delay_ms=1000):
                    _close_screen_instance(self)
                    return
            except Exception as e:
                _tw_log("[Sevendays] Direct restart scheduling error: %s" % str(e))
            _tw_log("[Sevendays] Falling back to parent restart signaling path")
            _close_screen_instance(self, "RESTART_PLUGIN")
            return

        # Check if settings returned a specific internal action
        action_name = None
        action_payload = None
        if isinstance(result, (tuple, list)) and result:
            action_name = result[0]
            if len(result) > 1:
                action_payload = result[1]
        elif isinstance(result, str) and result.startswith("action:"):
            action_name = result.replace("action:", "")

        if action_name == "refresh_background":
            target_city = _normalize_location_input(action_payload)
            if not target_city:
                try:
                    target_city = _normalize_location_input(getattr(self.session, "_tw_settings_refresh_city", ""))
                except Exception:
                    target_city = ""
            try:
                self.session._tw_settings_refresh_city = ""
            except Exception:
                pass
            if not target_city:
                target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))
            _tw_log("[Sevendays] Dreambox background refresh requested for city: %s" % str(target_city))
            try:
                if target_city and _replace_screen(self, lambda session_: _open_weather_screen(session_, target_city, allow_async=True)):
                    return
            except Exception as e:
                _tw_log("Dreambox background re-open error: %s" % str(e))
            try:
                self._refresh_background_pixmap()
            except Exception:
                pass
            try:
                self._reload_main_weather_view(target_city, add_to_favorites=bool(target_city))
            except Exception:
                pass
            return

        if action_name == "reload_weather_screen":
            target_city = _normalize_location_input(action_payload)
            if not target_city:
                target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))
            _tw_log("[Sevendays] Full weather screen reopen requested for city: %s" % str(target_city))
            try:
                if target_city and _replace_screen(self, lambda session_: _open_weather_screen(session_, target_city, allow_async=True)):
                    return
            except Exception as e:
                _tw_log("Weather screen reopen error: %s" % str(e))
            try:
                self._reload_main_weather_view(target_city, add_to_favorites=bool(target_city))
            except Exception:
                pass
            return

        try:
            if _is_dreambox_image() and not PY3:
                self._refresh_background_pixmap()
        except Exception:
            pass

        if action_name == "select_location":
            self._schedule_post_settings_action(self._open_city_search_from_settings, delay_ms=500)
            return
        if action_name == "manage_favorites":
            self._schedule_post_settings_action(self._open_manage_favorites_from_settings, delay_ms=500)
            return

        # If a city name was returned directly (as a simple string) or True
        try:
            target_city = None
            if isinstance(result, str) and not result.startswith("action:"):
                target_city = _normalize_location_input(result)

            if not target_city:
                target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))

            _tw_log("Refreshing weather for city: %s" % str(target_city))
            if self._settings_closed_without_change(result, target_city):
                # Same city and the same data as on screen: refresh in place like the original code did, instead of
                # closing and reopening the whole screen (that made a strong flicker on OpenATV).
                try:
                    # nothing changed in the settings: the favorites keep their order
                    _sync_active_location(target_city, add_to_favorites=False)
                except Exception as e:
                    _tw_log("Reload main weather sync error: %s" % str(e))
                _tw_log("Settings closed without a change; screen refreshed in place")
                self.selected = 0
                _refresh_screen_city_label(self)
                self.updateFrameselect()
                return
            self._reload_main_weather_view(target_city, add_to_favorites=bool(target_city))
        except Exception as e:
            _tw_log("Error in _return_from_settings: %s" % str(e))
            _refresh_screen_city_label(self)
            self.updateFrameselect()

    def _settings_closed_without_change(self, result, target_city):
        if result is not None and result is not False:
            return False
        try:
            if _location_compare_key(target_city) != _location_compare_key(_runtime_local_city()):
                return False
            return _data_signature(_runtime_plugin_value("weatherData")) == getattr(self, "_shown_signature", None)
        except Exception as e:
            _tw_log("Settings change check skipped: %s" % str(e))
            return False

    def _block_return_action(self):
        self._return_action_block_until = time.time() + 0.4

    def _consume_return_action(self):
        if time.time() <= self._return_action_block_until:
            self._return_action_block_until = 0.0
            return True
        return False

    def left(self):
        self.selected -= 1
        self.updateFrameselect()

    def right(self):
        self.selected += 1
        self.updateFrameselect()

    def exit(self):
        if self._consume_return_action():
            return
        if self._defer_ui_actions_on_current_image():
            self._schedule_plugin_close(delay_ms=120)
            return
        _close_plugin_safely(self)

    def cancel(self):
        if self._consume_return_action():
            return
        if self._defer_ui_actions_on_current_image():
            self._schedule_plugin_close(delay_ms=120)
            return
        _close_plugin_safely(self)

    def keyYellow(self):
        self._switch_favorite_city(-1)

    def keyBlue(self):
        self._switch_favorite_city(1)

    def _switch_favorite_city(self, direction):
        # Guard against rapid double-press: if a switch is already in progress, ignore.
        if getattr(self, "_city_switch_in_progress", False):
            _tw_log("City switch ignored: previous switch still in progress")
            return
        self._city_switch_in_progress = True
        async_pending = False
        _tw_log("Switching favorite city (direction: %d)" % direction)

        try:
            # Always refresh the saved locations list before navigating
            try:
                _load_saved_locations()
            except Exception as e:
                _tw_log("Failed to load saved locations: %s" % str(e))

            # Build a deduplicated list of valid favorite cities
            favorites = []
            seen_keys = set()
            for saved_location in list(_runtime_saved_locations()):
                normalized_location = _normalize_location_input(saved_location)
                if not normalized_location:
                    continue
                compare_key = _location_compare_key(normalized_location)
                if compare_key in seen_keys:
                    continue
                seen_keys.add(compare_key)
                favorites.append(normalized_location)

            if not favorites:
                _tw_log("Navigation skipped: SavedLocalWeather is empty")
                try:
                    self.session.open(MessageBox, _("No saved cities. Add a city first."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass
                return

            if len(favorites) < 2:
                _tw_log("Navigation skipped: only %d city saved (%s)" % (len(favorites), str(favorites)))
                try:
                    self.session.open(MessageBox, _("Only one favorite city is saved."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass
                return

            # Determine the currently displayed city using a robust key comparison
            current_city = _runtime_local_city()
            if not current_city:
                try:
                    current_city = _normalize_location_input(_resolve_start_location())
                except Exception:
                    current_city = ""
            current_key = _location_compare_key(current_city) if current_city else ""

            current_index = -1
            for i, city in enumerate(favorites):
                if _location_compare_key(city) == current_key:
                    current_index = i
                    break
            _tw_log("Current city: %s, index: %d in favorites list of %d" % (
                str(current_city), current_index, len(favorites)))

            if current_index == -1:
                # Current city not found — pick edge city based on direction
                _tw_log("Current city not found in favorites, picking edge city based on direction")
                current_index = 0 if direction > 0 else len(favorites) - 1
                new_index = current_index
            else:
                new_index = (current_index + direction) % len(favorites)

            new_city = favorites[new_index]
            new_city_key = _location_compare_key(new_city)

            _tw_log("Switching to: %s (index %d)" % (str(new_city), new_index))

            if new_city_key == current_key:
                _tw_log("City switch skipped: new city is same as current (%s)" % str(new_city))
                return

            # ----------------------------------------------------------------
            # PHASE 1 — Try cache first (disk read only, instant, never blocks).
            # _load_weather_cache() reads a local JSON file — no network call.
            # Cache hit → sync open new sevendays → THEN close current.
            # No race condition because both calls complete before returning.
            # ----------------------------------------------------------------
            cache_loaded = False
            try:
                cache_max_age = _tw_cache_max_age_seconds()
                if cache_max_age > 0:
                    cache_loaded = bool(_load_weather_cache(new_city, cache_max_age, False))
                if not cache_loaded and ALLOW_STALE_CACHE_FOR_FAST_CITY_SWITCH:
                    # Accept stale cache too — still instant and no network
                    cache_loaded = bool(_load_weather_cache(new_city, None, True))
            except Exception as cache_err:
                _tw_log("Cache pre-load error: %s" % str(cache_err))
                cache_loaded = False

            if cache_loaded:
                _tw_log("Cache hit for %s - instant sync switch" % str(new_city))
                _sync_active_location(new_city, add_to_favorites=False)
                try:
                    self.selected = 0
                    if self._refresh_main_weather_in_place():
                        return
                except Exception as sd_err:
                    _tw_log("Sync sevendays open error: %s" % str(sd_err))
                # Fallback: refresh in-place if new screen open failed
                try:
                    self.selected = 0
                    _refresh_screen_city_label(self)
                    self.updateFrameselect()
                except Exception:
                    pass
                return

            # ----------------------------------------------------------------
            # PHASE 2 — No cache: fetch from network in a BACKGROUND THREAD.
            # The UI thread is NEVER blocked — screen stays fully responsive.
            # The current screen stays open while loading; when done it is
            # refreshed in-place via updateFrameselect() — no open/close race.
            # ----------------------------------------------------------------
            _tw_log("No cache for %s - starting background fetch" % str(new_city))
            _sync_active_location(new_city, add_to_favorites=False)
            request_context = _weather_request_context()

            fetch_state = {"done": False, "success": False}
            poll_timer_ref = [None]
            switch_started = time.time()

            def _bg_fetch():
                # Runs in a background thread — safe to do network I/O here
                try:
                    weather_loader = _runtime_plugin_value("getLocalWeather")
                    if callable(weather_loader):
                        fetch_state["success"] = bool(weather_loader(new_city, request_context))
                    if not fetch_state["success"]:
                        fetch_state["success"] = bool(_load_weather_cache(new_city, None, True, request_context))
                except Exception as fetch_err:
                    _tw_log("Background fetch error: %s" % str(fetch_err))
                    fetch_state["success"] = False
                finally:
                    fetch_state["done"] = True

            def _poll_result():
                # Runs on the main UI thread via eTimer — safe to touch widgets
                if getattr(self, "_screen_closed_flag", True):
                    self._stop_city_poll_timer()
                    return
                if not fetch_state["done"] and (time.time() - switch_started) >= _POLL_TIMEOUT_SECONDS:
                    _tw_log("City switch gave up after %s seconds" % str(_POLL_TIMEOUT_SECONDS))
                    fetch_state["success"] = False
                    fetch_state["done"] = True
                if not fetch_state["done"]:
                    # Still loading — check again in 300 ms
                    try:
                        _start_timer(poll_timer_ref[0], 300)
                    except Exception:
                        pass
                    return
                if getattr(self.session, "current_dialog", self) is not self:
                    _start_timer(poll_timer_ref[0], 300)
                    return
                # Release both the callback and its retained native connection.
                self._stop_city_poll_timer()
                # Refresh every day card and icon without replacing the active dialog.
                if fetch_state["success"]:
                    try:
                        if _location_compare_key(_runtime_local_city()) != _location_compare_key(new_city):
                            _tw_log("Fetched data does not belong to %s any more - display unchanged" % str(new_city))
                        else:
                            self.selected = 0
                            self._refresh_main_weather_in_place()
                            _refresh_screen_city_label(self)
                            _tw_log("City refreshed in place for %s" % str(new_city))
                    except Exception as refresh_err:
                        _tw_log("Screen rebuild error: %s" % str(refresh_err))
                else:
                    _tw_log("Background fetch failed for %s - display unchanged" % str(new_city))
                    # Restore the prior selection only if no later request superseded it.
                    try:
                        if current_city and _weather_request_current(request_context):
                            _sync_active_location(current_city)
                        _refresh_screen_city_label(self)
                        self.session.open(MessageBox, _("Download error: No response, try again"), MESSAGEBOX_TYPE_INFO)
                    except Exception as revert_err:
                        _tw_log("City switch revert error: %s" % str(revert_err))
                # Clear the switch guard so next press is accepted
                self._city_switch_in_progress = False

            try:
                t = eTimer()
                poll_timer_ref[0] = t
                self._city_poll_ref = poll_timer_ref
                self._city_poll_callback = _poll_result
                _connect_timer(t, _poll_result)
                if _start_background_thread(_bg_fetch) is None:
                    raise RuntimeError("Could not start city fetch worker")
                _start_timer(t, 300)
                async_pending = True
                # Guard is cleared by _poll_result — return here without clearing it
                return
            except Exception as timer_err:
                _tw_log("Poll timer setup error: %s" % str(timer_err))
                self._stop_city_poll_timer()
                try:
                    _sync_active_location(current_city)
                    _refresh_screen_city_label(self)
                except Exception:
                    pass

        except Exception as e:
            _tw_log("_switch_favorite_city error: %s" % str(e))
        finally:
            # finally also runs on return: the poll callback owns the async guard.
            if not async_pending:
                self._city_switch_in_progress = False

    def _start_auto_update_timer(self):
        _start_auto_update_timer_for_screen(self)

    def _stop_auto_update_timer(self):
        _stop_auto_update_timer_for_screen(self)

    def _on_auto_update_timer(self):
        _handle_auto_update_timer_for_screen(self, True)

    def _stop_bg_refresh_timer(self):
        timer = getattr(self, "_bg_refresh_timer", None)
        callback = getattr(self, "_bg_refresh_callback", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            if callback is not None:
                _disconnect_timer(timer, callback)
        self._bg_refresh_timer = None
        self._bg_refresh_callback = None

    def _stop_city_poll_timer(self):
        poll_ref = getattr(self, "_city_poll_ref", None)
        if not poll_ref:
            return
        timer = poll_ref[0]
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            callback = getattr(self, "_city_poll_callback", None)
            if callback is not None:
                _disconnect_timer(timer, callback)
            poll_ref[0] = None
        self._city_poll_ref = None
        self._city_poll_callback = None
        self._city_switch_in_progress = False

    def _start_open_refresh(self):
        # Cached data is shown immediately; a throttled background request then asks the
        # provider for fresh data and the screen is rebuilt when real data arrives.
        try:
            if not _runtime_plugin_value("lastUpdateIsCached", False):
                return
            self._start_background_refresh(None, True)
        except Exception as e:
            _tw_log("Open refresh error: %s" % str(e))

    def _start_background_refresh(self, location=None, respect_throttle=True):
        if self._screen_closed_flag or self._bg_refresh_timer is not None or eTimer is None:
            return False
        candidate_resolver = _runtime_plugin_value("_background_refresh_candidate")
        if not callable(candidate_resolver):
            return False
        refresh_location = candidate_resolver(location, respect_throttle)
        if not refresh_location:
            return False
        state = {"done": False}
        refresh_started = time.time()
        request_context = _weather_request_context()

        def _worker():
            try:
                weather_loader = _runtime_plugin_value("getLocalWeather")
                if callable(weather_loader):
                    weather_loader(refresh_location, request_context)
            except Exception as refresh_err:
                _tw_log("Background refresh error: %s" % str(refresh_err))
            state["done"] = True

        timer = eTimer()

        def _poll():
            if getattr(self, "_screen_closed_flag", True):
                self._stop_bg_refresh_timer()
                return
            if not state["done"]:
                if (time.time() - refresh_started) < _POLL_TIMEOUT_SECONDS:
                    _start_timer(timer, 300)
                    return
                _tw_log("Background refresh gave up after %s seconds" % str(_POLL_TIMEOUT_SECONDS))
                self._stop_bg_refresh_timer()
                return
            self._stop_bg_refresh_timer()
            self._on_background_refresh_done(refresh_location)

        self._bg_refresh_timer = timer
        self._bg_refresh_callback = _poll
        _connect_timer(timer, _poll)
        if _start_background_thread(_worker) is None:
            self._stop_bg_refresh_timer()
            return False
        _start_timer(timer, 300)
        _tw_log("Background refresh started for %s" % str(refresh_location))
        return True

    def _refresh_main_weather_in_place(self):
        # Keep the active dialog and its callback intact on older receivers.
        bind_runtime()
        days = list((weatherData or {}).get("days") or [])[:7]
        if not days:
            return False
        if _day_card_icon_codes(weatherData) != getattr(self, "_shown_day_icons", None):
            # The day card icons are fixed pictures (named icon widgets made the screen flicker on
            # OpenATV), so new icons need a rebuilt screen, as in the original plugin.
            _tw_log("Day card icons changed; main screen rebuilt to show them")
            from .plugin import _open_sevendays_screen as _open_sd
            replaced = bool(_replace_screen(self, lambda session_: _open_sd(session_)))
            if replaced:
                # This screen is closing; a late refresh callback must not open a second copy.
                self._screen_closed_flag = True
            return replaced
        fullhd = _use_fullhd_layout()
        pack = _runtime_plugin_value("iconpath", iconpath)
        self._built_hour = _screen_current_hour()

        def _load_icon(name, folder, code):
            # Test build: the day card icons are fixed pictures again (no widget to refresh in place).
            if name not in self:
                return
            widget = self[name]
            native = getattr(widget, "instance", None)
            if native is not None:
                path = "/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/%s/%s/%s.png" % (pack, folder, code)
                path = _resolve_skin_asset_path(path)
                if self._main_icon_paths.get(name) == path:
                    return
                native.setPixmapFromFile(_ui_text(path))
                self._main_icon_paths[name] = path

        for day, data in enumerate(days):
            suffix = str(day)
            hour = _get_display_hour_for_day(data, day, self._built_hour)
            daily_code = _ensure_text(_get_mapping_value(data, "iconcode") or "nodata")
            hour_code = _ensure_text(_get_mapping_value(hour, "iconcode") or daily_code)
            wind = _get_mapping_value(hour, "winddirection") or _get_mapping_value(data, "winddirection") or "na"
            wind_folder = "windhd" if fullhd else "wind"
            _load_icon("bigWeerIcon1" + suffix, "iconbighd" if fullhd else "iconbigsd", hour_code)
            _load_icon("bigDirIcon1" + suffix, wind_folder, _tw_get_safe_wind_icon(pack, wind, wind_folder))
            _load_icon("daySummaryIcon" + suffix, "iconhd" if fullhd else "icon", daily_code)
            hours = _get_hourly_strip_entries(data, day, 8, self._built_hour)
            for slot in range(8):
                code = _ensure_text(_get_mapping_value(hours[slot], "iconcode") or "nodata") if slot < len(hours) else "nodata"
                _load_icon("dayIcon" + suffix + str(slot), "iconhd" if fullhd else "icon", code)
            maximum, unit = _day_card_max_temp_parts(_tw_convert_temp(_get_mapping_value(data, "maxtemp", "maxtemperature")), "--")
            minimum = _format_day_temperature_label(_tw_convert_temp(_get_mapping_value(data, "mintemp", "mintemperature")))
            _set_component_text(self["smallday2" + suffix], _format_day_summary_label(data))
            _set_component_text(self["maxtemp2" + suffix], '{:>3}'.format(maximum))
            _set_component_text(self["maxtemp2Unit" + suffix], unit)
            _set_component_text(self["minitemp2" + suffix], '{:>3}'.format(minimum))
            _set_component_text(self["weathertype" + suffix], icontotext(daily_code))
        _set_component_text(self["providerName"], str(_forecast_provider_name(weatherData) or "N/A").upper())
        try:
            from .plugin_insights import get_summary_text
            _set_component_text(self["smartInfo"], get_summary_text(weatherData, _runtime_local_city()))
        except Exception:
            pass
        self.updateFrameselect(animate=False)
        self._shown_signature = _data_signature(weatherData)
        return True

    def _on_background_refresh_done(self, refresh_location):
        if getattr(self, "_screen_closed_flag", True):
            return
        if PY3 and _data_signature(_runtime_plugin_value("weatherData")) == getattr(self, "_shown_signature", None):
            _tw_log("Fresh data equals the data on screen; screen not rebuilt")
            return
        if _runtime_plugin_value("lastUpdateIsCached", True):
            _tw_log("Background refresh finished without fresh data; keeping the cached view")
            return
        if _location_compare_key(_runtime_local_city()) != _location_compare_key(refresh_location):
            return
        if self.selected != 0 or getattr(self.session, "current_dialog", self) is not self:
            _tw_log("Fresh data stored; screen not rebuilt because the user is busy on this view")
            return
        if not PY3:
            try:
                if self._refresh_main_weather_in_place():
                    _tw_log("Fresh weather applied in place; main screen kept open")
            except Exception as refresh_err:
                _tw_log("In-place weather refresh error; keeping main screen open: %s" % str(refresh_err))
            return
        try:
            from .plugin import _open_sevendays_screen as _open_sd
            _replace_screen(self, lambda session_: _open_sd(session_))
        except Exception as rebuild_err:
            _tw_log("Background refresh rebuild error: %s" % str(rebuild_err))

    def fourteendays(self):
        if getattr(self, "_screen_switch_in_progress", False):
            return
        self._screen_switch_in_progress = True
        try:
            _GRAPH_OPEN_REQUESTED[0] = time.time()
            _tw_log("[Sevendays] OK pressed, opening %s" % _forecast_days_screen_class(weatherData).__name__)
            self.session.openWithCallback(self._return_from_fourteen, _forecast_days_screen_class(weatherData))
        except Exception as e:
            print("[TheWeather] fourteendays error: " + str(e))
            try:
                _tw_log("fourteendays error: %s | %s" % (str(e), traceback.format_exc().replace("\n", " | ")))
            except Exception:
                pass
            self._screen_switch_in_progress = False

    def _return_from_fourteen(self, *args):
        self._screen_switch_in_progress = False
        try:
            _refresh_screen_city_label(self)
            self.updateFrameselect()
        except Exception:
            pass

