# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function ensures print() works as function in Python 2.7
# absolute_import enforces explicit relative imports for Python 2.7 and Python 3.x compatibility
from __future__ import print_function, absolute_import

"""Shared screen helpers, layout constants and plugin runtime synchronization."""

from . import _

from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
try:
    from Components.MultiContent import MultiContentEntryText
except Exception:
    MultiContentEntryText = None
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText

# Safely import enigma symbols - some may be absent on certain image builds.
# gFont is available on Dreambox, Vu+, OpenATV, VTI and all standard open-source images.
# RT_HALIGN_LEFT / RT_HALIGN_RIGHT are used for MultiContent list alignment.
# eListboxPythonMultiContent is the core multi-column list engine.
# eTimer is used for deferred screen open and auto-update scheduling.
try:
    from enigma import RT_HALIGN_LEFT, RT_HALIGN_RIGHT, eListboxPythonMultiContent, eTimer, gFont
except ImportError:
    # Fallback: import each symbol individually so partial availability still works
    try:
        from enigma import RT_HALIGN_LEFT
    except ImportError:
        RT_HALIGN_LEFT = 0
    try:
        from enigma import RT_HALIGN_RIGHT
    except ImportError:
        RT_HALIGN_RIGHT = 1
    try:
        from enigma import eListboxPythonMultiContent
    except ImportError:
        eListboxPythonMultiContent = None
    try:
        from enigma import eTimer
    except ImportError:
        eTimer = None
    try:
        from enigma import gFont
    except ImportError:
        gFont = None

from Screens.Screen import Screen
import math
import re
import time
import sys
import traceback
import datetime

# Python version detection - used throughout for conditional behaviour
PY3 = sys.version_info[0] >= 3
from .plugin import (
    DEFAULT_ICON_PACK,
    MESSAGEBOX_TYPE_ERROR,
    MESSAGEBOX_TYPE_INFO,
    MessageBox,
    MovingPixmap,
    build_action_map,
    _ensure_menu_keymap,
    lastUpdateTime,
    SavedLocalWeather,
    localCity,
    _open_weather_screen,
    _load_saved_locations,
    _load_weather_cache,
    _icon_pack_has_files,
    _available_icon_packs,
    _icon_pack_display_name,
    _scale_font_size_for_runtime,
    _sanitize_icon_pack,
    _background_skin_asset_path,
    _ensure_default_location_available,
    _persist_runtime_settings,
    _purge_location_from_config_storage,
    _sync_active_background,
    version,
    iconpath,
    _write_saved_icon_pack,
    LOCATIONS_FILE,
)
from .plugin_utils import (
    _round_half_up,
    _build_location_search_row,
    _connect_timer,
    _compact_location_label,
    _disconnect_timer,
    _ensure_text,
    _format_speed_text,
    _format_temperature_text,
    _location_compare_key,
    _location_has_precise_coords,
    _location_label,
    _normalize_location_input,
    _populate_hour_slot,
    _set_component_text,
    _start_background_thread,
    _start_timer,
    _run_screen_job,
    _ui_text,
    _write_non_empty_lines,
    _tw_convert_temp,
    _tw_temp_suffix,
    _tw_auto_update_choices,
    _tw_auto_update_minutes,
    _tw_cache_choices,
    _tw_cfg,
    _tw_summary_color,
    _tw_make_font,
    _is_dreambox_image,
    _is_vti_image,
    _is_openatv_image,
    _is_open_source_image,
    _is_dreambox_box,
    _image_uses_openatv_tuning,
    _multi_content_entry_text,
    _tw_get_safe_wind_icon,
    _tw_log,
    _tw_next_choice_value,
    _display_city_only,
    _use_helpable_actions,
    _screen_switch_mode,
)
from .screen_tracking import AddNewScreen, ClosePlugin
from .weather_display import (
    _format_day_summary_label,
    _format_day_temperature_label,
    _get_day_label_parts,
    _get_day_sunrise_sunset_text,
    _get_display_hour_for_day,
    _get_mapping_value,
    _get_temperature_line_layout,
    _get_temperature_shift,
    _payload_current_hour,
    icontotext,
    winddirtext,
)

_PLUGIN_RUNTIME = None
_POLL_TIMEOUT_SECONDS = 120
_PLUGIN_RESTART_TIMERS = []
# Moment the OK key asked for the graph screen (used only for the timing line in the log).
_GRAPH_OPEN_REQUESTED = [0.0]
_SCREEN_CLOSE_SENTINEL = object()
ALLOW_STALE_CACHE_FOR_FAST_CITY_SWITCH = False

# Horizontal offset of the yellow selection dot on the day cards (negative = left).
SEVENDAYS_SELECT_DOT_SHIFT_X_HD = -20
SEVENDAYS_SELECT_DOT_SHIFT_X_SD = -13

# Forecast-graph layout adjustments in pixels (negative = up, positive = down). HD values are for
# the 1920x1080 layout, SD values are the same distances scaled for the 1280x720 layout.
# Set a value to 0 to restore the original position of that group.
# One percentage drives the empty gaps of the forecast graph: icon -> wind arrow, and wind speed
# -> rain. 25 means "make those gaps 25% smaller"; 0 keeps the original layout. The reference gaps
# are the original distances in pixels (HD = 1920x1080 layout, SD = 1280x720 layout).
GRAPH_GAP_REDUCTION_PERCENT = 25
# The wind speed -> rain gap is reduced by its own, smaller percentage.
GRAPH_WIND_RAIN_REDUCTION_PERCENT = 3
GRAPH_ICON_ARROW_GAP_HD = 56
GRAPH_ICON_ARROW_GAP_SD = 37
GRAPH_WIND_RAIN_GAP_HD = 75
GRAPH_WIND_RAIN_GAP_SD = 50
# Integer arithmetic only, so Python 2 and Python 3 always give the same pixels.
GRAPH_WIND_SHIFT_Y_HD = -((GRAPH_ICON_ARROW_GAP_HD * GRAPH_GAP_REDUCTION_PERCENT + 50) // 100)
GRAPH_WIND_SHIFT_Y_SD = -((GRAPH_ICON_ARROW_GAP_SD * GRAPH_GAP_REDUCTION_PERCENT + 50) // 100)
# The rain group follows the wind group and closes its own gap; the red/blue block follows the rain.
GRAPH_RAIN_SHIFT_Y_HD = GRAPH_WIND_SHIFT_Y_HD - ((GRAPH_WIND_RAIN_GAP_HD * GRAPH_WIND_RAIN_REDUCTION_PERCENT + 50) // 100)
GRAPH_RAIN_SHIFT_Y_SD = GRAPH_WIND_SHIFT_Y_SD - ((GRAPH_WIND_RAIN_GAP_SD * GRAPH_WIND_RAIN_REDUCTION_PERCENT + 50) // 100)
GRAPH_TOP_SHIFT_Y_HD = GRAPH_RAIN_SHIFT_Y_HD
# The rain bar grows upwards from its base line. Its height is capped (a deliberately "false" upper
# limit) so that even a huge amount of rain never reaches the wind speed text above it. The cap is
# derived from the distance between the rain base line and the wind speed text, in steps of 3 pixels
# (the available rain_N.png images).
GRAPH_RAIN_BAR_MAX_HEIGHT_HD = max(3, ((48 + GRAPH_RAIN_SHIFT_Y_HD - GRAPH_WIND_SHIFT_Y_HD) // 3) * 3)
GRAPH_RAIN_BAR_MAX_HEIGHT_SD = max(3, ((32 + GRAPH_RAIN_SHIFT_Y_SD - GRAPH_WIND_SHIFT_Y_SD) // 3) * 3)
GRAPH_TOP_SHIFT_Y_SD = GRAPH_RAIN_SHIFT_Y_SD
GRAPH_RED_SHIFT_Y_HD = 18
GRAPH_RED_SHIFT_Y_SD = 12
GRAPH_BLUE_SHIFT_Y_HD = 13
GRAPH_BLUE_SHIFT_Y_SD = 9
# The red/blue block is lowered by half of the empty space under the graph, up to this limit.
GRAPH_FILL_MAX_DROP_HD = 30
GRAPH_FILL_MAX_DROP_SD = 20
# The temperature numbers and their degree symbols (red and blue) move left, away from the column line.
GRAPH_TEMP_LABEL_SHIFT_X_HD = -12
GRAPH_TEMP_LABEL_SHIFT_X_SD = -8
# The red temperature number and its degree symbol move up, away from the red line and the red dot.
GRAPH_RED_LABEL_SHIFT_Y_HD = -8
GRAPH_RED_LABEL_SHIFT_Y_SD = -5

# Main screen. Font sizes of the big current temperature (number, degree sign, unit letter) and of the hourly cards
# (the sizes before this change were 118/100/104 and 48 for FHD, 72/64/68 and 32 for HD).
SEVENDAYS_BIG_TEMP_FONT_HD = 99
SEVENDAYS_BIG_TEMP_DEGREE_FONT_HD = 84
SEVENDAYS_BIG_TEMP_UNIT_FONT_HD = 87
SEVENDAYS_BIG_TEMP_FONT_SD = 61
SEVENDAYS_BIG_TEMP_DEGREE_FONT_SD = 53
SEVENDAYS_BIG_TEMP_UNIT_FONT_SD = 57
SEVENDAYS_HOUR_TEMP_FONT_HD = 38
SEVENDAYS_HOUR_TEMP_FONT_SD = 25
# The degree sign and the unit letter follow the shorter number (pixels to the left); the letter sits a little
# further right of the sign so that it no longer covers it.
SEVENDAYS_BIG_TEMP_SUFFIX_PULL_X_HD = -18
SEVENDAYS_BIG_TEMP_SUFFIX_PULL_X_SD = -11
SEVENDAYS_BIG_TEMP_UNIT_GAP_X_HD = 16
SEVENDAYS_BIG_TEMP_UNIT_GAP_X_SD = 10
# Day cards: font of the maximum temperature and of its unit letter (10 percent smaller than the original 48/44 and
# 32/28).
SEVENDAYS_DAY_MAX_FONT_HD = 43
SEVENDAYS_DAY_MAX_UNIT_FONT_HD = 40
SEVENDAYS_DAY_MAX_FONT_SD = 29
SEVENDAYS_DAY_MAX_UNIT_FONT_SD = 25
# Day cards on OpenATV / open-source images (fonts are 10 percent bigger there): the unit letter moves right.
SEVENDAYS_DAY_UNIT_EXTRA_X_HD = 12
SEVENDAYS_DAY_UNIT_EXTRA_X_SD = 9


def _main_screen_tuned():
    # The smaller temperatures, the moved unit letters and the raised sun were made for OpenATV and the other
    # open-source images (their fonts are 10 percent bigger). DreamOS and VTi keep the original sizes and places.
    # OpenATV / open-source images, and the Dreambox through its own condition (same values for now).
    return _image_uses_openatv_tuning()


def _tuned(new_value, original_value=0):
    return new_value if _main_screen_tuned() else original_value


def _apply_graph_shifts(plot, fullhd, extra_drop=0):
    # Moves the red/blue series as whole units (so the lines still connect the dots) without
    # touching any temperature value. The temperature labels follow their dots.
    red_shift = (GRAPH_RED_SHIFT_Y_HD if fullhd else GRAPH_RED_SHIFT_Y_SD) + int(extra_drop)
    blue_shift = (GRAPH_BLUE_SHIFT_Y_HD if fullhd else GRAPH_BLUE_SHIFT_Y_SD) + int(extra_drop)
    shifted = dict(plot)
    shifted["max_dot_y"] = plot["max_dot_y"] + red_shift
    shifted["max_ypos"] = plot["max_ypos"] + red_shift
    shifted["min_dot_y"] = plot["min_dot_y"] + blue_shift
    shifted["min_ypos"] = plot["min_ypos"] + blue_shift
    shifted["max_label_dot_y"] = shifted["max_dot_y"]
    return shifted


def _graph_visual_days(data_days, visible_days):
    # The days exactly as the graph draws them. When the hottest day is 40 degrees or more its
    # plotted maximum is one degree lower (the printed number stays true). Used by the screen
    # and by the automatic scale so both always work with identical values.
    days = list(data_days or [])
    hottest = -100
    for day in days[:int(visible_days)]:
        value = _round_half_up(day["maxtemperature"])
        if value > hottest:
            hottest = value
    visual_days = []
    for day in days:
        copy = dict(day)
        if _round_half_up(day["maxtemperature"]) == hottest and hottest >= 40:
            copy["maxtemperature"] = str(float(hottest - 1))
        visual_days.append(copy)
    return visual_days


def _fit_graph_scale(data_days, visible_days, fullhd, fixed_scale):
    # Pixels per degree for the forecast graph. The classic value is kept whenever the whole
    # graph (red line, blue line and the labels below it) fits on the screen; only when a wide
    # temperature range would run off the screen the scale shrinks until it fits again.
    if fullhd:
        base, top, gap, blue_limit, scale_max, scale_min_classic = 1200, 615 + GRAPH_TOP_SHIFT_Y_HD, 80, 675, 15, 5
        numerator, bottom_limit, label_below, blue_shift, scale_cap = 330.0, 1050, 69, GRAPH_BLUE_SHIFT_Y_HD, 18
    else:
        base, top, gap, blue_limit, scale_max, scale_min_classic = 800, 430 + GRAPH_TOP_SHIFT_Y_SD, 52, 480, 10, 3
        numerator, bottom_limit, label_below, blue_shift, scale_cap = 231.0, 700, 46, GRAPH_BLUE_SHIFT_Y_SD, 12
    days = list(data_days or [])
    visible = days[:int(visible_days)]
    if not visible:
        return scale_max, 0
    temps = [_round_half_up(d["maxtemperature"]) for d in visible]
    temps += [_round_half_up(d["mintemperature"]) for d in visible]
    temp_range = (max(temps) - min(temps)) or 1
    if fixed_scale:
        candidate = scale_max
    else:
        candidate = max(scale_min_classic, min(scale_cap, int(numerator / temp_range)))
    visual_days = _graph_visual_days(days, len(visible))

    def _bottom(scale):
        shift = _get_temperature_shift(visual_days, base, scale, 12, top)
        max_blue = 0
        smallest = 1000
        for index in range(0, len(visible)):
            probe = _get_temperature_line_layout(visual_days, index, base, scale, shift, 0, None)
            max_blue = max(max_blue, probe["min_dot_y"])
            smallest = min(smallest, probe["min_dot_y"] - probe["max_dot_y"])
        offset = 0
        if max_blue > blue_limit:
            offset = max_blue - blue_limit
            offset = max(0, min(offset, max(0, smallest - max(gap, int(smallest * 0.5)))))
        lowest = 0
        for index in range(0, len(visible)):
            row = _get_temperature_line_layout(visual_days, index, base, scale, shift, gap, None, blue_offset=offset)
            lowest = max(lowest, row["min_dot_y"] + blue_shift + label_below)
        return lowest

    scale = candidate
    lowest = _bottom(scale)
    while scale > 1 and lowest > bottom_limit:
        scale -= 1
        lowest = _bottom(scale)
    max_drop = GRAPH_FILL_MAX_DROP_HD if fullhd else GRAPH_FILL_MAX_DROP_SD
    extra_drop = max(0, min(max_drop, int((bottom_limit - lowest) / 2)))
    return scale, extra_drop

def _hold_plugin_restart_timer(timer):
    try:
        _PLUGIN_RESTART_TIMERS.append(timer)
    except Exception:
        pass


def _release_plugin_restart_timer(timer):
    try:
        _PLUGIN_RESTART_TIMERS.remove(timer)
    except Exception:
        pass


def _schedule_plugin_restart(session, target_location=None, delay_ms=1000):
    target_location = _normalize_location_input(target_location)
    if not target_location:
        target_location = _normalize_location_input(_tw_cfg("weatherlocation", ""))
    if not target_location:
        target_location = _runtime_local_city()
    if not target_location:
        return False

    try:
        timer = eTimer()

        def _restart():
            try:
                timer.stop()
            except Exception:
                pass
            try:
                _disconnect_timer(timer, _restart)
            except Exception:
                pass
            _release_plugin_restart_timer(timer)
            try:
                _open_weather_screen(session, target_location, allow_async=True)
            except Exception as e:
                _tw_log("Plugin restart reopen error: %s" % str(e))

        _connect_timer(timer, _restart)
        _hold_plugin_restart_timer(timer)
        _start_timer(timer, int(delay_ms))
        return True
    except Exception as e:
        _tw_log("Plugin restart timer error: %s" % str(e))
        try:
            timer.stop()
            _disconnect_timer(timer, _restart)
            _release_plugin_restart_timer(timer)
        except Exception:
            pass
        try:
            return bool(_open_weather_screen(session, target_location, allow_async=True))
        except Exception as reopen_error:
            _tw_log("Plugin restart immediate reopen error: %s" % str(reopen_error))
            return False


PLUGIN_ID = globals().get("PLUGIN_ID", "TheWeatherIet5")
cityNameDisplay = globals().get("cityNameDisplay", "")

_SEVENDAYS_RUNTIME_DEFAULTS = {
    "SEVENDAYS_MAIN_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_MAIN_ICON_SHIFT_Y_HD": 0,
    "SEVENDAYS_WIND_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_WIND_ICON_SHIFT_Y_HD": 0,
    "SEVENDAYS_CITY_SHIFT_X_HD": 0,
    "SEVENDAYS_CITY_SHIFT_Y_HD": 0,
    "SEVENDAYS_TEMP_SHIFT_X_HD": 0,
    "SEVENDAYS_TEMP_SHIFT_Y_HD": 0,
    "SEVENDAYS_TEMP_UNIT_SHIFT_X_HD": -42,
    "SEVENDAYS_TEMP_UNIT_SHIFT_Y_HD": -2,
    "SEVENDAYS_FEELS_SHIFT_X_HD": 0,
    "SEVENDAYS_FEELS_SHIFT_Y_HD": 0,
    "SEVENDAYS_WEATHER_TYPE_SHIFT_X_HD": 0,
    "SEVENDAYS_WEATHER_TYPE_SHIFT_Y_HD": 0,
    "SEVENDAYS_WIND_TEXT_SHIFT_X_HD": 0,
    "SEVENDAYS_WIND_TEXT_SHIFT_Y_HD": 0,
    "SEVENDAYS_TREND_SHIFT_X_HD": 0,
    "SEVENDAYS_TREND_SHIFT_Y_HD": 0,
    "SEVENDAYS_SUN_LABEL_SHIFT_X_HD": 0,
    "SEVENDAYS_SUN_LABEL_SHIFT_Y_HD": 0,
    "SEVENDAYS_SUN_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_SUN_ICON_SHIFT_Y_HD": 0,
    "SEVENDAYS_MIDDLE_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_MIDDLE_ICON_SHIFT_Y_HD": 0,
    "SEVENDAYS_MIDDLE_ICON_SIZE_HD": 72,
    "SEVENDAYS_BOTTOM_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_MAIN_ICON_SHIFT_X_SD": 0,
    "SEVENDAYS_MAIN_ICON_SHIFT_Y_SD": 0,
    "SEVENDAYS_WIND_ICON_SHIFT_X_SD": 0,
    "SEVENDAYS_WIND_ICON_SHIFT_Y_SD": 0,
    "SEVENDAYS_CITY_SHIFT_X_SD": 0,
    "SEVENDAYS_CITY_SHIFT_Y_SD": 0,
    "SEVENDAYS_TEMP_SHIFT_X_SD": 0,
    "SEVENDAYS_TEMP_SHIFT_Y_SD": 0,
    "SEVENDAYS_TEMP_UNIT_SHIFT_X_SD": -34,
    "SEVENDAYS_TEMP_UNIT_SHIFT_Y_SD": -2,
    "SEVENDAYS_FEELS_SHIFT_X_SD": 0,
    "SEVENDAYS_FEELS_SHIFT_Y_SD": 0,
    "SEVENDAYS_WEATHER_TYPE_SHIFT_X_SD": 0,
    "SEVENDAYS_WEATHER_TYPE_SHIFT_Y_SD": 0,
    "SEVENDAYS_WIND_TEXT_SHIFT_X_SD": 0,
    "SEVENDAYS_WIND_TEXT_SHIFT_Y_SD": 0,
    "SEVENDAYS_TREND_SHIFT_X_SD": 0,
    "SEVENDAYS_TREND_SHIFT_Y_SD": 0,
    "SEVENDAYS_SUN_LABEL_SHIFT_X_SD": 0,
    "SEVENDAYS_SUN_LABEL_SHIFT_Y_SD": 0,
    "SEVENDAYS_SUN_ICON_SHIFT_X_SD": 0,
    "SEVENDAYS_SUN_ICON_SHIFT_Y_SD": 0,
    "SEVENDAYS_MIDDLE_ICON_SHIFT_X_SD": 0,
    "SEVENDAYS_MIDDLE_ICON_SHIFT_Y_SD": 0,
    "SEVENDAYS_MIDDLE_ICON_SIZE_SD": 48,
    "SEVENDAYS_BOTTOM_ICON_SHIFT_X_SD": 0,
}
for _runtime_name, _runtime_value in list(_SEVENDAYS_RUNTIME_DEFAULTS.items()):
    globals().setdefault(_runtime_name, _runtime_value)

def _runtime_callable(name):
    value = _runtime_plugin_value(name, None)
    if callable(value):
        return value
    return None

def _apply_skin_path(skin_text):
    skin_applier = _runtime_callable("_apply_skin_path")
    if skin_applier is not None:
        try:
            return skin_applier(skin_text)
        except Exception:
            pass
    return skin_text

def _use_fullhd_layout():
    fullhd_checker = _runtime_callable("_use_fullhd_layout")
    if fullhd_checker is not None:
        try:
            return bool(fullhd_checker())
        except Exception:
            pass
    try:
        from enigma import getDesktop
        desktop = getDesktop(0)
        if desktop is not None:
            desktop_size = desktop.size()
            return int(desktop_size.width()) >= 1920
    except Exception:
        pass
    return False

def _move_pixmap(pixmap, pos_x, pos_y, speed=0):
    pixmap_mover = _runtime_callable("_move_pixmap")
    if pixmap_mover is not None:
        try:
            return pixmap_mover(pixmap, pos_x, pos_y, speed)
        except Exception:
            pass
    try:
        if hasattr(pixmap, "moveTo") and hasattr(pixmap, "startMoving"):
            pixmap.moveTo(int(pos_x), int(pos_y), int(speed or 0))
            pixmap.startMoving()
            return
    except Exception:
        pass
    try:
        from enigma import ePoint
        if hasattr(pixmap, "instance") and pixmap.instance is not None:
            pixmap.instance.move(ePoint(int(pos_x), int(pos_y)))
    except Exception:
        pass

def _open_virtual_keyboard(session, callback, title, text_value):
    keyboard_opener = _runtime_callable("_open_virtual_keyboard")
    if keyboard_opener is not None:
        return keyboard_opener(session, callback, title, text_value)
    try:
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        return session.openWithCallback(callback, VirtualKeyBoard, title=title, text=text_value)
    except Exception:
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        return session.openWithCallback(callback, VirtualKeyBoard, title=title)

def _sync_active_location(location_name, add_to_favorites=False):
    sync_location = _runtime_callable("_sync_active_location")
    if sync_location is not None:
        try:
            return sync_location(location_name, add_to_favorites=add_to_favorites)
        except TypeError:
            return sync_location(location_name)
    return None

def _tw_cache_max_age_seconds():
    cache_max_age = _runtime_callable("_tw_cache_max_age_seconds")
    if cache_max_age is not None:
        try:
            return int(cache_max_age() or 0)
        except Exception:
            pass
    return 0

def _resolve_start_location():
    start_location_resolver = _runtime_callable("_resolve_start_location")
    if start_location_resolver is not None:
        try:
            return start_location_resolver()
        except Exception:
            pass
    return _normalize_location_input(_tw_cfg("weatherlocation", "")) or _runtime_local_city()

def _bootstrap_embedded_default_city():
    bootstrap_default_city = _runtime_callable("_bootstrap_embedded_default_city")
    if bootstrap_default_city is not None:
        try:
            return bootstrap_default_city()
        except Exception:
            pass
    return None

def getLocalWeather(location_name):
    weather_loader = _runtime_callable("getLocalWeather")
    if weather_loader is not None:
        return weather_loader(location_name)
    return False

def bind_runtime(runtime_globals=None):
    global _PLUGIN_RUNTIME, cityNameDisplay, PLUGIN_ID
    if runtime_globals is not None:
        _PLUGIN_RUNTIME = runtime_globals
    if not isinstance(_PLUGIN_RUNTIME, dict):
        return
    for name, value in list(_PLUGIN_RUNTIME.items()):
        if name.startswith('__'):
            continue
        globals()[name] = value
    try:
        cityNameDisplay = _ensure_text(_PLUGIN_RUNTIME.get("cityNameDisplay", cityNameDisplay)).strip()
    except Exception:
        pass
    try:
        PLUGIN_ID = _ensure_text(_PLUGIN_RUNTIME.get("PLUGIN_ID", PLUGIN_ID)).strip() or PLUGIN_ID
    except Exception:
        pass

    # The screen classes previously shared this module's globals. Refresh every
    # loaded screen module so mutable plugin data and runtime functions stay current.
    runtime_values = dict((name, value) for name, value in _PLUGIN_RUNTIME.items()
                          if not name.startswith('__'))
    runtime_values["cityNameDisplay"] = cityNameDisplay
    runtime_values["PLUGIN_ID"] = PLUGIN_ID
    for module_name in ("plugin_screens", "plugin_screen_forecast", "plugin_screen_locations"):
        screen_module = sys.modules.get(__package__ + "." + module_name)
        if screen_module is not None:
            screen_module.__dict__.update(runtime_values)


def _runtime_saved_locations():
    return _runtime_plugin_value("SavedLocalWeather", SavedLocalWeather)


def _runtime_plugin_value(name, default=None):
    if isinstance(_PLUGIN_RUNTIME, dict):
        return _PLUGIN_RUNTIME.get(name, default)
    return globals().get(name, default)


def _runtime_local_city():
    return _normalize_location_input(_runtime_plugin_value("localCity", ""))


def _runtime_font(size):
    # Use the skin's built-in "Regular" font family so setFont() works correctly
    # on Dreambox, Vu+, OpenATV, VTI and all open-source images.
    # Avoids setFont() entirely - uses the skin font directly via gFont.
    if gFont is None:
        # gFont unavailable on this image build - skip font override gracefully
        return None
    try:
        return _tw_make_font(_scale_font_size_for_runtime(size))
    except Exception:
        try:
            return gFont("Regular", size)
        except Exception:
            return None

def _runtime_city_display_name():
    display_name = _ensure_text(_runtime_plugin_value("cityNameDisplay", "")).strip()
    if display_name:
        return _compact_location_label(display_name)
    active_location = _runtime_local_city() or _normalize_location_input(_tw_cfg("weatherlocation", ""))
    if active_location:
        return _compact_location_label(active_location)
    return ""

def _refresh_screen_city_label(screen):
    try:
        if "city1" in screen:
            _set_component_text(screen["city1"], _runtime_city_display_name())
    except Exception:
        pass


def _start_city_search(screen, searchterm, selection_callback, empty_callback=None):
    from .WeatherProviders import search_locations
    from .plugin_screen_locations import locationsearchresultscreen

    def _finished(results, error):
        if error is not None:
            _tw_log("City search failed: %s" % str(error))
        if results:
            screen.session.openWithCallback(selection_callback, locationsearchresultscreen, searchterm, results)
        else:
            if empty_callback is not None:
                empty_callback()
            message = _("Download error: No response, try again") if error else _("No matching cities found. Check spelling.")
            notice = getattr(screen, "_show_notice", None)
            if callable(notice):
                notice(message)
            else:
                screen.session.open(MessageBox, message, MESSAGEBOX_TYPE_INFO)

    return _run_screen_job(screen, lambda: search_locations(searchterm), _finished)


def _close_screen_instance(screen, result=_SCREEN_CLOSE_SENTINEL):
    """Close one screen safely on Dreambox, Vu+, OpenATV, VTi and open-source images."""
    if screen is None:
        return False
    try:
        _tw_log(
            "Closing screen %s (dreambox=%s, vti=%s, openatv=%s, opensource=%s, py3=%s)" % (
                screen.__class__.__name__,
                str(_is_dreambox_image() or _is_dreambox_box()),
                str(_is_vti_image()),
                str(_is_openatv_image()),
                str(_is_open_source_image()),
                str(PY3),
            )
        )
    except Exception:
        pass
    try:
        if result is _SCREEN_CLOSE_SENTINEL:
            closed = ClosePlugin(screen)
        else:
            closed = ClosePlugin(screen, result)
        if closed is not False:
            return True
    except TypeError:
        pass
    except Exception as e:
        try:
            _tw_log("Tracked close failed for %s: %s" % (screen.__class__.__name__, str(e)))
        except Exception:
            pass
    try:
        if result is _SCREEN_CLOSE_SENTINEL:
            screen.close()
        else:
            screen.close(result)
        return True
    except Exception as e:
        try:
            _tw_log("Direct close failed for %s: %s" % (screen.__class__.__name__, str(e)))
        except Exception:
            pass
    return False

def _data_signature(payload):
    # What the main screen shows: the rounded values of the first 7 days and the current temperature.
    try:
        days = list((payload or {}).get("days") or [])[:7]
        rows = []
        for day_data in days:
            rows.append((
                str(day_data.get("date", ""))[:10],
                None if day_data.get("maxtemperature") is None else int(round(float(day_data.get("maxtemperature")))),
                None if day_data.get("mintemperature") is None else int(round(float(day_data.get("mintemperature")))),
                day_data.get("iconcode"),
            ))
        current = days[0].get("temperature") if days else None
        return (tuple(rows), None if current is None else round(float(current), 1))
    except Exception:
        return None


def _replace_screen(screen, opener):
    # Opens a new screen and then closes the old one, exactly as the original plugin code did.
    # (An attempt to hide the old screen first to avoid a flicker on exit was removed: on a
    # Dreambox it left a black screen instead of returning to the TV.)
    if _screen_switch_mode() == "openatv" and eTimer is not None:
        # Condition 1 - OpenATV / open-source images: the old screen is closed FIRST and the new one is opened a moment
        # later, so no hidden "ghost" screen is left under it. A stack of ghost screens closing one after
        # another when the plugin is exited restarted Enigma2 on OpenATV (Python 3). DreamOS keeps the
        # original open-then-close order below.
        timer = eTimer()
        saved_session = getattr(screen, "session", None)

        def _open_new_screen():
            try:
                timer.stop()
            except Exception:
                pass
            try:
                _disconnect_timer(timer, _open_new_screen)
            except Exception:
                pass
            _release_plugin_restart_timer(timer)
            try:
                opener(saved_session)
            except Exception as open_error:
                _tw_log("Deferred screen open failed: %s" % str(open_error))

        _connect_timer(timer, _open_new_screen)
        _hold_plugin_restart_timer(timer)
        try:
            _start_timer(timer, 120)
        except Exception as timer_error:
            _disconnect_timer(timer, _open_new_screen)
            _release_plugin_restart_timer(timer)
            _tw_log("Screen replacement timer failed: %s" % str(timer_error))
            return False
        if not _close_screen_instance(screen):
            timer.stop()
            _disconnect_timer(timer, _open_new_screen)
            _release_plugin_restart_timer(timer)
            return False
        return True
    # Condition 2 - DreamOS (and every other image): the original order, new screen first.
    opened = bool(opener(getattr(screen, "session", None)))
    if opened:
        _close_screen_instance(screen)
    return opened

def _close_plugin_safely(screen):
    """Close the top-level plugin screen gracefully on all images."""
    if screen is None or getattr(screen, "session", None) is None:
        return
    try:
        if _is_openatv_image() or _is_open_source_image():
            if _close_screen_instance(screen):
                return
    except Exception:
        pass
    try:
        if _close_screen_instance(screen):
            return
    except Exception:
        pass
    try:
        ClosePlugin()
    except Exception:
        try:
            screen.close()
        except Exception:
            pass

def _start_auto_update_timer_for_screen(screen):
    minutes = _tw_auto_update_minutes()
    _stop_auto_update_timer_for_screen(screen)
    if getattr(screen, "session", None) is None or getattr(screen, "_screen_closed_flag", False) or getattr(screen, "_closed", False):
        return
    if minutes <= 0:
        _tw_log("Auto Update timer not started: automatic update disabled")
        return
    try:
        screen._auto_refresh_timer = eTimer()
        _connect_timer(screen._auto_refresh_timer, screen._on_auto_update_timer)
        _start_timer(screen._auto_refresh_timer, int(minutes) * 60 * 1000)
        _tw_log("Auto Update timer started: %s min" % str(minutes))
    except Exception as e:
        _tw_log("Auto Update timer start error: %s" % str(e))

def _stop_auto_update_timer_for_screen(screen):
    try:
        timer = getattr(screen, "_auto_refresh_timer", None)
        if timer is not None:
            _disconnect_timer(timer, screen._on_auto_update_timer)
            try:
                timer.stop()
            except Exception:
                pass
            screen._auto_refresh_timer = None
    except Exception:
        pass

def _handle_auto_update_timer_for_screen(screen, allow_start_location=False):
    if getattr(screen, "session", None) is None or getattr(screen, "_screen_closed_flag", False) or getattr(screen, "_closed", False):
        _stop_auto_update_timer_for_screen(screen)
        return
    try:
        minutes = _tw_auto_update_minutes()
        if minutes <= 0:
            _tw_log("Auto Update timer fired after disable request; stopping timer")
            _stop_auto_update_timer_for_screen(screen)
            return
        from .plugin import _refresh_weather_cache_worker
        location = _runtime_local_city()
        if not location and allow_start_location:
            resolver = globals().get("_resolve_start_location")
            if callable(resolver):
                location = _normalize_location_input(resolver())
        if location:
            _tw_log("Auto Update timer triggered for %s" % str(location))
            if hasattr(screen, "_start_background_refresh"):
                screen._start_background_refresh(location, False)
            else:
                _start_background_thread(_refresh_weather_cache_worker, (location,))
    except Exception as e:
        _tw_log("Auto Update timer error: %s" % str(e))
    _stop_auto_update_timer_for_screen(screen)
    _start_auto_update_timer_for_screen(screen)

def _sevendays_header_layout(fullhd):
    if fullhd:
        layout = {
            "main_icon": (700 + SEVENDAYS_MAIN_ICON_SHIFT_X_HD, 108 + SEVENDAYS_MAIN_ICON_SHIFT_Y_HD),
            "wind_icon": (1268 + SEVENDAYS_WIND_ICON_SHIFT_X_HD, 366 + SEVENDAYS_WIND_ICON_SHIFT_Y_HD),
            "city": (540 + SEVENDAYS_CITY_SHIFT_X_HD, 34 + SEVENDAYS_CITY_SHIFT_Y_HD),
            "temp": (950 + SEVENDAYS_TEMP_SHIFT_X_HD, 120 + SEVENDAYS_TEMP_SHIFT_Y_HD),
            "temp_degree": (1210 + SEVENDAYS_TEMP_UNIT_SHIFT_X_HD + _tuned(SEVENDAYS_BIG_TEMP_SUFFIX_PULL_X_HD), 116 + SEVENDAYS_TEMP_UNIT_SHIFT_Y_HD),
            "temp_unit": (1242 + SEVENDAYS_TEMP_UNIT_SHIFT_X_HD + _tuned(SEVENDAYS_BIG_TEMP_SUFFIX_PULL_X_HD) + _tuned(SEVENDAYS_BIG_TEMP_UNIT_GAP_X_HD), 126 + SEVENDAYS_TEMP_UNIT_SHIFT_Y_HD),
            "feels": (950 + SEVENDAYS_FEELS_SHIFT_X_HD, 248 + SEVENDAYS_FEELS_SHIFT_Y_HD),
            "weather_type": (950 + SEVENDAYS_WEATHER_TYPE_SHIFT_X_HD, 308 + SEVENDAYS_WEATHER_TYPE_SHIFT_Y_HD),
            "wind_text": (950 + SEVENDAYS_WIND_TEXT_SHIFT_X_HD, 360 + SEVENDAYS_WIND_TEXT_SHIFT_Y_HD),
            "trend": (1180 + SEVENDAYS_TREND_SHIFT_X_HD, 155 + SEVENDAYS_TREND_SHIFT_Y_HD),
            "sun_label": (680 + SEVENDAYS_SUN_LABEL_SHIFT_X_HD, 390 + SEVENDAYS_SUN_LABEL_SHIFT_Y_HD),
            "sun_icon": (715 + SEVENDAYS_SUN_ICON_SHIFT_X_HD, 316 + SEVENDAYS_SUN_ICON_SHIFT_Y_HD),
        }
        if _is_openatv_image():
            layout["main_icon"] = (layout["main_icon"][0], layout["main_icon"][1] + 18)
        # the sun was raised by 10 pixels for OpenATV; the other images keep the original place
        layout["main_icon"] = (layout["main_icon"][0], layout["main_icon"][1] + _tuned(0, 10))
        return layout
    layout = {
        "main_icon": (422 + SEVENDAYS_MAIN_ICON_SHIFT_X_SD, 76 + SEVENDAYS_MAIN_ICON_SHIFT_Y_SD),
        "wind_icon": (778 + SEVENDAYS_WIND_ICON_SHIFT_X_SD, 234 + SEVENDAYS_WIND_ICON_SHIFT_Y_SD),
        "city": (405 + SEVENDAYS_CITY_SHIFT_X_SD, 37 + SEVENDAYS_CITY_SHIFT_Y_SD),
        "temp": (565 + SEVENDAYS_TEMP_SHIFT_X_SD, 88 + SEVENDAYS_TEMP_SHIFT_Y_SD),
        "temp_degree": (704 + SEVENDAYS_TEMP_UNIT_SHIFT_X_SD + _tuned(SEVENDAYS_BIG_TEMP_SUFFIX_PULL_X_SD), 84 + SEVENDAYS_TEMP_UNIT_SHIFT_Y_SD),
        "temp_unit": (732 + SEVENDAYS_TEMP_UNIT_SHIFT_X_SD + _tuned(SEVENDAYS_BIG_TEMP_SUFFIX_PULL_X_SD) + _tuned(SEVENDAYS_BIG_TEMP_UNIT_GAP_X_SD), 88 + SEVENDAYS_TEMP_UNIT_SHIFT_Y_SD),
        "feels": (565 + SEVENDAYS_FEELS_SHIFT_X_SD, 176 + SEVENDAYS_FEELS_SHIFT_Y_SD),
        "weather_type": (565 + SEVENDAYS_WEATHER_TYPE_SHIFT_X_SD, 208 + SEVENDAYS_WEATHER_TYPE_SHIFT_Y_SD),
        "wind_text": (565 + SEVENDAYS_WIND_TEXT_SHIFT_X_SD, 240 + SEVENDAYS_WIND_TEXT_SHIFT_Y_SD),
        "trend": (752 + SEVENDAYS_TREND_SHIFT_X_SD, 99 + SEVENDAYS_TREND_SHIFT_Y_SD),
        "sun_label": (416 + SEVENDAYS_SUN_LABEL_SHIFT_X_SD, 248 + SEVENDAYS_SUN_LABEL_SHIFT_Y_SD),
        "sun_icon": (426 + SEVENDAYS_SUN_ICON_SHIFT_X_SD, 206 + SEVENDAYS_SUN_ICON_SHIFT_Y_SD),
    }
    if _is_openatv_image():
        layout["main_icon"] = (layout["main_icon"][0], layout["main_icon"][1] + 12)
    # the sun was raised by 7 pixels for OpenATV; the other images keep the original place
    layout["main_icon"] = (layout["main_icon"][0], layout["main_icon"][1] + _tuned(0, 7))
    return layout

def _sevendays_middle_icon_position(day, fullhd):
    if fullhd:
        return (
            131 + (248 * day) + SEVENDAYS_MIDDLE_ICON_SHIFT_X_HD,
            498 + SEVENDAYS_MIDDLE_ICON_SHIFT_Y_HD,
        )
    return (
        87 + (165 * day) + SEVENDAYS_MIDDLE_ICON_SHIFT_X_SD,
        334 + SEVENDAYS_MIDDLE_ICON_SHIFT_Y_SD,
    )

def _sevendays_middle_icon_geometry(day, fullhd):
    icon_x, icon_y = _sevendays_middle_icon_position(day, fullhd)
    if fullhd:
        return icon_x, icon_y, SEVENDAYS_MIDDLE_ICON_SIZE_HD
    return icon_x, icon_y, SEVENDAYS_MIDDLE_ICON_SIZE_SD

def _sevendays_main_icon_animation_start(target_x, target_y, fullhd):
    if fullhd:
        if _is_dreambox_image() and not PY3:
            return target_x - 300, target_y
        if _is_vti_image():
            return target_x, target_y + 60
        if _is_openatv_image():
            return target_x - 300, target_y
        if _is_open_source_image():
            return target_x, target_y + 70
        return target_x, target_y + 64
    if _is_dreambox_image() and not PY3:
        return target_x - 200, target_y
    if _is_vti_image():
        return target_x, target_y + 36
    if _is_openatv_image():
        return target_x - 200, target_y
    if _is_open_source_image():
        return target_x, target_y + 42
    return target_x, target_y + 38

def _forecast_graph_temp_unit_layout(fullhd):
    # Keep the degree/unit label visible on Dreambox, VU+, OpenATV, VTI, and open-source images.
    if fullhd:
        layout = {"x_shift": 6, "y_shift": 0, "width": 42, "height": 54, "font": 28}
        if _is_dreambox_image() and not PY3:
            layout["x_shift"] = 4
            layout["width"] = 40
        elif _is_vti_image():
            layout["x_shift"] = 7
            layout["width"] = 44
        elif _is_openatv_image() or _is_open_source_image():
            layout["x_shift"] = 8
            layout["width"] = 46
        return layout

    layout = {"x_shift": 4, "y_shift": 0, "width": 28, "height": 36, "font": 18}
    if _is_dreambox_image() and not PY3:
        layout["x_shift"] = 4
        layout["width"] = 28
    elif _is_vti_image():
        layout["x_shift"] = 5
        layout["width"] = 30
    elif _is_openatv_image() or _is_open_source_image():
        layout["x_shift"] = 6
        layout["width"] = 32
    return layout

def _sevendays_day_temp_layout(fullhd):
    # Reserve enough room for values such as 25 deg C / 25 deg F inside the day cards on every image family.
    if fullhd:
        layout = {
            "max_x_shift": 0,
            "max_width": 84,
            "max_height": 54,
            "max_font": _tuned(SEVENDAYS_DAY_MAX_FONT_HD, 48),
            "max_unit_x_shift": 56,
            "max_unit_width": _tuned(32, 22),
            "max_unit_height": 54,
            "max_unit_font": _tuned(SEVENDAYS_DAY_MAX_UNIT_FONT_HD, 44),
            "min_x_shift": 4,
            "min_width": 104,
            "min_height": 36,
            "min_font": 28,
        }
        if _is_dreambox_image() and not PY3:
            layout["max_width"] = 86
            layout["max_unit_x_shift"] = 62
            layout["min_width"] = 108
        elif _is_vti_image():
            layout["max_width"] = 88
            layout["max_unit_x_shift"] = 60
            layout["min_x_shift"] = 6
            layout["min_width"] = 112
        elif _is_openatv_image() or _is_open_source_image():
            layout["max_width"] = 90
            layout["max_unit_x_shift"] = 62 + SEVENDAYS_DAY_UNIT_EXTRA_X_HD
            layout["min_x_shift"] = 8
            layout["min_width"] = 116
        return layout

    layout = {
        "max_x_shift": 0,
        "max_width": 54,
        "max_height": 36,
        "max_font": _tuned(SEVENDAYS_DAY_MAX_FONT_SD, 32),
        "max_unit_x_shift": 32,
        "max_unit_width": _tuned(20, 14),
        "max_unit_height": 36,
        "max_unit_font": _tuned(SEVENDAYS_DAY_MAX_UNIT_FONT_SD, 28),
        "min_x_shift": 4,
        "min_width": 54,
        "min_height": 22,
        "min_font": 18,
    }
    if _is_dreambox_image() and not PY3:
        layout["max_width"] = 56
        layout["max_unit_x_shift"] = 37
        layout["min_width"] = 56
    elif _is_vti_image():
        layout["max_width"] = 58
        layout["max_unit_x_shift"] = 34
        layout["min_x_shift"] = 6
        layout["min_width"] = 58
    elif _is_openatv_image() or _is_open_source_image():
        layout["max_width"] = 60
        layout["max_unit_x_shift"] = 35 + SEVENDAYS_DAY_UNIT_EXTRA_X_SD
        layout["min_x_shift"] = 8
        layout["min_width"] = 60
    return layout

def _sevendays_bottom_icon_position(slot, fullhd):
    if fullhd:
        return (
            120 + (216 * slot) + SEVENDAYS_BOTTOM_ICON_SHIFT_X_HD,
            749,
        )
    return (
        80 + (144 * slot) + SEVENDAYS_BOTTOM_ICON_SHIFT_X_SD,
        494,
    )


def _main_temp_unit_parts():
    suffix_text = _ensure_text(_tw_temp_suffix())
    if not suffix_text:
        return u"", u""
    degree_text = u"\u00B0" if u"\u00B0" in suffix_text else suffix_text[:1]
    if degree_text == u"\u00B0":
        unit_text = suffix_text.replace(u"\u00B0", u"", 1)
    else:
        unit_text = suffix_text[1:]
    return degree_text, unit_text

def _day_card_max_temp_parts(value, default="--"):
    degree_text, unit_text = _main_temp_unit_parts()
    value_text = _format_temperature_text(value, 0, default) + degree_text
    return value_text, unit_text

def _summary_color():
    # Text and shadow color chosen in the settings for the top-left info block.
    try:
        return _tw_summary_color()
    except Exception:
        return "#ffffff", "black"


def _screen_current_hour():
    return _payload_current_hour(globals().get("weatherData"))

def _format_rain_text(value):
    try:
        return "%.1f mm" % float(value)
    except Exception:
        return "-- mm"

def _get_hourly_strip_entries(day_data, day_index, max_slots=8, current_hour=None):
    hours = []
    if isinstance(day_data, dict):
        hours = list(day_data.get("hours") or [])
    if not hours:
        return []

    visible_hours = list(hours)
    if day_index == 0:
        if current_hour is None:
            current_hour = _screen_current_hour()
        remaining_hours = []
        for hour_item in visible_hours:
            try:
                hour_value = int(_get_mapping_value(hour_item, "hour"))
            except Exception:
                hour_value = None
            if hour_value is not None and hour_value >= current_hour:
                remaining_hours.append(hour_item)
        if remaining_hours:
            visible_hours = remaining_hours

    if day_index == 0:
        if max_slots > 1:
            step = int((len(visible_hours) - 1) / (max_slots - 1))
        else:
            step = 1
    else:
        step = 3
    if step < 1:
        step = 1

    slots = []
    for slot_index in range(max_slots):
        hour_index = slot_index * step
        if hour_index < len(visible_hours):
            slots.append(visible_hours[hour_index])
    return slots

def _forecast_provider_name(payload=None):
    if payload is None:
        payload = globals().get("weatherData")
    if isinstance(payload, dict):
        provider_name = _ensure_text(payload.get("provider", payload.get("service", ""))).strip().lower()
        if provider_name:
            return provider_name
    normalizer = _runtime_plugin_value("_normalized_weather_service_value")
    if callable(normalizer):
        try:
            return _ensure_text(normalizer()).strip().lower()
        except Exception:
            pass
    return _ensure_text(_tw_cfg("weatherservice", "open-meteo")).strip().lower()


def _forecast_screen_day_count(data_days, default_limit=16, payload=None):
    total_days = len(list(data_days or []))
    if total_days <= 0:
        return 0
    safe_limit = int(default_limit or 0)
    if _forecast_provider_name(payload) == "buienradar":
        safe_limit = 14
    if isinstance(payload, dict):
        payload_limit = payload.get("screen_days", payload.get("forecast_days", 0))
        try:
            payload_limit = int(payload_limit or 0)
        except Exception:
            payload_limit = 0
        if payload_limit > 0:
            safe_limit = min(safe_limit or payload_limit, payload_limit)
    if safe_limit <= 0:
        safe_limit = total_days
    return max(0, min(safe_limit, total_days))


def _forecast_day_column_offset(fullhd, visible_days):
    visible_days = int(visible_days or 0)
    if visible_days <= 0:
        return 0
    max_slots = 16
    slot_step = 113 if fullhd else 74
    if visible_days >= max_slots:
        return 0
    return int(((max_slots - visible_days) * slot_step) / 2)


def _forecast_days_screen_class(payload=None):
    from .plugin_screen_forecast import TenDays, FourteenDays, SixteenDays

    provider = _forecast_provider_name(payload)
    if provider == "buienradar":
        return FourteenDays
    if provider == "msn":
        return TenDays
    return SixteenDays

def _day_card_icon_codes(payload):
    # Icon codes of the seven day cards, exactly as the main screen skin uses them.
    days = list((payload or {}).get("days") or [])[:7]
    return [_ensure_text(_get_mapping_value(day_data, "iconcode") or "nodata") for day_data in days]


# Include private helpers in the compatibility exports from plugin_screens.
__all__ = tuple(name for name in globals() if not name.startswith("__"))
