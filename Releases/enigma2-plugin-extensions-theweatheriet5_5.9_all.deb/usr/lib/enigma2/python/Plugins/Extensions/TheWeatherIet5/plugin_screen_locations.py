# -*- coding: utf-8 -*-
"""Weather loading, city search and favorite locations screens."""
from __future__ import print_function, absolute_import

# Shared helpers and runtime synchronization.
from .plugin_screen_common import (
    ActionMap,
    AddNewScreen,
    LOCATIONS_FILE,
    Label,
    MESSAGEBOX_TYPE_ERROR,
    MenuList,
    MessageBox,
    RT_HALIGN_LEFT,
    RT_HALIGN_RIGHT,
    SavedLocalWeather,
    Screen,
    _,
    _POLL_TIMEOUT_SECONDS,
    _apply_skin_path,
    _background_skin_asset_path,
    _bootstrap_embedded_default_city,
    _build_location_search_row,
    _close_screen_instance,
    _connect_timer,
    _disconnect_timer,
    _display_city_only,
    _ensure_default_location_available,
    _ensure_text,
    _is_open_source_image,
    _is_openatv_image,
    _is_vti_image,
    _load_saved_locations,
    _load_weather_cache,
    _location_compare_key,
    _location_has_precise_coords,
    _location_label,
    _multi_content_entry_text,
    _normalize_location_input,
    _open_virtual_keyboard,
    _open_weather_screen,
    _purge_location_from_config_storage,
    _replace_screen,
    _resolve_start_location,
    _runtime_font,
    _set_component_text,
    _start_background_thread,
    _start_city_search,
    _start_timer,
    _sync_active_location,
    _tuned,
    _tw_cfg,
    _tw_log,
    _ui_text,
    _use_fullhd_layout,
    _write_non_empty_lines,
    bind_runtime,
    eListboxPythonMultiContent,
    eTimer,
    getLocalWeather,
    iconpath,
    sys,
    time,
)

class weatherloading(Screen):
    def __init__(self, session, location_name, cache_max_age=0, callback=None):
        bind_runtime()
        self.cache_max_age = int(cache_max_age or 0)
        self.parent_callback = callback
        if _use_fullhd_layout():
            skin = """
                    <screen name="weatherloading" position="center,center" size="1920,1080" title="Weather Loading\"""" + _tuned(' flags="wfNoBorder"', '') + """>
                    <ePixmap pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=True) + """\" position="center,center" size="1920,1080" zPosition="0" alphatest="blend"/>
                    <widget name="title" position="0,200" size="1920,72" zPosition="2" valign="center" halign="center" font="Regular;56" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="location" position="0,380" size="1920,68" zPosition="2" valign="center" halign="center" font="Regular;52" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="status" position="260,500" size="1400,62" zPosition="2" valign="center" halign="center" font="Regular;42" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/buttons/red34.png" position="852,686" size="34,34" alphatest="blend"/>
                    <widget name="key_red" position="900,678" size="220,42" zPosition="2" font="Regular;38" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""
        else:
            skin = """
                    <screen name="weatherloading" position="center,center" size="1280,720" title="Weather Loading\"""" + _tuned(' flags="wfNoBorder"', '') + """>
                    <ePixmap pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=False) + """\" position="center,center" size="1280,720" zPosition="0" alphatest="blend"/>
                    <widget name="title" position="0,140" size="1280,48" zPosition="2" valign="center" halign="center" font="Regular;36" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="location" position="0,255" size="1280,44" zPosition="2" valign="center" halign="center" font="Regular;34" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="status" position="160,340" size="960,40" zPosition="2" valign="center" halign="center" font="Regular;28" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/buttons/red26.png" position="560,474" size="26,26" alphatest="blend"/>
                    <widget name="key_red" position="600,469" size="160,30" zPosition="2" font="Regular;26" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""

        self.session = session
        self.location_name = _normalize_location_input(location_name)
        self._request_context = _weather_request_context()
        self._fetch_started = False
        self._fetch_done = False
        self._fetch_success = False
        self._closed = False
        self._error_text = ""
        self.skin = _apply_skin_path(skin)
        Screen.__init__(self, session)
        AddNewScreen(self)
        display_location = _location_label(self.location_name)
        self["title"] = Label(_ui_text(_("Weather forecast")))
        self["location"] = Label(_ui_text(display_location))
        self["status"] = Label(_ui_text(_("Connecting to weather server...")))
        self["key_red"] = Label(_ui_text(_("Cancel")))
        self["actions"] = ActionMap(["WizardActions", "ColorActions"], {"back": self.cancel, "red": self.cancel}, -1)
        self._poll_timer = eTimer()
        _connect_timer(self._poll_timer, self._poll_worker)
        self.onLayoutFinish.append(self._start_fetch)
        self.onClose.append(self._cleanup)

    def _start_fetch(self):
        if self._fetch_started or self._closed:
            return
        self._fetch_started = True
        self._fetch_started_at = time.time()
        _tw_log("weatherloading start fetch for %s" % str(self.location_name))
        _set_component_text(self["status"], _("Loading weather data..."))
        if _start_background_thread(self._worker_run) is None:
            self._error_text = "Could not start weather worker"
            self._fetch_done = True
            self._poll_worker()
            return
        _start_timer(self._poll_timer, 100)

    def _worker_run(self):
        try:
            if self.cache_max_age > 0 and _load_weather_cache(self.location_name, self.cache_max_age, False, self._request_context):
                self._fetch_success = True
                _tw_log("weatherloading opened from valid cache window")
            else:
                self._fetch_success = getLocalWeather(self.location_name, self._request_context)
                if not self._fetch_success and _load_weather_cache(self.location_name, None, True, self._request_context):
                    self._fetch_success = True
        except Exception as e:
            self._error_text = str(e)
            self._fetch_success = False
        _tw_log("weatherloading worker done success=%s error=%s" % (str(self._fetch_success), str(self._error_text)))
        self._fetch_done = True

    def _poll_worker(self):
        if getattr(self, "_closed", True) or getattr(self, "_fetch_finished", False):
            return
        if not self._fetch_done:
            if (time.time() - getattr(self, "_fetch_started_at", time.time())) < _POLL_TIMEOUT_SECONDS:
                _start_timer(self._poll_timer, 100)
                return
            self._fetch_success = False
            self._error_text = "timeout"
            _invalidate_weather_requests(self._request_context)
        if getattr(self.session, "current_dialog", self) is not self:
            _start_timer(self._poll_timer, 100)
            return
        self._fetch_finished = True
        self._poll_timer.stop()
        _disconnect_timer(self._poll_timer, self._poll_worker)
        if self._fetch_success and _weather_request_current(self._request_context):
            parent_callback = self.parent_callback

            def _open_weather_view(session):
                return _open_sevendays_screen(session, parent_callback)

            if _replace_screen(self, _open_weather_view):
                return
        elif self._fetch_success:
            _close_screen_instance(self)
            return
        _tw_log("Weather loading failed: %s" % self._error_text)

        def _open_fallback(session):
            session.open(localcityscreen)
            session.open(MessageBox, _ui_text(_("Download error: No response, try again")), MESSAGEBOX_TYPE_ERROR)
            return True

        # Screen.doClose may delete .session. The replacement helper saves it first.
        if not _replace_screen(self, _open_fallback):
            _close_screen_instance(self)

    def _cleanup(self):
        self._closed = True
        try:
            self._poll_timer.stop()
        except Exception:
            pass
        _disconnect_timer(self._poll_timer, self._poll_worker)

    def cancel(self):
        if self._closed:
            return
        _invalidate_weather_requests(self._request_context)
        self._closed = True
        _close_screen_instance(self)

class locationsearchresultscreen(Screen):

    def __init__(self, session, searchterm, search_results):
        bind_runtime()
        if _use_fullhd_layout():
            skin = """
                    <screen name="locationSearchResultScreen" position="center,center" size="1920,1080" title="Weather Plugin\"""" + _tuned(' flags="wfNoBorder"', '') + """>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline3.png" position="0,112" size="1920,3" zPosition="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline3.png" position="0,1010" size="1920,3" zPosition="1"/>
                    <widget name="title" position="120,36" size="800,52" zPosition="2" font="Regular;40" transparent="1" halign="left" valign="center" />
                    <widget name="searchterm" position="120,112" size="1680,56" zPosition="2" font="Regular;36" transparent="1" halign="left" valign="center" />
                    <widget name="resultinfo" position="120,168" size="1680,42" zPosition="2" font="Regular;28" transparent="1" halign="left" valign="center" />
                    <widget name="list" position="120,230" size="1680,700" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/list/list97563.png"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/red34.png" position="192,1022" size="34,34" alphatest="blend"/>
                    <widget name="key_red" position="242,1015" size="370,42" zPosition="1" font="Regular;40" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/green34.png" position="628,1022" size="34,34" alphatest="blend"/>
                    <widget name="key_green" position="678,1015" size="370,42" zPosition="1" font="Regular;40" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""
        else:
            skin = """
                    <screen name="locationSearchResultScreen" position="center,center" size="1280,720" title="Weather Plugin\"""" + _tuned(' flags="wfNoBorder"', '') + """>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline2.png" position="0,88" size="1280,2" zPosition="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline2.png" position="0,650" size="1280,2" zPosition="1"/>
                    <widget name="title" position="60,22" size="560,34" zPosition="2" font="Regular;28" transparent="1" halign="left" valign="center" />
                    <widget name="searchterm" position="60,86" size="1160,34" zPosition="2" font="Regular;24" transparent="1" halign="left" valign="center" />
                    <widget name="resultinfo" position="60,118" size="1160,28" zPosition="2" font="Regular;18" transparent="1" halign="left" valign="center" />
                    <widget name="list" position="60,162" size="1160,430" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/list/list65043.png"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/red26.png" position="145,663" size="26,26" alphatest="blend"/>
                    <widget name="key_red" position="185,663" size="220,28" zPosition="1" font="Regular;24" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/green26.png" position="420,663" size="26,26" alphatest="blend"/>
                    <widget name="key_green" position="460,663" size="220,28" zPosition="1" font="Regular;24" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""

        self.session = session
        self.searchterm = _ensure_text(searchterm).strip()
        self.search_results = list(search_results or [])
        self.res = []
        self._screen_closed = False
        self._result_sent = False
        self.skin = _apply_skin_path(skin)
        Screen.__init__(self, session)
        AddNewScreen(self)
        self["title"] = Label(_ui_text(_("Choose city")))
        self["searchterm"] = Label(_ui_text(self.searchterm))
        self["resultinfo"] = Label(_ui_text(_("Select the correct city from the list")))
        self["key_red"] = Label(_ui_text(_("Cancel")))
        self["key_green"] = Label(_ui_text(_("Select")))

        for result in self.search_results:
            display_label = _ensure_text(result.get("label", "")).strip()
            if display_label:
                self.res.append(_build_location_search_row(result, _use_fullhd_layout()))

        self["list"] = MenuList(self.res, True, eListboxPythonMultiContent)
        if _use_fullhd_layout():
            self["list"].l.setItemHeight(68)
            self["list"].l.setFont(0, _runtime_font(40))
            self["list"].l.setFont(1, _runtime_font(34))
        else:
            self["list"].l.setItemHeight(42)
            self["list"].l.setFont(0, _runtime_font(26))
            self["list"].l.setFont(1, _runtime_font(22))
        self["list"].show()
        self["actions"] = ActionMap(["WizardActions", "MenuActions", "ShortcutActions", "ColorActions"], {"ok": self.select, "back": self.cancel, "red": self.cancel, "green": self.select}, -1)
        self.onClose.append(self._cleanup)

    def _cleanup(self):
        self._screen_closed = True

    def _close_with_result(self, result=None):
        if self._screen_closed or self._result_sent:
            return
        self._result_sent = True
        try:
            self._screen_closed = True
            _close_screen_instance(self, result)
        except Exception as e:
            print("[TheWeather] city result close error: " + str(e))

    def select(self):
        if self._screen_closed:
            return
        if not self.res:
            self._close_with_result(None)
            return
        try:
            index = self["list"].getSelectedIndex()
            selected_data = self.res[index][0]
        except Exception:
            selected_data = None
        if isinstance(selected_data, dict):
            self._close_with_result(selected_data.get("value"))
            return
        self._close_with_result(selected_data)

    def cancel(self):
        self._close_with_result(None)

class localcityscreen(Screen):

    def __init__(self, session, return_selection=False, reopen_via_callback=False):
        bind_runtime()
        global SavedLocalWeather
        vti_font_adjust = 2 if _is_vti_image() else 0
        button_font_adjust = (1 if (_is_openatv_image() or _is_open_source_image()) else 0) + vti_font_adjust
        button_font_hd = 25 + button_font_adjust
        button_font_sd = 19 + button_font_adjust
        favor_font_hd = 25 + vti_font_adjust
        favor_font_sd = 16 + vti_font_adjust
        emptyinfo_font_hd = 18 + vti_font_adjust
        emptyinfo_font_sd = 13 + vti_font_adjust
        try:
            _bootstrap_embedded_default_city()
        except Exception:
            pass
        try:
            _load_saved_locations()
        except Exception:
            pass
        if _use_fullhd_layout():
            skin = """
                    <screen name="TheWeatherIet5ManageFavorites" position="center,center" size="1080,570" title="Manage Favorites - TheWeatherIet5" flags="wfNoBorder" backgroundColor="#232323" transparent="0">
                    <eLabel position="0,0" size="1080,570" backgroundColor="#232323" transparent="0" zPosition="0"/>
                    <eLabel position="0,0" size="1080,46" backgroundColor="#454b50" transparent="0" zPosition="1"/>
                    <widget name="favor" position="18,5" size="800,34" valign="center" halign="left" zPosition="2" font="Regular;{favor_font_hd}" foregroundColor="#00ff00" backgroundColor="#454b50" transparent="0" noWrap="1"/>
                    <eLabel position="18,48" size="1044,2" backgroundColor="#9d6616" transparent="0" zPosition="1"/>
                    <widget name="emptyinfo" position="18,58" size="1044,30" valign="center" halign="center" zPosition="2" font="Regular;{emptyinfo_font_hd}" foregroundColor="#9f9f9f" backgroundColor="#232323" transparent="0" noWrap="1"/>
                    <widget name="list" position="18,94" size="1044,364" zPosition="5" foregroundColor="#ffffff" backgroundColor="#000000" transparent="0" scrollbarMode="showOnDemand"/>
                    <eLabel position="18,474" size="1044,1" backgroundColor="#9d6616" transparent="0" zPosition="1"/>
                    <widget name="key_red" position="42,492" size="210,28" zPosition="3" font="Regular;{button_font_hd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="72,524" size="150,3" backgroundColor="#c5161d" transparent="0" zPosition="3"/>
                    <widget name="key_green" position="304,492" size="210,28" zPosition="3" font="Regular;{button_font_hd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="334,524" size="150,3" backgroundColor="#2ca52c" transparent="0" zPosition="3"/>
                    <widget name="key_yellow" position="566,492" size="210,28" zPosition="3" font="Regular;{button_font_hd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="596,524" size="150,3" backgroundColor="#c5b01b" transparent="0" zPosition="3"/>
                    <widget name="key_blue" position="828,492" size="210,28" zPosition="3" font="Regular;{button_font_hd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="858,524" size="150,3" backgroundColor="#2aa8e7" transparent="0" zPosition="3"/>
                    </screen>""".format(button_font_hd=button_font_hd, favor_font_hd=favor_font_hd, emptyinfo_font_hd=emptyinfo_font_hd)

        else:
            skin = """
                    <screen name="TheWeatherIet5ManageFavorites" position="center,center" size="720,380" title="Manage Favorites - TheWeatherIet5" flags="wfNoBorder" backgroundColor="#232323" transparent="0">
                    <eLabel position="0,0" size="720,380" backgroundColor="#232323" transparent="0" zPosition="0"/>
                    <eLabel position="0,0" size="720,32" backgroundColor="#454b50" transparent="0" zPosition="1"/>
                    <widget name="favor" position="12,3" size="480,24" valign="center" halign="left" zPosition="2" font="Regular;{favor_font_sd}" foregroundColor="#00ff00" backgroundColor="#454b50" transparent="0" noWrap="1"/>
                    <eLabel position="12,34" size="696,1" backgroundColor="#9d6616" transparent="0" zPosition="1"/>
                    <widget name="emptyinfo" position="12,40" size="696,22" valign="center" halign="center" zPosition="2" font="Regular;{emptyinfo_font_sd}" foregroundColor="#9f9f9f" backgroundColor="#232323" transparent="0" noWrap="1"/>
                    <widget name="list" position="12,66" size="696,234" zPosition="5" foregroundColor="#ffffff" backgroundColor="#000000" transparent="0" scrollbarMode="showOnDemand"/>
                    <eLabel position="12,314" size="696,1" backgroundColor="#9d6616" transparent="0" zPosition="1"/>
                    <widget name="key_red" position="24,328" size="150,22" zPosition="3" font="Regular;{button_font_sd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="45,352" size="108,2" backgroundColor="#c5161d" transparent="0" zPosition="3"/>
                    <widget name="key_green" position="198,328" size="150,22" zPosition="3" font="Regular;{button_font_sd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="219,352" size="108,2" backgroundColor="#2ca52c" transparent="0" zPosition="3"/>
                    <widget name="key_yellow" position="372,328" size="150,22" zPosition="3" font="Regular;{button_font_sd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="393,352" size="108,2" backgroundColor="#c5b01b" transparent="0" zPosition="3"/>
                    <widget name="key_blue" position="546,328" size="150,22" zPosition="3" font="Regular;{button_font_sd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="567,352" size="108,2" backgroundColor="#2aa8e7" transparent="0" zPosition="3"/>
                    </screen>""".format(button_font_sd=button_font_sd, favor_font_sd=favor_font_sd, emptyinfo_font_sd=emptyinfo_font_sd)

        self.session = session
        self._screen_closed = False
        self._return_action_block_until = time.time() + (1.20 if return_selection else 0.70)
        self._return_selection = bool(return_selection)
        self._reopen_via_callback = bool(reopen_via_callback)
        self._empty_state_prompt_started = False
        self._editing_location_key = None
        self.skin = _apply_skin_path(skin)
        self.skinName = "TheWeatherIet5ManageFavorites"
        Screen.__init__(self, session)
        AddNewScreen(self)
        self["key_red"] = Label(_ui_text(_("Delete")))
        self["key_green"] = Label(_ui_text(_("Save")))
        self["key_yellow"] = Label(_ui_text(_("Edit")))
        self["key_blue"] = Label(_ui_text(_("Add")))
        self["favor"] = Label(_ui_text(_("Manage Favorites - TheWeatherIet5")))
        self["emptyinfo"] = Label("")
        self._inline_notice_timer = eTimer()
        self._inline_notice_callback = self._clear_inline_notice
        _connect_timer(self._inline_notice_timer, self._inline_notice_callback)
        self.res = []
        self._reload_favorites_view()
        self["list"] = MenuList(self.res, True, eListboxPythonMultiContent)
        self._apply_favorites_list_layout()
        self["list"].show()
        close_action = getattr(self, "cancel", None) or getattr(self, "exit", None) or self.close
        red_action = self.removeLoc
        self["actions"] = ActionMap(
            ["WizardActions", "MenuActions", "ShortcutActions", "OkCancelActions"],
            {
                "ok": self.go,
                "back": close_action,
                "cancel": close_action,
            },
            -1
        )
        self["color_actions"] = ActionMap(
            ["ColorActions"],
            {
                "red": red_action,
                "green": self.go,
                "yellow": self.editLoc,
                "blue": self.addLoc,
            },
            -1
        )
        self.onLayoutFinish.append(self._handle_empty_state_after_layout)
        self.onClose.append(self._cleanup)

    def _cleanup(self):
        self._screen_closed = True
        try:
            if self._inline_notice_timer is not None:
                try:
                    self._inline_notice_timer.stop()
                except Exception:
                    pass
                if self._inline_notice_callback is not None:
                    _disconnect_timer(self._inline_notice_timer, self._inline_notice_callback)
        except Exception:
            pass

    def _default_emptyinfo_text(self):
        return _("Use Blue to add a city.") if not self.res else ""

    def _clear_inline_notice(self):
        if getattr(self, "_screen_closed", True):
            return
        try:
            self._inline_notice_timer.stop()
        except Exception:
            pass
        _set_component_text(self["emptyinfo"], self._default_emptyinfo_text())

    def _show_inline_notice(self, message, timeout_ms=2500):
        if self._screen_closed:
            return
        _set_component_text(self["emptyinfo"], message)
        try:
            self._inline_notice_timer.stop()
        except Exception:
            pass
        try:
            _start_timer(self._inline_notice_timer, int(timeout_ms))
        except Exception:
            pass

    def _show_notice(self, message, timeout_ms=2500):
        self._show_inline_notice(_ui_text(message), timeout_ms)

    def _plugin_runtime_module(self):
        try:
            return sys.modules.get(getattr(_load_saved_locations, "__module__", ""))
        except Exception:
            return None

    def _plugin_saved_locations(self):
        plugin_runtime = self._plugin_runtime_module()
        if plugin_runtime is not None and hasattr(plugin_runtime, "SavedLocalWeather"):
            return plugin_runtime.SavedLocalWeather
        return SavedLocalWeather

    def _set_saved_locations(self, locations):
        global SavedLocalWeather
        normalized_locations = self._dedupe_locations(locations)
        SavedLocalWeather[:] = normalized_locations
        plugin_runtime = self._plugin_runtime_module()
        if plugin_runtime is not None and hasattr(plugin_runtime, "SavedLocalWeather"):
            try:
                plugin_runtime.SavedLocalWeather[:] = normalized_locations
            except Exception:
                try:
                    plugin_runtime.SavedLocalWeather = normalized_locations
                except Exception:
                    pass
        return SavedLocalWeather

    def _sync_saved_locations_view(self, reload_locations=False):
        global SavedLocalWeather
        if reload_locations:
            try:
                _load_saved_locations()
            except Exception:
                pass
        plugin_runtime = self._plugin_runtime_module()
        if plugin_runtime is not None and hasattr(plugin_runtime, "SavedLocalWeather"):
            if id(SavedLocalWeather) != id(plugin_runtime.SavedLocalWeather):
                SavedLocalWeather[:] = list(plugin_runtime.SavedLocalWeather)

    def _dedupe_locations(self, locations):
        deduped = []
        seen_keys = set()
        for location_name in list(locations or []):
            normalized_location = _normalize_location_input(location_name)
            if not normalized_location:
                continue
            if not _location_has_precise_coords(normalized_location):
                continue
            compare_key = _location_compare_key(normalized_location)
            if compare_key in seen_keys:
                continue
            seen_keys.add(compare_key)
            deduped.append(normalized_location)
        return deduped

    def _persist_favorite_locations(self, locations, preferred_location=None):
        persisted_locations = self._dedupe_locations(locations)
        current_locations = list(self._set_saved_locations(persisted_locations))
        try:
            _write_non_empty_lines(LOCATIONS_FILE, current_locations)
        except Exception:
            pass
        self._sync_saved_locations_view(reload_locations=False)
        self._reload_favorites_view(preferred_location, current_locations)
        return list(current_locations)

    def _block_return_action(self):
        self._return_action_block_until = time.time() + 0.4

    def _handle_empty_state_after_layout(self):
        if self._screen_closed or self.res or self._empty_state_prompt_started:
            return
        self._empty_state_prompt_started = True
        self.addLoc()

    def _apply_favorites_list_layout(self):
        try:
            title_font_boost = 0
            info_font_boost = 0
            row_primary_boost = 0
            row_secondary_boost = 0
            item_height_boost = 0
            if _is_vti_image():
                title_font_boost = 2
                info_font_boost = 2
                row_primary_boost = 3
                row_secondary_boost = 2
                item_height_boost = 4
            # Font size for eLabel widgets (favor, emptyinfo) is controlled by the skin.
            # Do NOT use instance.setFont() on eLabel components - rely on skin font attributes.
            # Only the MultiContent list engine (l.setFont) supports dynamic font overrides.
            if _use_fullhd_layout():
                self["list"].l.setItemHeight(56 + item_height_boost)
                self["list"].l.setFont(0, _runtime_font(32 + row_primary_boost))
                self["list"].l.setFont(1, _runtime_font(26 + row_secondary_boost))
            else:
                self["list"].l.setItemHeight(40 + item_height_boost)
                self["list"].l.setFont(0, _runtime_font(22 + row_primary_boost))
                self["list"].l.setFont(1, _runtime_font(18 + row_secondary_boost))
        except Exception:
            pass

    def _favorite_row(self, location_name):
        if _use_fullhd_layout():
            row_height = 56
            left_margin = 15
            right_margin = 20
            city_width = 450
            coords_width = 564
        else:
            row_height = 40
            left_margin = 10
            right_margin = 15
            city_width = 300
            coords_width = 376
        city_text = _location_label(location_name)
        coords_text = self._favorite_coords_text(location_name)
        _tw_log("Rendering row for: %s | %s " % (city_text, coords_text))
        return [
            location_name,
            _multi_content_entry_text(pos=(left_margin, 0), size=(city_width, row_height), font=0, flags=RT_HALIGN_LEFT, text=_ui_text(city_text)),
            _multi_content_entry_text(pos=(left_margin + city_width, 0), size=(coords_width - right_margin, row_height), font=1, flags=RT_HALIGN_RIGHT, text=_ui_text(coords_text)),
        ]

    def _favorite_coords_text(self, location_name):
        location_text = _ensure_text(location_name).strip()
        if "@" in location_text:
            coords_text = location_text.rsplit("@", 1)[1].strip()
            if "," in coords_text:
                lat_text, lon_text = [part.strip() for part in coords_text.split(",", 1)]
                if lat_text and lon_text:
                    return _("Lon: %s, Lat: %s") % (lon_text, lat_text)
        return _("No coordinates")

    def _current_selected_location(self):
        if not self.res:
            return None
        try:
            index = int(self["list"].getSelectedIndex())
        except Exception:
            index = 0
        if index < 0 or index >= len(self.res):
            index = 0
        try:
            return _normalize_location_input(self.res[index][0])
        except Exception:
            return None

    def _reload_favorites_view(self, preferred_location=None, locations=None):
        if locations is None:
            self._sync_saved_locations_view(reload_locations=True)
            current_locations = list(self._plugin_saved_locations())
        else:
            current_locations = self._dedupe_locations(locations)
            self._set_saved_locations(current_locations)
        previous_index = 0
        try:
            previous_index = int(self["list"].getSelectedIndex())
        except Exception:
            previous_index = 0
        preferred_key = None
        if preferred_location:
            try:
                preferred_key = _location_compare_key(preferred_location)
            except Exception:
                preferred_key = None
        self.res[:] = []
        _tw_log("Reloading favorites view with %d current locations" % len(current_locations))
        target_index = 0
        for idx, location_name in enumerate(current_locations):
            self.res.append(self._favorite_row(location_name))
            if preferred_key is not None and _location_compare_key(location_name) == preferred_key:
                target_index = idx
        _tw_log("Added %d rows to the list widget" % len(self.res))
        _set_component_text(self["emptyinfo"], _("Use Blue to add a city.") if not current_locations else "")
        try:
            self["list"].setList(self.res)
        except Exception:
            pass
        try:
            self["list"].l.setList(self.res)
        except Exception:
            pass
        try:
            self["list"].show()
        except Exception:
            pass
        if self.res:
            if preferred_key is None:
                target_index = min(max(previous_index, 0), len(self.res) - 1)
            try:
                self["list"].moveToIndex(target_index)
            except Exception:
                pass

    def _consume_return_action(self):
        if time.time() <= self._return_action_block_until:
            self._return_action_block_until = 0.0
            return True
        return False

    def go(self):
        if self._screen_closed:
            return
        if self._consume_return_action():
            return
        if len(self._plugin_saved_locations()) <= 0 or not self.res:
            self.addLoc()
            return
        try:
            index = self["list"].getSelectedIndex()
            selecteddat = _ensure_text(self.res[index][0]).strip()
            if not selecteddat:
                return
            if self._return_selection:
                self._screen_closed = True
                _close_screen_instance(self, selecteddat)
                return
            if self._reopen_via_callback:
                self._screen_closed = True
                _close_screen_instance(self, selecteddat)
                return
            if _replace_screen(self, lambda session_: _open_weather_screen(session_, selecteddat, allow_async=True)):
                self._screen_closed = True
                return
            if not self._screen_closed:
                self._show_notice(_("Download error: Check spelling."))
        except Exception as e:
            print("[TheWeather] location go error: " + str(e))
            if not self._screen_closed:
                self._show_notice(_("Download error: No response, try again"))

    def addLoc(self):
        if self._screen_closed:
            return
        try:
            _open_virtual_keyboard(self.session, self.searchCity, _("Enter cityname e.g. london or cairo"), "")
        except Exception as e:
            print("[TheWeather] keyboard open error: " + str(e))
            if not self._screen_closed:
                self._show_notice(_("Keyboard screen is not available on this image."))

    def editLoc(self):
        if self._screen_closed or len(self._plugin_saved_locations()) <= 0 or not self.res:
            return
        current_location = self._current_selected_location()
        if not current_location:
            return
        if not _location_has_precise_coords(current_location):
            if not self._screen_closed:
                self._show_notice(_("This city entry is invalid and cannot be edited."))
            return
        self._editing_location_key = _location_compare_key(current_location)
        current_label = _display_city_only(current_location)
        try:
            _open_virtual_keyboard(self.session, self._on_edit_city_text, _("Edit cityname"), current_label)
        except Exception as e:
            print("[TheWeather] edit keyboard open error: " + str(e))
            self._editing_location_key = None
            if not self._screen_closed:
                self._show_notice(_("Keyboard screen is not available on this image."))

    def _on_edit_city_text(self, searchterm=None):
        if self._screen_closed:
            return
        searchterm = _ensure_text(searchterm).strip()
        if not searchterm:
            self._editing_location_key = None
            return
        _start_city_search(self, searchterm, self._return_from_edit_results,
                           lambda: setattr(self, "_editing_location_key", None))

    def _return_from_edit_results(self, selected_location=None):
        if self._screen_closed:
            return
        selected_location = _normalize_location_input(selected_location)
        if not selected_location:
            self._editing_location_key = None
            self._block_return_action()
            return
        self._apply_edited_location(selected_location)

    def _apply_edited_location(self, selected_location):
        editing_key = self._editing_location_key
        self._editing_location_key = None
        if not editing_key:
            return
        selected_location = _normalize_location_input(selected_location)
        if not selected_location:
            return
        try:
            active_locations = list(self._plugin_saved_locations())
            target_index = -1
            old_location = None
            for idx, location_name in enumerate(active_locations):
                if _location_compare_key(location_name) == editing_key:
                    target_index = idx
                    old_location = location_name
                    break
            if target_index < 0:
                return

            updated_locations = []
            new_key = _location_compare_key(selected_location)
            for idx, location_name in enumerate(active_locations):
                current_key = _location_compare_key(location_name)
                if idx == target_index:
                    continue
                if current_key == new_key:
                    continue
                updated_locations.append(location_name)

            insert_at = target_index if target_index <= len(updated_locations) else len(updated_locations)
            updated_locations.insert(insert_at, selected_location)
            current_locations = self._persist_favorite_locations(updated_locations, selected_location)

            current_location = _normalize_location_input(_resolve_start_location())
            if old_location and current_location and _location_compare_key(old_location) == _location_compare_key(current_location):
                _sync_active_location(selected_location, add_to_favorites=True)
        except Exception as e:
            print("[TheWeather] apply edited city error: " + str(e))

    def removeLoc(self):
        if self._screen_closed or len(self._plugin_saved_locations()) <= 0 or not self.res:
            return
        try:
            index = self["list"].getSelectedIndex()
            current_locations = list(self._plugin_saved_locations())
            removed_location = _normalize_location_input(current_locations[index])
            del current_locations[index]
            current_locations = self._persist_favorite_locations(current_locations)
            current_location = _normalize_location_input(_resolve_start_location())
            replacement_location = ""
            if removed_location and current_location and _location_compare_key(removed_location) == _location_compare_key(current_location):
                if current_locations:
                    replacement_location = current_locations[0]
                    _sync_active_location(current_locations[0])
                else:
                    restored_location = _ensure_default_location_available(force=True)
                    replacement_location = restored_location
                    _purge_location_from_config_storage(removed_location, replacement_location)
                    self._reload_favorites_view(restored_location)
                    if not self._screen_closed:
                        self._show_notice(_("Cairo restored as default city."))
                    return
            elif not current_locations:
                restored_location = _ensure_default_location_available(force=True)
                replacement_location = restored_location
                _purge_location_from_config_storage(removed_location, replacement_location)
                self._reload_favorites_view(restored_location)
                if not self._screen_closed:
                    self._show_notice(_("Cairo restored as default city."))
                return
            else:
                replacement_location = current_location
            _purge_location_from_config_storage(removed_location, replacement_location)
        except Exception as e:
            print("[TheWeather] remove location error: " + str(e))

    def searchCity(self, searchterm=None):
        if self._screen_closed:
            return
        searchterm = _ensure_text(searchterm).strip()
        if not searchterm:
            return
        _start_city_search(self, searchterm, self._return_from_search_results)

    def _return_from_search_results(self, selected_location=None):
        if self._screen_closed:
            return
        selected_location = _normalize_location_input(selected_location)
        if not selected_location:
            self._block_return_action()
            return
        self.saveSelectedCity(selected_location)

    def saveSelectedCity(self, selected_location=None):
        if self._screen_closed:
            return
        selected_location = _normalize_location_input(selected_location)
        if not selected_location:
            return
        try:
            if self._return_selection:
                self._screen_closed = True
                _close_screen_instance(self, selected_location)
                return

            compare_key = _location_compare_key(selected_location)
            reordered_locations = [selected_location]
            for saved_location in list(self._plugin_saved_locations()):
                if _location_compare_key(saved_location) == compare_key:
                    continue
                reordered_locations.append(saved_location)
            self._persist_favorite_locations(reordered_locations, selected_location)
            if not self._return_selection and not self._screen_closed:
                self._show_notice(_("City added successfully."))
        except Exception as e:
            print("[TheWeather] save selected city error: " + str(e))

    def exit(self):
        if self._screen_closed:
            return
        if self._consume_return_action():
            return
        if self._return_selection:
            self._screen_closed = True
            _close_screen_instance(self, None)
            return
        self._screen_closed = True
        _close_screen_instance(self)

    def cancel(self):
        self.exit()

