# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function ensures print() works as function in Python 2.7
from __future__ import print_function, absolute_import

# TheWeatherIet5 - plugin.py
# Supports Python 2.7, 3.12, 3.13, 3.14
# Compatible with Dreambox DM920+, Vu+ (FuturePlus), OpenATV, VTI, OpenPLi, BlackHole, and all Enigma2 images
# Temperature curve rendering supports both Dreambox (DreamOS/py2) and open-source (py3) images

from . import _
from .plugin_utils import (
    _round_half_up,
    PY3,
    unicode,
    ssl,
    Request,
    urlopen,
    _urllib_quote,
    DEFAULT_HTTP_HEADERS,
    PLUGIN_ROOT,
    THEWEATHERIET5_DATA_DIR,
    _ensure_text,
    _ensure_binary,
    _ui_text,
    _split_precise_location,
    _parse_precise_location,
    _urlopen_compat,
    _read_json_url,
    _close_response_quietly,
    _quote_url_value,
    _format_location_coordinate,
    PLUGIN_ID,
    LEGACY_PLUGIN_ID,
    _read_non_empty_lines_with_fallback,
    _read_non_empty_lines,
    _write_text_file,
    _write_binary_file,
    _write_non_empty_lines,
    _normalize_location_input,
    _location_compare_key,
    _location_has_precise_coords,
    _connect_timer,
    _disconnect_timer,
    _start_timer,
    _ensure_directory,
    _start_background_thread,
    _tw_log,
    _tw_clear_log,
    _tw_cfg,
    _tw_set_cfg,
    _tw_auto_update_choices,
    _tw_cache_choices,
    _tw_summary_color_choices,
    _tw_font_name,
    DEFAULT_FONT_NAME,
    _tw_auto_update_enabled,
    _tw_cache_max_age_seconds,
    _is_dreambox_image,
    _is_vti_image,
    _is_openatv_image,
    _is_open_source_image,
    _runtime_receiver_summary,
    _is_vuplus_box,
    _is_plausible_temperature,
    _runtime_device_family,
    _runtime_image_family,
    _display_city_only,
    _use_helpable_actions,
)
from .WeatherProviders import DEFAULT_WEATHER_SERVICE, WEATHER_SERVICE_CHOICES, WEATHER_SERVICE_DAY_LIMITS, FORECAST_DAYS

from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.config import ConfigSelection, ConfigSubsection, ConfigText, ConfigYesNo, config
try:
    from Components.ActionMap import ActionMap, HelpableActionMap
except Exception:
    from Components.ActionMap import ActionMap
    HelpableActionMap = None
from Components.ConfigList import ConfigListScreen
try:
    from Components.Pixmap import MovingPixmap
except Exception:
    MovingPixmap = None
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    try:
        from Screens.VirtualKeyboard import VirtualKeyBoard
    except Exception:
        try:
            from Screens.VirtualKeyboard import VirtualKeyboard as VirtualKeyBoard
        except Exception:
            try:
                from Screens.VirtualKeyBoard import VirtualKeyboard as VirtualKeyBoard
            except Exception:
                VirtualKeyBoard = None
try:
    from enigma import ePoint, getDesktop, eTimer
except Exception:
    ePoint = None
    getDesktop = None
    eTimer = None
import hashlib
import json
import os
import re
import sys
import threading
import time
import datetime

from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

# Preserve the established plugin API while keeping implementations separate.
from .plugin_ui import (
    _store_pixmap_position,
    _get_pixmap_position,
    _direct_move_pixmap,
    _anim_connect_timer,
    _anim_disconnect_timer,
    _stop_pixmap_animation,
    _pixmap_animation_duration,
    _manual_move_pixmap,
    _move_pixmap,
    safe_get_desktop_width,
    _normalize_action_contexts,
    _mapping_requires_helpable,
    _normalize_action_mapping,
    _ensure_menu_keymap,
    build_action_map,
    open_virtual_keyboard,
    _normalize_icon_pack_name,
    _icon_pack_has_files,
    _sanitize_icon_pack,
    _available_icon_packs,
    _icon_pack_display_name,
    _icon_pack_choices,
    _icon_pack_candidates,
    _read_saved_icon_pack,
    _write_saved_icon_pack,
    _skin_needs_legacy_color_cleanup,
    _normalize_skin_color_value,
    _plugin_relative_path,
    _plugin_absolute_path,
    _plugin_skin_path,
    _runtime_supports_scaled_pixmaps,
    _asset_directory_candidates,
    _background_skin_asset_path,
    _png_files_in_dir,
    _png_files_in_dir_uncached,
    _fallback_asset_filenames,
    _candidate_asset_relative_paths,
    _resolve_skin_asset_path,
    _resolve_skin_asset_path_uncached,
    _runtime_font_scale,
    _scale_font_size_for_runtime,
    _normalize_skin_markup,
    _apply_skin_path,
    _plugin_descriptor_icon,
    _use_fullhd_layout,
)
from .plugin_weather import (
    _normalized_weather_service_value,
    _legacy_cache_location_key,
    _cache_location_key,
    _get_weather_cache_file,
    _get_legacy_current_cache_file,
    _get_weather_cache_candidates,
    _remove_file_quietly,
    _cache_file_matches_location,
    _purge_location_from_config_storage,
    _forecast_payload_provider,
    _forecast_expected_day_count,
    _forecast_date_key,
    _forecast_rounded_temperature,
    _forecast_temperature_pair,
    _forecast_temperature_map,
    _forecast_payload_temperatures_ready,
    _forecast_payload_ready_for_apply,
    _current_weather_matches_location,
    _log_forecast_payload_apply,
    _log_forecast_temperature_changes,
    _format_last_update_label,
    _location_today_text,
    _prepare_cached_payload,
    _weather_request_context,
    _weather_request_current,
    _invalidate_weather_requests,
    _apply_weather_payload,
    _get_weather_days,
    _day_payload_ready,
    _weather_payload_ready,
    _save_weather_cache,
    _load_weather_cache,
    _refresh_weather_cache_worker,
    _fetch_key,
    _background_refresh_candidate,
    getLocalWeather,
    _get_local_weather_locked,
)
# Bind helpers before module-level desktop/config initialization. A relative
# import back into this module during startup can fail on older image loaders.
from .plugin_ui import _bind_runtime as _bind_ui_runtime
from .plugin_weather import _bind_runtime as _bind_weather_runtime
_bind_ui_runtime(sys.modules[__name__])
_bind_weather_runtime(sys.modules[__name__])

# State and variables remain here for every module and screen.
_PLUGIN_SCREENS_CACHE = None
lastUpdateTime = ""
lastUpdateIsCached = False
_lastUpdateEpoch = 0
_weatherDataLocation = ""
# One fetch at a time (queued, never overlapping) and atomic swaps of the shared forecast state.
_FETCH_LOCK = threading.Lock()
_STATE_LOCK = threading.RLock()
_LOCATION_GENERATION = [0]
_LAST_LIVE_FETCH = {}
_LAST_FETCH_ATTEMPT = {}
LIVE_FETCH_DEDUPE_SECONDS = 15
OPEN_REFRESH_MIN_INTERVAL = 2 * 60
OPEN_REFRESH_ATTEMPT_INTERVAL = 60
CACHED_CURRENT_TEMPERATURE_MAX_AGE = 15 * 60
NETWORK_TIMEOUT_STANDARD = 8
FETCH_POLL_TIMEOUT = 120
NETWORK_TIMEOUT_SHORT = 4
_startup_refresh_started = False
FAST_PIXMAP_ANIMATION_FACTOR = 0.80

MESSAGEBOX_TYPE_INFO = getattr(MessageBox, "TYPE_INFO", 0)
MESSAGEBOX_TYPE_ERROR = getattr(MessageBox, "TYPE_ERROR", MESSAGEBOX_TYPE_INFO)

if MovingPixmap is None:
    class MovingPixmap(Pixmap):
        def __init__(self):
            Pixmap.__init__(self)
            self._pending_position = None

        def moveTo(self, x, y, duration=0):
            self._pending_position = (int(x), int(y))

        def startMoving(self):
            if not self._pending_position:
                return
            try:
                if self.instance is not None:
                    self.instance.move(ePoint(self._pending_position[0], self._pending_position[1]))
            except Exception:
                pass


# Determine whether to use the safe manual pixmap move strategy.
# On Dreambox (dpkg/apt-based systems), the native moveTo/startMoving API works reliably.
# On Vu+, OpenATV, OpenSource, VTI, BlackHole images (IPK-based), use manual ePoint-based move.
USE_SAFE_PIXMAP_MOVE = not _is_dreambox_image()


try:
    STRING_TYPES = (basestring,)
except Exception:
    # Python 3: basestring does not exist, use str and bytes
    STRING_TYPES = (str, bytes)


_MENU_KEYMAP_LOADED = False


def _plugin_screens_module():
    global _PLUGIN_SCREENS_CACHE
    if _PLUGIN_SCREENS_CACHE is None:
        from . import plugin_screens
        _PLUGIN_SCREENS_CACHE = plugin_screens
    return _PLUGIN_SCREENS_CACHE

def _bind_screen_runtime():
    _plugin_screens_module().bind_runtime(globals())

def _localcityscreen_class():
    return _plugin_screens_module().localcityscreen

def _sevendays_class():
    return _plugin_screens_module().sevendays

def _weatherloading_class():
    return _plugin_screens_module().weatherloading


# # Constants and variables
DEFAULT_ICON_PACK = "Images"
AVAILABLE_ICON_PACKS = ("Images",)
ICON_PACK_ALIASES = {
    "Images": "Images",
    "Images/Default": "Images",
    "Default": "Images",
    "Images_extra": "Images",
    "Extra1": "Images",
    "Extra2": "Images",
    "Images_extra3": "Images",
    "Extra3": "Images",
}
PLUGIN_DESCRIPTOR_ICON_CANDIDATES = (
    "plugin.png",
    "Images/plugin.png",
    "Images/weerinfo.png",
)
iconpath = DEFAULT_ICON_PACK
SKIN_PIXMAP_PATTERN = re.compile(r'(?P<attr>pixmap|selectionPixmap)="(?P<path>[^"]+)"')
SKIN_COLOR_PATTERN = re.compile(r'(?P<attr>[A-Za-z]+Color)="(?P<value>#[0-9A-Fa-f]{8})"')
SKIN_FONT_PATTERN = re.compile(r'font="(?P<name>[^";]+);(?P<size>\d+)"')
SKIN_PIXMAP_TAG_PATTERN = re.compile(r'<(?P<tag>[A-Za-z0-9_]+)\b(?P<attrs>[^>]*\bpixmap="[^"]+"[^>]*?)(?P<closing>\s*/?)>')
# A picture with a zero width or height draws nothing, but Enigma2 (OpenATV 8) can crash while scaling it.
SKIN_EMPTY_PIXMAP_PATTERN = re.compile(r'<ePixmap\b[^>]*?\bsize="(?:0+,\d+|\d+,0+)"[^>]*?/>[ \t]*\r?\n?')
CANONICAL_ASSET_DIR_ALIASES = {
    "icon": ("icon", "iconhd", "iconbigsd", "iconbighd"),
    "wind": ("wind", "windhd", "windbig"),
    "lines": ("lines", "linessd"),
}
LEGACY_ASSET_DIR_TO_CANONICAL = {}
for _canonical_asset_dir, _legacy_asset_dirs in CANONICAL_ASSET_DIR_ALIASES.items():
    for _legacy_asset_dir in _legacy_asset_dirs:
        LEGACY_ASSET_DIR_TO_CANONICAL[_legacy_asset_dir] = _canonical_asset_dir
weatherData = []
state = ["", "", "", "", "", "", ""]
SavedLocalWeather = []
localCity = ""
selectedWeatherDay = 0
cityNameDisplay = ""
sz_w = safe_get_desktop_width()
FORCE_FULLHD_LAYOUT = False
PLUGIN_SKIN_PATH = PLUGIN_ROOT.replace("\\", "/")
OAWeather = resolveFilename(SCOPE_PLUGINS, "Extensions/{}".format('OAWeather'))
LEGACY_CONFIG_DIR = "/etc/enigma2"
CONFIG_DIR = THEWEATHERIET5_DATA_DIR
try:
    _ensure_directory(CONFIG_DIR)
except Exception:
    pass
LOCATIONS_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_locations.cfg")
LEGACY_LOCATIONS_FILE = [
    os.path.join(LEGACY_CONFIG_DIR, "%s.cfg" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s.cfg" % LEGACY_PLUGIN_ID),
]
LAST_LOCATION_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_last.cfg")
LEGACY_LAST_LOCATION_FILE = [
    os.path.join(LEGACY_CONFIG_DIR, "%s_last.cfg" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s_last.cfg" % LEGACY_PLUGIN_ID),
]
LAST_BACKGROUND_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_last_background.cfg")
LEGACY_LAST_BACKGROUND_FILE = [
    os.path.join(LEGACY_CONFIG_DIR, "%s_last_background.cfg" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s_last_background.cfg" % LEGACY_PLUGIN_ID),
]
SETTINGS_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_settings.cfg")
ICONPACK_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_iconpack.cfg")
LEGACY_ICONPACK_FILES = [
    os.path.join(LEGACY_CONFIG_DIR, "iconpack.cfg"),
    os.path.join(LEGACY_CONFIG_DIR, "%s_iconpack.cfg" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s_iconpack.cfg" % LEGACY_PLUGIN_ID),
]
WEATHER_CACHE_DIR = os.path.join(CONFIG_DIR, "theweatheriet5_cache")
try:
    _ensure_directory(WEATHER_CACHE_DIR)
except Exception:
    pass
LEGACY_WEATHER_CACHE_DIRS = [
    os.path.join(LEGACY_CONFIG_DIR, "%s_cache" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s_cache" % LEGACY_PLUGIN_ID),
]
DEFAULT_WEATHER_CACHE_FILE = os.path.join(WEATHER_CACHE_DIR, "theweatheriet5_default.json")
BACKGROUND_VERSION_URL = "https://www.luxsat.be/hpengine/download_files/plugins/wallpapers/daa.php?data"
BACKGROUND_HD_URL = "https://www.luxsat.be/hpengine/download_files/plugins/wallpapers/daa.php"
BACKGROUND_SD_URL = "https://www.luxsat.be/hpengine/download_files/plugins/wallpapers/daa.php?small"
# Show a validated recent forecast immediately while the screen refreshes it.
WEATHER_CACHE_FAST_OPEN_AGE = 6 * 60 * 60
WEATHER_CACHE_STALE_AGE = 7 * 24 * 60 * 60
DEFAULT_FALLBACK_LOCATION = "Cairo, Egypt@30.06263,31.24967"  # Embedded default city in plugin.py
LEGACY_DEFAULT_FALLBACK_LOCATIONS = (
    "Cairo, Egypt@30.04442,31.23571",
)
DEFAULT_CONFIG_VALUES = {
    "enabled": True,
    "automatic_update": "0",
    "weatherservice": DEFAULT_WEATHER_SERVICE,
    "weatherlocation": "",
    "apikey": "",
    "detailLevel": "more",
    "tempUnit": "Celsius",
    "windspeedMetricUnit": "km/h",
    "background": "1",
    "iconset": DEFAULT_ICON_PACK,
    "trendarrows": True,
    "cachedata": "30",
    "debug": False,
    "smartinfo": True,
    "summarycolor": "white",
    "fontbold": False,
}


# Layout Shift Constants
SEVENDAYS_CITY_SHIFT_X_HD = 0
SEVENDAYS_CITY_SHIFT_Y_HD = 10
SEVENDAYS_CITY_SHIFT_X_SD = 0
SEVENDAYS_CITY_SHIFT_Y_SD = 6
SEVENDAYS_MAIN_ICON_SHIFT_X_HD = -40
SEVENDAYS_MAIN_ICON_SHIFT_Y_HD = -4
SEVENDAYS_MAIN_ICON_SHIFT_X_SD = -22
SEVENDAYS_MAIN_ICON_SHIFT_Y_SD = -2
SEVENDAYS_WIND_ICON_SHIFT_X_HD = -44
SEVENDAYS_WIND_ICON_SHIFT_Y_HD = -20
SEVENDAYS_WIND_ICON_SHIFT_X_SD = -29
SEVENDAYS_WIND_ICON_SHIFT_Y_SD = -13
SEVENDAYS_TEMP_SHIFT_X_HD = 0
SEVENDAYS_TEMP_SHIFT_Y_HD = 0
SEVENDAYS_TEMP_UNIT_SHIFT_X_HD = -42
SEVENDAYS_TEMP_UNIT_SHIFT_Y_HD = -2
SEVENDAYS_TEMP_SHIFT_X_SD = 0
SEVENDAYS_TEMP_SHIFT_Y_SD = 0
SEVENDAYS_TEMP_UNIT_SHIFT_X_SD = -34
SEVENDAYS_TEMP_UNIT_SHIFT_Y_SD = -2
SEVENDAYS_FEELS_SHIFT_X_HD = 0
SEVENDAYS_FEELS_SHIFT_Y_HD = 0
SEVENDAYS_FEELS_SHIFT_X_SD = 0
SEVENDAYS_FEELS_SHIFT_Y_SD = 0
SEVENDAYS_WEATHER_TYPE_SHIFT_X_HD = 0
SEVENDAYS_WEATHER_TYPE_SHIFT_Y_HD = 0
SEVENDAYS_WEATHER_TYPE_SHIFT_X_SD = 0
SEVENDAYS_WEATHER_TYPE_SHIFT_Y_SD = 0
SEVENDAYS_WIND_TEXT_SHIFT_X_HD = 0
SEVENDAYS_WIND_TEXT_SHIFT_Y_HD = 0
SEVENDAYS_WIND_TEXT_SHIFT_X_SD = 0
SEVENDAYS_WIND_TEXT_SHIFT_Y_SD = 0
SEVENDAYS_TREND_SHIFT_X_HD = 0
SEVENDAYS_TREND_SHIFT_Y_HD = 0
SEVENDAYS_TREND_SHIFT_X_SD = 0
SEVENDAYS_TREND_SHIFT_Y_SD = 0
SEVENDAYS_SUN_LABEL_SHIFT_X_HD = -26
SEVENDAYS_SUN_LABEL_SHIFT_Y_HD = -34
SEVENDAYS_SUN_LABEL_SHIFT_X_SD = -16
SEVENDAYS_SUN_LABEL_SHIFT_Y_SD = -20
SEVENDAYS_SUN_ICON_SHIFT_X_HD = -40
SEVENDAYS_SUN_ICON_SHIFT_Y_HD = -36
SEVENDAYS_SUN_ICON_SHIFT_X_SD = -24
SEVENDAYS_SUN_ICON_SHIFT_Y_SD = -22
SEVENDAYS_MIDDLE_ICON_SHIFT_X_HD = 13
SEVENDAYS_MIDDLE_ICON_SHIFT_Y_HD = 8
SEVENDAYS_MIDDLE_ICON_SHIFT_X_SD = 7
SEVENDAYS_MIDDLE_ICON_SHIFT_Y_SD = 5
SEVENDAYS_MIDDLE_ICON_SIZE_HD = 65
SEVENDAYS_MIDDLE_ICON_SIZE_SD = 43
SEVENDAYS_BOTTOM_ICON_SHIFT_X_HD = 10
SEVENDAYS_BOTTOM_ICON_SHIFT_X_SD = 6

PLUGIN_FOLDER_NAME = os.path.basename(PLUGIN_ROOT)
PLUGIN_SKIN_PREFIX = "/usr/lib/enigma2/python/Plugins/Extensions/%s" % PLUGIN_ID
LEGACY_PLUGIN_SKIN_PREFIX = "/usr/lib/enigma2/python/Plugins/Extensions/%s" % LEGACY_PLUGIN_ID

try:
    with open(os.path.join(PLUGIN_ROOT, 'version.txt'), 'r') as _f:
        version = _f.read().strip()
except Exception:
    version = '4.1 modified by iet5'

HTTP_HEADERS = {
    "User-Agent": "Enigma2-TheWeatherIet5/%s" % version,
    "Accept": "application/json,text/plain,*/*",
    "Accept-Encoding": "identity",
    "Connection": "close",
}
# When the plugin was started from the menu (only used for the timing line in the log).
_PLUGIN_OPEN_STARTED = [0.0]


def _ensure_plugin_config():
    try:
        config_root = getattr(config.plugins, "TheWeatherIet5", None)
    except Exception:
        config_root = None
    if config_root is None:
        try:
            config.plugins.TheWeatherIet5 = ConfigSubsection()
            config_root = config.plugins.TheWeatherIet5
        except Exception:
            return None

    automatic_update_choices = _tw_auto_update_choices()
    weather_service_choices = list(WEATHER_SERVICE_CHOICES)
    detail_level_choices = [("more", _("More Details / Smaller font"))]
    temp_unit_choices = [("Celsius", _("Celsius")), ("Fahrenheit", _("Fahrenheit"))]
    windspeed_choices = [("km/h", "km/h"), ("m/s", "m/s")]
    background_choices = [(val, _("Background ") + val) for val in _available_background_values()]
    iconset_choices = [(DEFAULT_ICON_PACK, DEFAULT_ICON_PACK)]
    cachedata_choices = _tw_cache_choices()
    summarycolor_choices = _tw_summary_color_choices()

    def _choice_values(choices):
        values = []
        for choice in list(choices or []):
            try:
                values.append(_ensure_text(choice[0]).strip())
            except Exception:
                pass
        return values

    def _coerce_bool(value, default):
        if isinstance(value, bool):
            return value
        normalized_value = _ensure_text(value).strip().lower()
        if normalized_value in ("1", "true", "yes", "on"):
            return True
        if normalized_value in ("0", "false", "no", "off"):
            return False
        return bool(default)

    def _coerce_choice(value, choices, default):
        allowed_values = _choice_values(choices)
        fallback_value = _ensure_text(default).strip()
        if fallback_value not in allowed_values and allowed_values:
            fallback_value = allowed_values[0]
        normalized_value = _ensure_text(value).strip()
        if normalized_value in allowed_values:
            return normalized_value
        return fallback_value

    def _ensure_cfg(name, factory):
        try:
            current_value = getattr(config_root, name, None)
        except Exception:
            current_value = None
        if current_value is not None and hasattr(current_value, "value"):
            return current_value
        try:
            current_value = factory()
            setattr(config_root, name, current_value)
            return current_value
        except Exception as err:
            try:
                _tw_log("Config item init failed for %s: %s" % (name, str(err)))
            except Exception:
                pass
        return None

    enabled_item = _ensure_cfg("enabled", lambda: ConfigYesNo(default=DEFAULT_CONFIG_VALUES["enabled"]))
    automatic_update_item = _ensure_cfg("automatic_update", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["automatic_update"], choices=automatic_update_choices))
    weatherservice_item = _ensure_cfg("weatherservice", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["weatherservice"], choices=weather_service_choices))
    weatherlocation_item = _ensure_cfg("weatherlocation", lambda: ConfigText(default=DEFAULT_CONFIG_VALUES["weatherlocation"], fixed_size=False))
    apikey_item = _ensure_cfg("apikey", lambda: ConfigText(default=DEFAULT_CONFIG_VALUES["apikey"], fixed_size=False))
    detaillevel_item = _ensure_cfg("detailLevel", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["detailLevel"], choices=detail_level_choices))
    tempunit_item = _ensure_cfg("tempUnit", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["tempUnit"], choices=temp_unit_choices))
    windspeed_item = _ensure_cfg("windspeedMetricUnit", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["windspeedMetricUnit"], choices=windspeed_choices))
    background_item = _ensure_cfg("background", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["background"], choices=background_choices))
    iconset_item = _ensure_cfg("iconset", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["iconset"], choices=iconset_choices))
    trendarrows_item = _ensure_cfg("trendarrows", lambda: ConfigYesNo(default=DEFAULT_CONFIG_VALUES["trendarrows"]))
    cachedata_item = _ensure_cfg("cachedata", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["cachedata"], choices=cachedata_choices))
    debug_item = _ensure_cfg("debug", lambda: ConfigYesNo(default=DEFAULT_CONFIG_VALUES["debug"]))
    smartinfo_item = _ensure_cfg("smartinfo", lambda: ConfigYesNo(default=DEFAULT_CONFIG_VALUES["smartinfo"]))
    summarycolor_item = _ensure_cfg("summarycolor", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["summarycolor"], choices=summarycolor_choices))
    fontbold_item = _ensure_cfg("fontbold", lambda: ConfigYesNo(default=DEFAULT_CONFIG_VALUES["fontbold"]))

    for config_item, choices, default_value in (
        (automatic_update_item, automatic_update_choices, DEFAULT_CONFIG_VALUES["automatic_update"]),
        (weatherservice_item, weather_service_choices, DEFAULT_CONFIG_VALUES["weatherservice"]),
        (detaillevel_item, detail_level_choices, DEFAULT_CONFIG_VALUES["detailLevel"]),
        (tempunit_item, temp_unit_choices, DEFAULT_CONFIG_VALUES["tempUnit"]),
        (windspeed_item, windspeed_choices, DEFAULT_CONFIG_VALUES["windspeedMetricUnit"]),
        (background_item, background_choices, DEFAULT_CONFIG_VALUES["background"]),
        (iconset_item, iconset_choices, DEFAULT_CONFIG_VALUES["iconset"]),
        (cachedata_item, cachedata_choices, DEFAULT_CONFIG_VALUES["cachedata"]),
        (summarycolor_item, summarycolor_choices, DEFAULT_CONFIG_VALUES["summarycolor"]),
    ):
        if config_item is None:
            continue
        try:
            config_item.setChoices(choices, default=default_value)
        except Exception:
            pass
        try:
            config_item.value = _coerce_choice(getattr(config_item, "value", default_value), choices, default_value)
        except Exception:
            pass

    for config_item, default_value in (
        (enabled_item, DEFAULT_CONFIG_VALUES["enabled"]),
        (trendarrows_item, DEFAULT_CONFIG_VALUES["trendarrows"]),
        (debug_item, DEFAULT_CONFIG_VALUES["debug"]),
        (smartinfo_item, DEFAULT_CONFIG_VALUES["smartinfo"]),
        (fontbold_item, DEFAULT_CONFIG_VALUES["fontbold"]),
    ):
        if config_item is None:
            continue
        try:
            config_item.value = _coerce_bool(getattr(config_item, "value", default_value), default_value)
        except Exception:
            pass

    for config_item, default_value in (
        (weatherlocation_item, DEFAULT_CONFIG_VALUES["weatherlocation"]),
        (apikey_item, DEFAULT_CONFIG_VALUES["apikey"]),
    ):
        if config_item is None:
            continue
        try:
            config_item.value = _ensure_text(getattr(config_item, "value", default_value))
        except Exception:
            pass

    return config_root


try:
    _ensure_plugin_config()
except Exception as err:
    try:
        _tw_log("Plugin config bootstrap failed: %s" % str(err))
    except Exception:
        pass

def _open_virtual_keyboard(session, callback, title, text=""):
    return open_virtual_keyboard(
        session,
        callback,
        title,
        text,
        text_converter=_ui_text,
        unavailable_message=_ui_text(_("Keyboard screen is not available on this image.")),
    )

def _append_unique_location(location_name):
    global SavedLocalWeather
    normalized_location = _canonicalize_embedded_default_location(location_name)
    if not normalized_location:
        return False
    if not _location_has_precise_coords(normalized_location):
        return False
    compare_key = _location_compare_key(normalized_location)
    for saved_location in list(SavedLocalWeather):
        if _location_compare_key(saved_location) == compare_key:
            return False
    SavedLocalWeather.append(normalized_location)
    return True


def _configured_weather_location():
    return _canonicalize_embedded_default_location(_runtime_config_value("weatherlocation"))


def _canonicalize_embedded_default_location(location_name):
    normalized_location = _normalize_location_input(location_name)
    if not normalized_location:
        return ""
    for legacy_location in LEGACY_DEFAULT_FALLBACK_LOCATIONS:
        if _location_compare_key(normalized_location) == _location_compare_key(legacy_location):
            return DEFAULT_FALLBACK_LOCATION
    return normalized_location


_cached_background_values = None

def _should_refresh_background_catalog():
    image_family = _runtime_image_family()
    device_family = _runtime_device_family()
    return bool(
        image_family in ("dreamos", "vti", "openatv", "open-source", "generic-enigma2") or
        device_family in ("dreambox", "vuplus")
    )

def _available_background_values():
    global _cached_background_values
    if _should_refresh_background_catalog():
        _cached_background_values = None
    if _cached_background_values is not None:
        return _cached_background_values

    choices = set()
    try:
        bg_dir = os.path.join(os.path.dirname(__file__), "Images", "background")
        if os.path.isdir(bg_dir):
            for f in os.listdir(bg_dir):
                match = re.match(r"^backgroundhd\+(\d+)\.png$", f, re.IGNORECASE)
                if match:
                    choices.add(int(match.group(1)))
                else:
                    match_non_hd = re.match(r"^background\+(\d+)\.png$", f, re.IGNORECASE)
                    if match_non_hd:
                        choices.add(int(match_non_hd.group(1)))
        
        if not choices:
            choices.add(1)
            
        sorted_choices = sorted(list(choices))
        _cached_background_values = [str(i) for i in sorted_choices]
        return _cached_background_values
    except Exception:
        return [str(i) for i in range(1, 17)]


def _normalize_background_value(background_value, default="1"):
    valid_values = _available_background_values()
    normalized_default = _ensure_text(default).strip()
    if normalized_default not in valid_values:
        normalized_default = valid_values[0]
    normalized_value = _ensure_text(background_value).strip()
    if normalized_value in valid_values:
        return normalized_value
    return normalized_default


def _configured_background():
    return _normalize_background_value(_runtime_config_value("background"))


TRACKED_CONFIG_KEYS = (
    "enabled",
    "automatic_update",
    "weatherservice",
    "weatherlocation",
    "apikey",
    "detailLevel",
    "tempUnit",
    "windspeedMetricUnit",
    "background",
    "iconset",
    "trendarrows",
    "cachedata",
    "debug",
    "smartinfo",
    "summarycolor",
    "fontbold",
)
BOOLEAN_CONFIG_KEYS = ("enabled", "trendarrows", "debug", "smartinfo", "fontbold")


def _runtime_config_root():
    try:
        _ensure_plugin_config()
    except Exception:
        pass
    try:
        return getattr(config.plugins, "TheWeatherIet5", None)
    except Exception:
        return None


def _runtime_config_value(attr):
    config_root = _runtime_config_root()
    fallback_value = DEFAULT_CONFIG_VALUES.get(attr, "")
    if config_root is None or not hasattr(config_root, attr):
        return fallback_value
    config_item = getattr(config_root, attr)
    return getattr(config_item, "value", fallback_value)


def _serialize_config_value(attr, value):
    if attr in BOOLEAN_CONFIG_KEYS:
        return "true" if bool(value) else "false"
    return _ensure_text(value).strip()


def _coerce_saved_config_value(attr, value):
    text_value = _ensure_text(value).strip()
    if attr in BOOLEAN_CONFIG_KEYS:
        return text_value.lower() in ("1", "true", "yes", "on")
    if attr == "background":
        return _normalize_background_value(text_value)
    if attr == "automatic_update":
        valid_values = [choice[0] for choice in _tw_auto_update_choices()]
        return text_value if text_value in valid_values else DEFAULT_CONFIG_VALUES.get(attr, "0")
    if attr == "cachedata":
        valid_values = [choice[0] for choice in _tw_cache_choices()]
        return text_value if text_value in valid_values else DEFAULT_CONFIG_VALUES.get(attr, "30")
    if attr == "summarycolor":
        valid_values = [choice[0] for choice in _tw_summary_color_choices()]
        return text_value if text_value in valid_values else DEFAULT_CONFIG_VALUES.get(attr, "white")
    if attr == "weatherservice":
        valid_values = [choice[0] for choice in WEATHER_SERVICE_CHOICES]
        return text_value if text_value in valid_values else DEFAULT_CONFIG_VALUES.get(attr, DEFAULT_WEATHER_SERVICE)
    if attr == "detailLevel":
        return text_value if text_value == "more" else DEFAULT_CONFIG_VALUES.get(attr, "more")
    if attr == "tempUnit":
        return text_value if text_value in ("Celsius", "Fahrenheit") else DEFAULT_CONFIG_VALUES.get(attr, "Celsius")
    if attr == "windspeedMetricUnit":
        return text_value if text_value in ("km/h", "m/s") else DEFAULT_CONFIG_VALUES.get(attr, "km/h")
    if attr == "iconset":
        return _sanitize_icon_pack(text_value or DEFAULT_CONFIG_VALUES.get(attr, DEFAULT_ICON_PACK))
    if text_value == "":
        return DEFAULT_CONFIG_VALUES.get(attr, "")
    return text_value


def _read_saved_settings_map():
    settings_map = {}
    for raw_line in _read_non_empty_lines(SETTINGS_FILE):
        if "=" not in raw_line:
            continue
        key, value = raw_line.split("=", 1)
        key = _ensure_text(key).strip()
        if not key:
            continue
        settings_map[key] = _ensure_text(value).strip()
    return settings_map


def _write_saved_settings_map(settings_map):
    lines = []
    for key in TRACKED_CONFIG_KEYS:
        if key not in settings_map:
            continue
        lines.append("%s=%s" % (key, _ensure_text(settings_map[key]).strip()))
    try:
        _write_non_empty_lines(SETTINGS_FILE, lines)
    except Exception:
        pass
    return settings_map


def _current_settings_snapshot():
    snapshot = {}
    for key in TRACKED_CONFIG_KEYS:
        snapshot[key] = _serialize_config_value(key, _runtime_config_value(key))
    snapshot["background"] = _normalize_background_value(snapshot.get("background", "1"))
    return snapshot


def _persist_runtime_settings():
    _ensure_plugin_config()
    snapshot = _current_settings_snapshot()
    _write_saved_settings_map(snapshot)
    return snapshot


def _load_runtime_settings():
    _ensure_plugin_config()
    settings_map = _read_saved_settings_map()
    if not settings_map:
        _persist_runtime_settings()
        return {}
    for key in TRACKED_CONFIG_KEYS:
        if key not in settings_map:
            continue
        try:
            _tw_set_cfg(key, _coerce_saved_config_value(key, settings_map.get(key, "")), save=False)
        except Exception:
            pass
    _persist_runtime_settings()
    return settings_map


def _initialize_runtime_storage():
    try:
        _ensure_directory(CONFIG_DIR)
        _ensure_directory(WEATHER_CACHE_DIR)
    except Exception:
        pass

    resolved_location = (
        _configured_weather_location() or
        _normalize_location_input(DEFAULT_FALLBACK_LOCATION)
    )
    resolved_background = _normalize_background_value(_configured_background(), DEFAULT_CONFIG_VALUES.get("background", "1"))
    resolved_icon_pack = _sanitize_icon_pack(_runtime_config_value("iconset") or DEFAULT_ICON_PACK)

    try:
        if not _read_non_empty_lines(SETTINGS_FILE):
            _persist_runtime_settings()
    except Exception:
        pass

    try:
        if not _read_non_empty_lines_with_fallback(LOCATIONS_FILE, LEGACY_LOCATIONS_FILE):
            _write_non_empty_lines(LOCATIONS_FILE, [resolved_location])
    except Exception:
        pass

    try:
        if not _read_non_empty_lines_with_fallback(LAST_LOCATION_FILE, LEGACY_LAST_LOCATION_FILE):
            _write_text_file(LAST_LOCATION_FILE, resolved_location)
    except Exception:
        pass

    try:
        if not _read_non_empty_lines_with_fallback(LAST_BACKGROUND_FILE, LEGACY_LAST_BACKGROUND_FILE):
            _write_text_file(LAST_BACKGROUND_FILE, resolved_background)
    except Exception:
        pass

    try:
        if not _read_non_empty_lines_with_fallback(ICONPACK_FILE, LEGACY_ICONPACK_FILES):
            _write_text_file(ICONPACK_FILE, resolved_icon_pack)
    except Exception:
        pass

    try:
        _tw_log("Runtime storage initialized under %s" % str(CONFIG_DIR))
    except Exception:
        pass

    return resolved_location


def _sync_active_background(background_value=None):
    normalized_background = _normalize_background_value(background_value, _configured_background())
    try:
        _write_text_file(LAST_BACKGROUND_FILE, normalized_background)
    except Exception:
        pass
    try:
        _tw_set_cfg("background", normalized_background)
    except Exception:
        pass
    _persist_runtime_settings()
    return normalized_background


def _restore_last_background():
    configured_background = _configured_background()
    last_backgrounds = _read_non_empty_lines_with_fallback(LAST_BACKGROUND_FILE, LEGACY_LAST_BACKGROUND_FILE)
    resolved_background = configured_background
    if last_backgrounds:
        resolved_background = _normalize_background_value(last_backgrounds[-1], configured_background)
    try:
        _tw_set_cfg("background", resolved_background)
    except Exception:
        pass
    try:
        if not last_backgrounds or resolved_background != _ensure_text(last_backgrounds[-1]).strip():
            _write_text_file(LAST_BACKGROUND_FILE, resolved_background)
    except Exception:
        pass
    try:
        _tw_log("Resolved start background: %s" % str(resolved_background))
    except Exception:
        pass
    return resolved_background


def _sync_active_location(location_name, add_to_favorites=False):
    global localCity, cityNameDisplay
    normalized_location = _canonicalize_embedded_default_location(location_name)
    if not normalized_location:
        return ""
    with _STATE_LOCK:
        if _location_compare_key(normalized_location) != _location_compare_key(localCity):
            _LOCATION_GENERATION[0] += 1
        localCity = normalized_location
        cityNameDisplay = _display_city_only(normalized_location)
    try:
        _write_text_file(LAST_LOCATION_FILE, normalized_location)
    except Exception:
        pass
    try:
        _tw_set_cfg("weatherlocation", normalized_location)
    except Exception:
        pass
    _persist_runtime_settings()
    try:
        if not _location_has_precise_coords(normalized_location):
            _tw_log("Active location synchronized without adding to favorites: %s" % str(normalized_location))
            return normalized_location

        current_key = _location_compare_key(normalized_location)
        updated_locations = []
        found_existing = False
        for saved_location in list(SavedLocalWeather):
            if _location_compare_key(saved_location) == current_key:
                if not found_existing:
                    updated_locations.append(normalized_location)
                    found_existing = True
                continue
            updated_locations.append(saved_location)

        if add_to_favorites:
            if not found_existing:
                updated_locations.insert(0, normalized_location)
            else:
                updated_locations = [normalized_location] + [
                    saved_location for saved_location in list(updated_locations)
                    if _location_compare_key(saved_location) != current_key
                ]
            _tw_log("Active location added/promoted in favorites: %s" % str(normalized_location))
        elif not updated_locations and not found_existing:
            updated_locations = [normalized_location]
            _tw_log("Active location synchronized as the first saved favorite: %s" % str(normalized_location))
        elif found_existing:
            _tw_log("Active location synchronized without changing favorites order: %s" % str(normalized_location))
        else:
            _tw_log("Active location synchronized without storing in favorites order: %s" % str(normalized_location))

        SavedLocalWeather[:] = updated_locations
        _write_non_empty_lines(LOCATIONS_FILE, SavedLocalWeather)
    except Exception as e:
        _tw_log("Sync error in _sync_active_location: %s" % str(e))
    return normalized_location


def _ensure_default_location_available(force=False):
    global SavedLocalWeather
    default_location = _canonicalize_embedded_default_location(DEFAULT_FALLBACK_LOCATION)
    if not default_location:
        return ""
    try:
        _ensure_directory(CONFIG_DIR)
        _ensure_directory(WEATHER_CACHE_DIR)
    except Exception:
        pass
    normalized_existing = []
    seen_keys = set()
    for saved_location in list(SavedLocalWeather):
        normalized_saved = _canonicalize_embedded_default_location(saved_location)
        if not normalized_saved:
            continue
        compare_key = _location_compare_key(normalized_saved)
        if compare_key in seen_keys:
            continue
        seen_keys.add(compare_key)
        normalized_existing.append(normalized_saved)
    has_locations = bool(normalized_existing)
    if not force and has_locations:
        SavedLocalWeather[:] = normalized_existing
        return _normalize_location_input(SavedLocalWeather[0])
    reordered_locations = [default_location]
    default_key = _location_compare_key(default_location)
    for normalized_saved in normalized_existing:
        if _location_compare_key(normalized_saved) == default_key:
            continue
        reordered_locations.append(normalized_saved)
    SavedLocalWeather[:] = reordered_locations
    try:
        _write_non_empty_lines(LOCATIONS_FILE, SavedLocalWeather)
    except Exception:
        pass
    last_locations = _read_non_empty_lines_with_fallback(LAST_LOCATION_FILE, LEGACY_LAST_LOCATION_FILE)
    if force or not last_locations:
        try:
            _write_text_file(LAST_LOCATION_FILE, default_location)
        except Exception:
            pass
    try:
        if force or not _configured_weather_location():
            _tw_set_cfg("weatherlocation", default_location)
    except Exception:
        pass
    try:
        _tw_log("Embedded default location restored from plugin.py: %s" % str(default_location))
    except Exception:
        pass
    return default_location


def _bootstrap_embedded_default_city():
    try:
        _ensure_directory(CONFIG_DIR)
        _ensure_directory(WEATHER_CACHE_DIR)
    except Exception:
        pass
    locations = _read_non_empty_lines_with_fallback(LOCATIONS_FILE, LEGACY_LOCATIONS_FILE)
    if locations:
        return _canonicalize_embedded_default_location(locations[0])
    configured_location = _configured_weather_location()
    if configured_location:
        return configured_location
    last_locations = _read_non_empty_lines_with_fallback(LAST_LOCATION_FILE, LEGACY_LAST_LOCATION_FILE)
    if last_locations:
        resolved_last = _canonicalize_embedded_default_location(last_locations[-1])
        if resolved_last:
            return resolved_last
    return _ensure_default_location_available(force=True)

def _read_all_saved_locations():
    merged_locations = []
    seen_paths = set()
    candidate_paths = [LOCATIONS_FILE]
    # Once the dedicated locations file exists, treat it as the single source of truth.
    # This prevents deleted favorites from being resurrected by stale legacy files.
    primary_exists = False
    try:
        primary_exists = os.path.exists(LOCATIONS_FILE)
    except Exception:
        primary_exists = False
    if not primary_exists:
        for legacy_path in list(LEGACY_LOCATIONS_FILE or []):
            candidate_paths.append(legacy_path)
    for candidate_path in candidate_paths:
        if not candidate_path or candidate_path in seen_paths:
            continue
        seen_paths.add(candidate_path)
        for saved_location in _read_non_empty_lines(candidate_path):
            normalized_location = _canonicalize_embedded_default_location(saved_location)
            if normalized_location:
                merged_locations.append(normalized_location)
    return merged_locations


_PNG_DIR_CACHE = {}


_ASSET_PATH_CACHE = {}


def _load_icon_pack():
    global iconpath
    saved_icon_pack = ""
    try:
        saved_icon_pack = _read_saved_icon_pack()
    except Exception:
        saved_icon_pack = ""
    if not saved_icon_pack:
        saved_icon_pack = _tw_cfg("iconset", "")
    iconpath = _sanitize_icon_pack(saved_icon_pack or DEFAULT_ICON_PACK)
    return iconpath


def _open_sevendays_screen(session, callback=None):
    global lastUpdateTime
    try:
        lastUpdateTime = _format_last_update_label()
    except Exception:
        pass
    ready, reason = _forecast_payload_ready_for_apply(weatherData)
    if not ready:
        try:
            _tw_log("sevendays open skipped: %s" % _ensure_text(reason))
        except Exception:
            pass
        return False
    try:
        if callback:
            session.openWithCallback(callback, _sevendays_class())
        else:
            session.open(_sevendays_class())
        return True
    except Exception as e:
        _tw_log("sevendays open error: " + str(e))
    return False


def _schedule_background_assets_update():
    # Backgrounds are managed locally; there is no download job to schedule.
    return False


def _stop_weather_open_timer(session):
    state = getattr(session, "_weather_open_state", None)
    if state is not None:
        state["cancelled"] = True
        session._weather_open_state = None
    timer = getattr(session, "_weather_open_timer", None)
    callback = getattr(session, "_weather_open_callback", None)
    try:
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            if callback is not None:
                _disconnect_timer(timer, callback)
    except Exception as e:
        print("[TheWeather] weather timer cleanup error: " + str(e))
    try:
        session._weather_open_timer = None
    except Exception:
        pass
    try:
        session._weather_open_callback = None
    except Exception:
        pass

def _clear_session_update_timers(session):
    """Stop any deferred background timers when automatic update is disabled."""
    if session is None:
        return False
    stopped_any = False
    try:
        stopped_any = getattr(session, "_weather_open_timer", None) is not None
        _stop_weather_open_timer(session)
    except Exception:
        pass
    for timer_attr in ("_tw_restart_timer", "_tw_bg_restart_timer"):
        try:
            timer = getattr(session, timer_attr, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception:
                    pass
                setattr(session, timer_attr, None)
                stopped_any = True
        except Exception:
            pass
    return stopped_any

def _start_deferred_weather_open(session, location_name, callback=None):
    if eTimer is None:
        return False
    _stop_weather_open_timer(session)
    context = _weather_request_context()
    state = {"done": False, "success": False, "cancelled": False}
    poll_started = time.time()
    original_dialog = getattr(session, "current_dialog", None)

    def fetch_weather():
        try:
            state["success"] = bool(getLocalWeather(location_name, context))
        except Exception as exc:
            _tw_log("Deferred weather open failed: %s" % str(exc))
        finally:
            state["done"] = True

    def poll_weather():
        if state["cancelled"]:
            return
        if not _weather_request_current(context) or getattr(session, "current_dialog", None) is not original_dialog:
            _stop_weather_open_timer(session)
            return
        if not state["done"]:
            if time.time() - poll_started < FETCH_POLL_TIMEOUT:
                _start_timer(timer, 200)
                return
            _invalidate_weather_requests(context)
        _stop_weather_open_timer(session)
        if state["success"] and _open_sevendays_screen(session, callback):
            return
        session.open(_localcityscreen_class())

    timer = eTimer()
    session._weather_open_timer = timer
    session._weather_open_callback = poll_weather
    session._weather_open_state = state
    try:
        _connect_timer(timer, poll_weather)
        if _start_background_thread(fetch_weather) is None:
            _stop_weather_open_timer(session)
            return False
        _start_timer(timer, 200)
        return True
    except Exception as exc:
        _stop_weather_open_timer(session)
        _tw_log("Deferred weather timer failed: %s" % str(exc))
        return False


def _open_weather_screen(session, location_name, allow_async=True, callback=None):
    try:
        location_name = _normalize_location_input(location_name)
        if not location_name:
            return False
        if not _tw_auto_update_enabled():
            try:
                if _clear_session_update_timers(session):
                    _tw_log("Background timers cleared before manual weather open")
            except Exception:
                pass
        _load_icon_pack()
        _schedule_background_assets_update()
        location_name = _sync_active_location(location_name)
        _stop_weather_open_timer(session)
        cache_max_age = _tw_cache_max_age_seconds()
        # Reopening the same city does not need another disk read or a loading screen.
        if cache_max_age > 0 and _current_weather_matches_location(location_name):
            memory_age = time.time() - _lastUpdateEpoch
            if (0 <= memory_age <= cache_max_age and
                    _forecast_payload_provider(weatherData) == _normalized_weather_service_value() and
                    _forecast_payload_ready_for_apply(weatherData)[0] and
                    _open_sevendays_screen(session, callback)):
                _tw_log("Opened weather immediately from current runtime data")
                return True
        # On manual plugin open, respect Cache data duration first.
        if cache_max_age > 0 and _load_weather_cache(location_name, cache_max_age, False) and _open_sevendays_screen(session, callback):
            _tw_log("Opened weather from valid cache window (%s seconds)" % str(cache_max_age))
            return True
        # A recently expired cache can still show the forecast without waiting for
        # the network. sevendays._start_open_refresh updates it in the background.
        # Keep Cache data = disabled meaningful and reject older/invalid forecasts.
        if (cache_max_age > 0 and
                _load_weather_cache(location_name, max(cache_max_age, WEATHER_CACHE_FAST_OPEN_AGE), False) and
                _open_sevendays_screen(session, callback)):
            _tw_log("Opened recent cached weather immediately; refreshing in background")
            return True
        # Network access never runs on the GUI thread: the loading screen/worker thread is used
        # whenever the caller allows it, independently of the periodic "Auto Update" setting.
        use_async_open = bool(allow_async)
        if use_async_open:
            try:
                if callback:
                    session.open(_weatherloading_class(), location_name, cache_max_age, callback=callback)
                else:
                    session.open(_weatherloading_class(), location_name, cache_max_age)
                return True
            except Exception as e:
                _tw_log("weatherloading open error for " + str(location_name) + ": " + str(e))
                return _start_deferred_weather_open(session, location_name, callback)
        if getLocalWeather(location_name) and _open_sevendays_screen(session, callback):
            return True
        if _load_weather_cache(location_name, None, True) and _open_sevendays_screen(session, callback):
            return True
    except Exception as e:
        _tw_log("open weather screen error for " + str(location_name) + ": " + str(e))
    return False


def _load_saved_locations():
    global SavedLocalWeather
    SavedLocalWeather[:] = []
    try:
        _ensure_directory(CONFIG_DIR)
        _ensure_directory(WEATHER_CACHE_DIR)
    except Exception:
        pass
    _bootstrap_embedded_default_city()
    original_locations = _read_all_saved_locations()
    _tw_log("Read from files: %d initial entries" % len(original_locations))
    for saved_location in original_locations:
        normalized_location = _canonicalize_embedded_default_location(saved_location)
        if normalized_location:
            _append_unique_location(normalized_location)
    _tw_log("After normalization and deduplication: %d entries" % len(SavedLocalWeather))
    configured_location = _configured_weather_location()
    if configured_location and not original_locations and not SavedLocalWeather:
        if _append_unique_location(configured_location):
            _tw_log("Migrated configured weather location into favorites: %s" % str(configured_location))
    if not SavedLocalWeather:
        _tw_log("No favorites found, restoring default city.")
        _ensure_default_location_available(force=True)
    try:
        _write_non_empty_lines(LOCATIONS_FILE, SavedLocalWeather)
    except Exception:
        pass
    _tw_log("Final favorites count: %d" % len(SavedLocalWeather))

def _remember_last_city_on_exit():
    # The city shown when the plugin (or its main screen) closes is the one the plugin starts with next time.
    city = _normalize_location_input(localCity)
    if not city:
        return False
    try:
        _write_text_file(LAST_LOCATION_FILE, city)
        _tw_log("Last city saved on exit: %s" % str(city))
        return True
    except Exception as error:
        _tw_log("Last city could not be saved: %s" % str(error))
        return False

def _resolve_start_location():
    last_locations = _read_non_empty_lines_with_fallback(LAST_LOCATION_FILE, LEGACY_LAST_LOCATION_FILE)
    if last_locations:
        raw_location = last_locations[-1]
        resolved = _canonicalize_embedded_default_location(raw_location)
        if resolved and resolved != _ensure_text(raw_location).strip():
            try:
                _write_text_file(LAST_LOCATION_FILE, resolved)
                _tw_log("Migrated last location file to normalized format")
            except Exception:
                pass
        try:
            _tw_log("Start location from last file %s: %s" % (str(LAST_LOCATION_FILE), str(resolved)))
        except Exception:
            pass
        return resolved
    configured_location = _configured_weather_location()
    if configured_location:
        try:
            _tw_log("Start location from TheWeatherIet5 config: %s" % str(configured_location))
        except Exception:
            pass
        return configured_location
    if SavedLocalWeather:
        resolved = _canonicalize_embedded_default_location(SavedLocalWeather[0])
        try:
            _tw_log("Start location from favorites fallback: %s" % str(resolved))
        except Exception:
            pass
        return resolved
    default_location = _ensure_default_location_available(force=True)
    if default_location:
        try:
            _tw_log("Start location from embedded default: %s" % str(default_location))
        except Exception:
            pass
        return default_location
    try:
        _tw_log("No start location found. Last path checked: %s" % str(LAST_LOCATION_FILE))
    except Exception:
        pass
    return ""

_bind_screen_runtime()

def main(session, **kwargs):
    _PLUGIN_OPEN_STARTED[0] = time.time()
    _tw_clear_log()
    _tw_log("Plugin started (main)")
    global iconpath
    _initialize_runtime_storage()
    _load_runtime_settings()
    _bootstrap_embedded_default_city()
    _restore_last_background()
    _load_saved_locations()
    location = _resolve_start_location()
    if not location:
        location = _ensure_default_location_available(force=True)
    try:
        _tw_log("Config dir: %s" % str(CONFIG_DIR))
        _tw_log("Resolved start location in main: %s" % str(location))
    except Exception:
        pass

    _load_icon_pack()
    _schedule_background_assets_update()

    def _on_plugin_exit(result=None):
        _tw_log("[Main] Plugin screen closed with result: %s" % str(result))
        if result == "RESTART_PLUGIN":
            # Fallback: plugin_screens.py now handles RESTART_PLUGIN directly via
            # _schedule_plugin_restart(). This path is kept for backward compatibility.
            _tw_log("[Main] Restart signal received, scheduling 1000ms delayed re-open...")
            if eTimer is None:
                try:
                    main(session)
                except Exception as e:
                    _tw_log("[Main] Restart fallback failed: %s" % str(e))
                return
            # Cancel bg-switch restart timer from plugin_screens to avoid double-launch
            try:
                bg_timer = getattr(session, "_tw_bg_restart_timer", None)
                if bg_timer is not None:
                    bg_timer.stop()
                    session._tw_bg_restart_timer = None
            except Exception:
                pass
            # Stop any previous restart timer
            try:
                old_timer = getattr(session, "_tw_restart_timer", None)
                if old_timer is not None:
                    old_timer.stop()
                    session._tw_restart_timer = None
            except Exception:
                pass

            session._tw_restart_timer = eTimer()

            def _restart():
                try:
                    t = getattr(session, "_tw_restart_timer", None)
                    if t is not None:
                        t.stop()
                        _disconnect_timer(t, _restart)
                    session._tw_restart_timer = None
                except Exception:
                    pass
                _tw_log("[Main] Restart timer fired, re-opening plugin now...")
                try:
                    main(session)
                    _tw_log("[Main] Restart: main(session) executed successfully")
                except Exception as e:
                    _tw_log("[Main] Restart: main(session) failed: %s" % str(e))

            _connect_timer(session._tw_restart_timer, _restart)
            _start_timer(session._tw_restart_timer, 1000)

    try:
        _tw_log("Plugin prepared in %d ms (settings, favorites, icon pack); opening the weather screen" % int((time.time() - _PLUGIN_OPEN_STARTED[0]) * 1000))
        _tw_log("Receiver: %s" % _runtime_receiver_summary())
    except Exception:
        pass
    if location and _open_weather_screen(session, location, True, _on_plugin_exit):
        return
    fallback_location = _ensure_default_location_available(force=True)
    if fallback_location and fallback_location != location and _open_weather_screen(session, fallback_location, True, _on_plugin_exit):
        return
    try:
        _tw_log("Opening startup location selector")
        session.open(_localcityscreen_class())
    except Exception as e:
        _tw_log("main localcityscreen open error: " + str(e))
        try:
            session.open(MessageBox, _ui_text(_("Startup screen error: ")) + _ui_text(str(e)), MESSAGEBOX_TYPE_ERROR)
        except Exception:
            pass

def _refresh_default_city_on_startup():
    location = ""
    try:
        _initialize_runtime_storage()
        if not _tw_auto_update_enabled():
            _tw_log("Startup refresh skipped: automatic update disabled")
            return
        _load_runtime_settings()
        _bootstrap_embedded_default_city()
        _restore_last_background()
        _load_saved_locations()
        location = _resolve_start_location()
        _load_icon_pack()
        _schedule_background_assets_update()
        if not location:
            _tw_log("Startup refresh skipped: no default city found")
            return
        _tw_log("Startup refresh for default city: %s" % str(location))
        cache_max_age = _tw_cache_max_age_seconds()
        if cache_max_age > 0 and _load_weather_cache(location, cache_max_age, False):
            _tw_log("Startup refresh skipped: valid cache still within %s seconds" % str(cache_max_age))
            return
        getLocalWeather(location)
    except Exception as e:
        _tw_log("Startup refresh error for %s: %s" % (str(location), str(e)))

def sessionstart(session, **kwargs):
    global _startup_refresh_started
    if _startup_refresh_started:
        return
    _startup_refresh_started = True
    _initialize_runtime_storage()
    _tw_log("Plugin sessionstart detected")
    if not _tw_auto_update_enabled():
        _tw_log("Session startup background refresh disabled by user setting")
        return
    _start_background_thread(_refresh_default_city_on_startup)

def Plugins(path, **kwargs):
    return [
        PluginDescriptor(name=PLUGIN_ID, description="WeatherInfo",
                         icon=_plugin_descriptor_icon(),
                         where=[PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU],
                         fnc=main),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart),
    ]
