"""Fast-open and compressed transport checks without a network or receiver."""
import datetime
import importlib
import json
import sys
import tempfile
import time
import types
import unittest
import zlib
from pathlib import Path

from test_plugin_loading import ROOT, module, receiver_stubs

sys.dont_write_bytecode = True
CITY = "Wurzbach, Germany@50.46,11.54"


def forecast():
    today = datetime.date.today()
    return {"provider": "open-meteo", "screen_days": 16, "days": [
        {"date": (today + datetime.timedelta(days=i)).isoformat(),
         "mintemperature": 10, "maxtemperature": 20, "iconcode": "a",
         "sunrise": "06:00", "sunset": "18:00",
         "hours": [{"hour": 12, "temperature": 18, "iconcode": "a"}]}
        for i in range(16)]}


class Loading(object):
    pass


class FastOpenTests(unittest.TestCase):
    counter = 0

    def setUp(self):
        receiver_stubs()
        type(self).counter += 1
        self.prefix = "weather_fast_open_%s" % self.counter
        pkg = module(self.prefix)
        pkg.__path__ = [str(ROOT)]
        pkg._ = lambda text: text
        pkg.isDreambox = False
        self.storage = tempfile.TemporaryDirectory(prefix=".weather_fast_", dir=str(ROOT))
        self.assertEqual(Path(self.storage.name).resolve().parent, ROOT)
        self.addCleanup(self.storage.cleanup)
        self.utils = importlib.import_module(self.prefix + ".plugin_utils")
        self.utils.THEWEATHERIET5_DATA_DIR = self.storage.name
        self.utils.THEWEATHERIET5_LOG_FILE = str(Path(self.storage.name) / "log.txt")
        self.utils._tw_log = lambda *args: None
        self.plugin = importlib.import_module(self.prefix + ".plugin")
        plugin = self.plugin
        plugin._tw_cache_max_age_seconds = lambda: 1800
        plugin._tw_auto_update_enabled = lambda: False
        plugin._clear_session_update_timers = lambda session: False
        plugin._load_icon_pack = lambda: None
        plugin._schedule_background_assets_update = lambda: None
        plugin._sync_active_location = lambda city: city
        plugin._stop_weather_open_timer = lambda session: None
        plugin._weatherloading_class = lambda: Loading
        self.events = []
        self.session = types.SimpleNamespace(open=lambda *args, **kwargs: self.events.append(("loading", args, kwargs)))
        plugin._open_sevendays_screen = lambda session, callback=None: self.events.append(("weather", callback)) or True
        plugin.getLocalWeather = lambda *args: self.fail("Network must not run on the UI thread")

    def cache(self, age, service="open-meteo", bad=False):
        plugin = self.plugin
        data = forecast()
        if bad:
            data["days"][0]["mintemperature"] = 30
        path = Path(plugin._get_weather_cache_file(CITY))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"timestamp": int(time.time()) - age,
                                   "location": CITY, "service": service,
                                   "display_name": "Wurzbach", "weather": data}), encoding="utf-8")

    def test_current_memory_opens_without_disk_or_loading(self):
        plugin = self.plugin
        plugin.weatherData = forecast()
        plugin._weatherDataLocation = CITY
        plugin._lastUpdateEpoch = int(time.time())
        plugin._load_weather_cache = lambda *args: self.fail("Fresh memory must not reread disk")
        self.assertTrue(plugin._open_weather_screen(self.session, CITY))
        self.assertEqual(self.events, [("weather", None)])

    def test_fresh_cache_opens_without_loading(self):
        self.cache(60)
        callback = lambda: None
        self.assertTrue(self.plugin._open_weather_screen(self.session, CITY, callback=callback))
        self.assertEqual(self.events, [("weather", callback)])
        self.assertTrue(self.plugin.lastUpdateIsCached)

    def test_recent_expired_cache_opens_and_schedules_refresh(self):
        self.cache(3600)
        plugin = self.plugin
        self.assertTrue(plugin._open_weather_screen(self.session, CITY))
        self.assertEqual(self.events, [("weather", None)])
        self.assertTrue(plugin.lastUpdateIsCached)
        plugin._bind_screen_runtime()
        screens = importlib.import_module(self.prefix + ".plugin_screens")
        screen = screens.sevendays.__new__(screens.sevendays)
        refreshes = []
        screen._start_background_refresh = lambda *args: refreshes.append(args)
        screen._start_open_refresh()
        self.assertEqual(refreshes, [(None, True)])

    def test_cache_older_than_fast_open_limit_uses_loading(self):
        self.cache(7 * 3600)
        self.assertTrue(self.plugin._open_weather_screen(self.session, CITY))
        self.assertEqual(self.events[0][0], "loading")

    def test_disabled_cache_uses_loading(self):
        self.cache(60)
        self.plugin._tw_cache_max_age_seconds = lambda: 0
        self.plugin._load_weather_cache = lambda *args: self.fail("Disabled cache must not be read")
        self.assertTrue(self.plugin._open_weather_screen(self.session, CITY))
        self.assertEqual(self.events[0][0], "loading")

    def test_invalid_temperatures_use_loading(self):
        self.cache(3600, bad=True)
        self.assertTrue(self.plugin._open_weather_screen(self.session, CITY))
        self.assertEqual(self.events[0][0], "loading")

    def test_other_provider_cache_uses_loading(self):
        self.cache(3600, service="msn")
        self.assertTrue(self.plugin._open_weather_screen(self.session, CITY))
        self.assertEqual(self.events[0][0], "loading")

    def test_other_city_memory_is_not_reused(self):
        self.plugin.weatherData = forecast()
        self.plugin._weatherDataLocation = "London, UK@51.5,-0.1"
        self.plugin._lastUpdateEpoch = int(time.time())
        self.assertTrue(self.plugin._open_weather_screen(self.session, CITY))
        self.assertEqual(self.events[0][0], "loading")

    def test_gzip_and_plain_json_have_identical_results(self):
        expected = {"city": "القاهرة", "forecast": forecast()}
        raw = json.dumps(expected, ensure_ascii=False).encode("utf-8")
        compressor = zlib.compressobj(wbits=16 + zlib.MAX_WBITS)
        compressed = compressor.compress(raw) + compressor.flush()
        self.assertLess(len(compressed), len(raw))
        for body, headers, legacy in ((raw, {}, False), (compressed, {"Content-Encoding": "gzip"}, False),
                                     (compressed, {"Content-Encoding": "gzip"}, True)):
            with self.subTest(compressed=bool(headers), legacy=legacy):
                closed = []
                response = types.SimpleNamespace(read=lambda: body, close=lambda: closed.append(True))
                if legacy:
                    response.info = lambda: headers
                else:
                    response.headers = headers
                self.utils._urlopen_compat = lambda *args: response
                self.assertEqual(self.utils._read_json_url("local-fixture"), expected)
                self.assertEqual(closed, [True])

    def test_corrupt_gzip_closes_response(self):
        closed = []
        response = types.SimpleNamespace(read=lambda: b"invalid gzip", headers={"Content-Encoding": "gzip"},
                                         close=lambda: closed.append(True))
        self.utils._urlopen_compat = lambda *args: response
        with self.assertRaises(zlib.error):
            self.utils._read_json_url("local-fixture")
        self.assertEqual(closed, [True])

    def test_gzip_header_reaches_http_request(self):
        requests = []
        response = types.SimpleNamespace(read=lambda: b'{"ok": true}', headers={}, close=lambda: None)
        self.utils.urlopen = lambda request, *args, **kwargs: requests.append(request) or response
        self.assertEqual(self.utils._read_json_url("https://example.invalid/fixture", headers={"Accept-Encoding": "gzip"}), {"ok": True})
        self.assertEqual(requests[0].get_header("Accept-encoding"), "gzip")

    def test_open_meteo_requests_gzip(self):
        providers = importlib.import_module(self.prefix + ".WeatherProviders")
        providers.get_location_coords = lambda city: (50.46, 11.54, "Wurzbach")
        requests = []
        providers._read_json = lambda *args, **kwargs: requests.append((args, kwargs)) or None
        providers._get_weather_open_meteo(CITY)
        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0][1]["headers"], {"Accept-Encoding": "gzip"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
