# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function ensures print() works as function in Python 2.7
from __future__ import print_function, absolute_import

# TheWeather_4.1 modified by iet5 for Python 2 and 3
# Mod_cold_line
# line774_(yposlinecold-100)
# line869_(yposlinecold-66)
# line757_lineheightcold)-12-100)
# line762_lineheightcold-100)
# line_882_lineheightcold)-8-66)
# line887_lineheightcold-66)

from . import _
from .plugin_utils import (
    PY3,
    unicode,
    ssl,
    Request,
    urlopen,
    _urllib_quote,
    DEFAULT_HTTP_HEADERS,
    PLUGIN_ROOT,
    THEWEATHERIET5_DATA_DIR,
    _ensure_text,
    _ensure_binary,
    _ui_text,
    _split_precise_location,
    _parse_precise_location,
    _urlopen_compat,
    _read_json_url,
    _close_response_quietly,
    _quote_url_value,
    _format_location_coordinate,
    PLUGIN_ID,
    LEGACY_PLUGIN_ID,
    _read_non_empty_lines_with_fallback,
    _read_non_empty_lines,
    _write_text_file,
    _write_binary_file,
    _write_non_empty_lines,
    _normalize_location_input,
    _location_compare_key,
    _location_has_precise_coords,
    _connect_timer,
    _disconnect_timer,
    _start_timer,
    _ensure_directory,
    _start_background_thread,
    _tw_log,
    _tw_clear_log,
    _tw_cfg,
    _tw_set_cfg,
    _tw_auto_update_choices,
    _tw_cache_choices,
    _tw_auto_update_enabled,
    _tw_cache_max_age_seconds,
    _is_dreambox_image,
    _is_vti_image,
    _is_openatv_image,
    _is_open_source_image,
    _is_vuplus_box,
    _runtime_device_family,
    _runtime_image_family,
    _display_city_only,
)
from .WeatherProviders import DEFAULT_WEATHER_SERVICE, WEATHER_SERVICE_CHOICES

from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.config import ConfigSelection, ConfigSubsection, ConfigText, ConfigYesNo, config
try:
    from Components.ActionMap import ActionMap, HelpableActionMap
except Exception:
    from Components.ActionMap import ActionMap
    HelpableActionMap = None
from Components.ConfigList import ConfigListScreen
try:
    from Components.Pixmap import MovingPixmap
except Exception:
    MovingPixmap = None
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    try:
        from Screens.VirtualKeyboard import VirtualKeyBoard
    except Exception:
        try:
            from Screens.VirtualKeyboard import VirtualKeyboard as VirtualKeyBoard
        except Exception:
            try:
                from Screens.VirtualKeyBoard import VirtualKeyboard as VirtualKeyBoard
            except Exception:
                VirtualKeyBoard = None
from enigma import ePoint, getDesktop, eTimer
import hashlib
import json
import os
import re
import sys
import time

from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

# # State and Variables
_PLUGIN_SCREENS_CACHE = None
lastUpdateTime = ""
NETWORK_TIMEOUT_STANDARD = 8
NETWORK_TIMEOUT_SHORT = 4
_startup_refresh_started = False
FAST_PIXMAP_ANIMATION_FACTOR = 0.80

MESSAGEBOX_TYPE_INFO = getattr(MessageBox, "TYPE_INFO", 0)
MESSAGEBOX_TYPE_ERROR = getattr(MessageBox, "TYPE_ERROR", MESSAGEBOX_TYPE_INFO)

if MovingPixmap is None:
    class MovingPixmap(Pixmap):
        def __init__(self):
            Pixmap.__init__(self)
            self._pending_position = None

        def moveTo(self, x, y, duration=0):
            self._pending_position = (int(x), int(y))

        def startMoving(self):
            if not self._pending_position:
                return
            try:
                if self.instance is not None:
                    self.instance.move(ePoint(self._pending_position[0], self._pending_position[1]))
            except Exception:
                pass

def _store_pixmap_position(widget, x, y):
    try:
        widget._weather_last_position = (int(x), int(y))
    except Exception:
        pass

def _get_pixmap_position(widget, default_x, default_y):
    try:
        if getattr(widget, "instance", None) is not None:
            point = widget.instance.position()
            return int(point.x()), int(point.y())
    except Exception:
        pass
    try:
        stored = getattr(widget, "_weather_last_position", None)
        if stored:
            return int(stored[0]), int(stored[1])
    except Exception:
        pass
    return int(default_x), int(default_y)

def _direct_move_pixmap(widget, x, y):
    target_x = int(x)
    target_y = int(y)
    try:
        if getattr(widget, "instance", None) is not None:
            widget.instance.move(ePoint(target_x, target_y))
            _store_pixmap_position(widget, target_x, target_y)
            return True
    except Exception:
        pass
    try:
        widget.moveTo(target_x, target_y, 0)
        widget.startMoving()
        _store_pixmap_position(widget, target_x, target_y)
        return True
    except Exception:
        return False

def _anim_connect_timer(timer, callback):
    try:
        timer.callback.append(callback)
    except Exception:
        try:
            timer_conn = timer.timeout.connect(callback)
            timer._weather_anim_conn = timer_conn
        except Exception:
            pass

def _anim_disconnect_timer(timer, callback):
    try:
        timer.callback.remove(callback)
    except Exception:
        try:
            timer_conn = getattr(timer, "_weather_anim_conn", None)
            if timer_conn is not None:
                timer_conn.remove(callback)
            timer._weather_anim_conn = None
        except Exception:
            pass

def _stop_pixmap_animation(widget):
    timer = getattr(widget, "_weather_anim_timer", None)
    callback = getattr(widget, "_weather_anim_callback", None)
    if timer is not None:
        try:
            timer.stop()
        except Exception:
            pass
        if callback is not None:
            _anim_disconnect_timer(timer, callback)
    try:
        widget._weather_anim_timer = None
        widget._weather_anim_callback = None
    except Exception:
        pass

def _pixmap_animation_duration(duration):
    adjusted_duration = int(duration or 0)
    if adjusted_duration <= 0:
        return 0
    if _is_openatv_image() or _is_open_source_image():
        adjusted_duration = max(1, int(round(float(adjusted_duration) * FAST_PIXMAP_ANIMATION_FACTOR)))
    return adjusted_duration

def _manual_move_pixmap(widget, x, y, duration=0):
    target_x = int(x)
    target_y = int(y)
    if widget is None:
        return False
    _stop_pixmap_animation(widget)
    frame_duration = int(duration or 0)
    if frame_duration <= 0:
        return _direct_move_pixmap(widget, target_x, target_y)
    start_x, start_y = _get_pixmap_position(widget, target_x, target_y)
    if start_x == target_x and start_y == target_y:
        return _direct_move_pixmap(widget, target_x, target_y)
    frame_count = max(6, min(24, frame_duration))
    frame_interval = 20
    state = {
        "step": 0,
        "steps": frame_count,
        "start_x": start_x,
        "start_y": start_y,
        "target_x": target_x,
        "target_y": target_y,
        "instance_waits": 0,
    }
    timer = eTimer()

    def _animate_step():
        try:
            if getattr(widget, "instance", None) is None:
                state["instance_waits"] += 1
                if state["instance_waits"] > 8:
                    _stop_pixmap_animation(widget)
                    _direct_move_pixmap(widget, target_x, target_y)
                    return
                _start_timer(timer, 30)
                return
            state["step"] += 1
            progress = float(state["step"]) / float(state["steps"])
            next_x = int(round(state["start_x"] + ((state["target_x"] - state["start_x"]) * progress)))
            next_y = int(round(state["start_y"] + ((state["target_y"] - state["start_y"]) * progress)))
            _direct_move_pixmap(widget, next_x, next_y)
            if state["step"] >= state["steps"]:
                _stop_pixmap_animation(widget)
                return
            _start_timer(timer, frame_interval)
        except Exception:
            _stop_pixmap_animation(widget)
            _direct_move_pixmap(widget, target_x, target_y)

    _anim_connect_timer(timer, _animate_step)
    widget._weather_anim_timer = timer
    widget._weather_anim_callback = _animate_step
    _start_timer(timer, frame_interval)
    return True

def _move_pixmap(widget, x, y, duration=0):
    target_x = int(x)
    target_y = int(y)
    adjusted_duration = _pixmap_animation_duration(duration)
    if widget is None:
        return False
    if USE_SAFE_PIXMAP_MOVE:
        return _manual_move_pixmap(widget, target_x, target_y, adjusted_duration)
    if not USE_SAFE_PIXMAP_MOVE:
        try:
            widget.moveTo(target_x, target_y, adjusted_duration)
            widget.startMoving()
            _store_pixmap_position(widget, target_x, target_y)
            return True
        except Exception:
            pass
    return _manual_move_pixmap(widget, target_x, target_y, adjusted_duration)

# Determine whether to use the safe manual pixmap move strategy.
# On Dreambox (dpkg/apt-based systems), the native moveTo/startMoving API works reliably.
# On Vu+, OpenATV, OpenSource images (IPK-based), use our manual ePoint-based move instead.
USE_SAFE_PIXMAP_MOVE = not (os.path.exists("/var/lib/dpkg") or os.path.exists("/etc/apt"))

try:
    STRING_TYPES = (basestring,)
except Exception:
    # Python 3: basestring does not exist, use str and bytes
    STRING_TYPES = (str, bytes)

def safe_get_desktop_width(default=1280):
    try:
        desktop = getDesktop(0)
        if desktop is not None:
            size = desktop.size()
            if size is not None:
                width = int(size.width())
                if width > 0:
                    return width
    except Exception:
        pass
    return int(default)

def _normalize_action_contexts(contexts, text_converter):
    def _normalize_value(value):
        value = text_converter(value)
        try:
            if isinstance(value, unicode):
                return value.encode("utf-8", "ignore")
        except Exception:
            pass
        return value

    if isinstance(contexts, STRING_TYPES):
        return [_normalize_value(contexts)]
    if contexts is None:
        return []
    if isinstance(contexts, (list, tuple)):
        result = []
        for context in contexts:
            if context is None:
                continue
            result.append(_normalize_value(context))
        return result
    return [_normalize_value(contexts)]

def _mapping_requires_helpable(mapping):
    try:
        iterator = mapping.values()
    except Exception:
        return False
    for value in iterator:
        if isinstance(value, (list, tuple)) and value:
            return True
    return False

def _normalize_action_mapping(mapping, keep_help_entries):
    normalized = {}
    try:
        iterator = mapping.items()
    except Exception:
        return normalized
    for key, value in iterator:
        if keep_help_entries:
            normalized[key] = value
            continue
        if isinstance(value, (list, tuple)) and value:
            normalized[key] = value[0]
            continue
        normalized[key] = value
    return normalized

def build_action_map(owner, contexts, mapping, priority=-1, helpable=False, text_converter=None):
    if text_converter is None:
        text_converter = lambda value: value
    context_list = _normalize_action_contexts(contexts, text_converter)
    if not context_list:
        context_list = ["WizardActions"]
    use_helpable = bool(helpable and HelpableActionMap is not None and _mapping_requires_helpable(mapping))
    action_mapping = _normalize_action_mapping(mapping, use_helpable)
    if use_helpable:
        try:
            return HelpableActionMap(owner, context_list, action_mapping, priority)
        except Exception:
            pass
        for context in context_list:
            try:
                return HelpableActionMap(owner, context, action_mapping, priority)
            except Exception:
                pass
    try:
        return ActionMap(context_list, action_mapping, priority)
    except Exception:
        pass
    for context in context_list:
        try:
            return ActionMap([context], action_mapping, priority)
        except Exception:
            pass
    return ActionMap(["WizardActions"], action_mapping, priority)

def open_virtual_keyboard(session, callback, title, text="", text_converter=None, unavailable_message=None):
    if text_converter is None:
        text_converter = lambda value: value
    if unavailable_message is None:
        unavailable_message = "Keyboard screen is not available on this image."
    if VirtualKeyBoard is None:
        if session is not None:
            session.open(MessageBox, unavailable_message, MESSAGEBOX_TYPE_INFO)
        return False
    last_error = None
    keyboard_title = text_converter(title)
    keyboard_text = text_converter(text)
    if not PY3:
        keyboard_title = _ui_text(keyboard_title)
        keyboard_text = _ui_text(keyboard_text)
    attempts = []
    if _is_dreambox_image():
        attempts.extend((
            {"title": keyboard_title, "text": keyboard_text},
            {"windowTitle": keyboard_title, "text": keyboard_text},
        ))
    if _is_vti_image() or _is_vuplus_box():
        attempts.extend((
            {"text": keyboard_text, "title": keyboard_title},
            {"text": keyboard_text},
        ))
    if _is_openatv_image() or _is_open_source_image():
        attempts.extend((
            {"title": keyboard_title, "text": keyboard_text},
            {"title": keyboard_title},
        ))
    attempts.extend((
        {"title": keyboard_title, "text": keyboard_text},
        {"windowTitle": keyboard_title, "text": keyboard_text},
        {"title": keyboard_title},
        {"text": keyboard_text},
        {},
    ))
    for kwargs in attempts:
        try:
            session.openWithCallback(callback, VirtualKeyBoard, **kwargs)
            return True
        except Exception as e:
            last_error = e
    if last_error is not None:
        raise last_error
    return False

def _plugin_screens_module():
    global _PLUGIN_SCREENS_CACHE
    if _PLUGIN_SCREENS_CACHE is None:
        from . import plugin_screens
        _PLUGIN_SCREENS_CACHE = plugin_screens
    return _PLUGIN_SCREENS_CACHE

def _bind_screen_runtime():
    _plugin_screens_module().bind_runtime(globals())

def _localcityscreen_class():
    return _plugin_screens_module().localcityscreen

def _sevendays_class():
    return _plugin_screens_module().sevendays

def _weatherloading_class():
    return _plugin_screens_module().weatherloading


# # Constants and variables
DEFAULT_ICON_PACK = "Images"
AVAILABLE_ICON_PACKS = ("Images",)
ICON_PACK_ALIASES = {
    "Images": "Images",
    "Images/Default": "Images",
    "Default": "Images",
    "Images_extra": "Images",
    "Extra1": "Images",
    "Extra2": "Images",
    "Images_extra3": "Images",
    "Extra3": "Images",
}
PLUGIN_DESCRIPTOR_ICON_CANDIDATES = (
    "plugin.png",
    "Images/plugin.png",
    "Images/weerinfo.png",
)
iconpath = DEFAULT_ICON_PACK
SKIN_PIXMAP_PATTERN = re.compile(r'(?P<attr>pixmap|selectionPixmap)="(?P<path>[^"]+)"')
SKIN_COLOR_PATTERN = re.compile(r'(?P<attr>[A-Za-z]+Color)="(?P<value>#[0-9A-Fa-f]{8})"')
SKIN_FONT_PATTERN = re.compile(r'font="(?P<name>[^";]+);(?P<size>\d+)"')
SKIN_PIXMAP_TAG_PATTERN = re.compile(r'<(?P<tag>[A-Za-z0-9_]+)\b(?P<attrs>[^>]*\bpixmap="[^"]+"[^>]*?)(?P<closing>\s*/?)>')
CANONICAL_ASSET_DIR_ALIASES = {
    "icon": ("icon", "iconhd", "iconbigsd", "iconbighd"),
    "wind": ("wind", "windhd", "windbig"),
    "lines": ("lines", "linessd"),
}
LEGACY_ASSET_DIR_TO_CANONICAL = {}
for _canonical_asset_dir, _legacy_asset_dirs in CANONICAL_ASSET_DIR_ALIASES.items():
    for _legacy_asset_dir in _legacy_asset_dirs:
        LEGACY_ASSET_DIR_TO_CANONICAL[_legacy_asset_dir] = _canonical_asset_dir
weatherData = []
state = ["", "", "", "", "", "", ""]
SavedLocalWeather = []
localCity = ""
selectedWeatherDay = 0
cityNameDisplay = ""
sz_w = safe_get_desktop_width()
FORCE_FULLHD_LAYOUT = False
PLUGIN_SKIN_PATH = PLUGIN_ROOT.replace("\\", "/")
OAWeather = resolveFilename(SCOPE_PLUGINS, "Extensions/{}".format('OAWeather'))
LEGACY_CONFIG_DIR = "/etc/enigma2"
CONFIG_DIR = THEWEATHERIET5_DATA_DIR
try:
    _ensure_directory(CONFIG_DIR)
except Exception:
    pass
LOCATIONS_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_locations.cfg")
LEGACY_LOCATIONS_FILE = [
    os.path.join(LEGACY_CONFIG_DIR, "%s.cfg" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s.cfg" % LEGACY_PLUGIN_ID),
]
LAST_LOCATION_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_last.cfg")
LEGACY_LAST_LOCATION_FILE = [
    os.path.join(LEGACY_CONFIG_DIR, "%s_last.cfg" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s_last.cfg" % LEGACY_PLUGIN_ID),
]
LAST_BACKGROUND_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_last_background.cfg")
LEGACY_LAST_BACKGROUND_FILE = [
    os.path.join(LEGACY_CONFIG_DIR, "%s_last_background.cfg" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s_last_background.cfg" % LEGACY_PLUGIN_ID),
]
SETTINGS_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_settings.cfg")
ICONPACK_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_iconpack.cfg")
LEGACY_ICONPACK_FILES = [
    os.path.join(LEGACY_CONFIG_DIR, "iconpack.cfg"),
    os.path.join(LEGACY_CONFIG_DIR, "%s_iconpack.cfg" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s_iconpack.cfg" % LEGACY_PLUGIN_ID),
]
WEATHER_CACHE_DIR = os.path.join(CONFIG_DIR, "theweatheriet5_cache")
try:
    _ensure_directory(WEATHER_CACHE_DIR)
except Exception:
    pass
LEGACY_WEATHER_CACHE_DIRS = [
    os.path.join(LEGACY_CONFIG_DIR, "%s_cache" % PLUGIN_ID),
    os.path.join(LEGACY_CONFIG_DIR, "%s_cache" % LEGACY_PLUGIN_ID),
]
DEFAULT_WEATHER_CACHE_FILE = os.path.join(WEATHER_CACHE_DIR, "theweatheriet5_default.json")
BACKGROUND_STAMP_FILE = os.path.join(CONFIG_DIR, "theweatheriet5_background_check.txt")
BACKGROUND_VERSION_URL = "https://www.luxsat.be/hpengine/download_files/plugins/wallpapers/daa.php?data"
BACKGROUND_HD_URL = "https://www.luxsat.be/hpengine/download_files/plugins/wallpapers/daa.php"
BACKGROUND_SD_URL = "https://www.luxsat.be/hpengine/download_files/plugins/wallpapers/daa.php?small"
WEATHER_CACHE_FAST_OPEN_AGE = 10 * 60
WEATHER_CACHE_STALE_AGE = 7 * 24 * 60 * 60
BACKGROUND_CHECK_INTERVAL = 12 * 60 * 60
DEFAULT_FALLBACK_LOCATION = "Cairo, Egypt@30.06263,31.24967"  # Embedded default city in plugin.py
LEGACY_DEFAULT_FALLBACK_LOCATIONS = (
    "Cairo, Egypt@30.04442,31.23571",
)
DEFAULT_CONFIG_VALUES = {
    "enabled": True,
    "automatic_update": "0",
    "weatherservice": DEFAULT_WEATHER_SERVICE,
    "weatherlocation": "",
    "apikey": "",
    "detailLevel": "more",
    "tempUnit": "Celsius",
    "windspeedMetricUnit": "km/h",
    "background": "1",
    "iconset": DEFAULT_ICON_PACK,
    "trendarrows": True,
    "cachedata": "30",
    "debug": False,
}


# Layout Shift Constants
SEVENDAYS_CITY_SHIFT_X_HD = 0
SEVENDAYS_CITY_SHIFT_Y_HD = 10
SEVENDAYS_CITY_SHIFT_X_SD = 0
SEVENDAYS_CITY_SHIFT_Y_SD = 6
SEVENDAYS_MAIN_ICON_SHIFT_X_HD = -40
SEVENDAYS_MAIN_ICON_SHIFT_Y_HD = 6
SEVENDAYS_MAIN_ICON_SHIFT_X_SD = -22
SEVENDAYS_MAIN_ICON_SHIFT_Y_SD = 5
SEVENDAYS_WIND_ICON_SHIFT_X_HD = 0
SEVENDAYS_WIND_ICON_SHIFT_Y_HD = 0
SEVENDAYS_WIND_ICON_SHIFT_X_SD = 0
SEVENDAYS_WIND_ICON_SHIFT_Y_SD = 0
SEVENDAYS_TEMP_SHIFT_X_HD = 0
SEVENDAYS_TEMP_SHIFT_Y_HD = 0
SEVENDAYS_TEMP_UNIT_SHIFT_X_HD = -42
SEVENDAYS_TEMP_UNIT_SHIFT_Y_HD = -2
SEVENDAYS_TEMP_SHIFT_X_SD = 0
SEVENDAYS_TEMP_SHIFT_Y_SD = 0
SEVENDAYS_TEMP_UNIT_SHIFT_X_SD = -34
SEVENDAYS_TEMP_UNIT_SHIFT_Y_SD = -2
SEVENDAYS_FEELS_SHIFT_X_HD = 0
SEVENDAYS_FEELS_SHIFT_Y_HD = 0
SEVENDAYS_FEELS_SHIFT_X_SD = 0
SEVENDAYS_FEELS_SHIFT_Y_SD = 0
SEVENDAYS_WEATHER_TYPE_SHIFT_X_HD = 0
SEVENDAYS_WEATHER_TYPE_SHIFT_Y_HD = 0
SEVENDAYS_WEATHER_TYPE_SHIFT_X_SD = 0
SEVENDAYS_WEATHER_TYPE_SHIFT_Y_SD = 0
SEVENDAYS_WIND_TEXT_SHIFT_X_HD = 0
SEVENDAYS_WIND_TEXT_SHIFT_Y_HD = 0
SEVENDAYS_WIND_TEXT_SHIFT_X_SD = 0
SEVENDAYS_WIND_TEXT_SHIFT_Y_SD = 0
SEVENDAYS_TREND_SHIFT_X_HD = 0
SEVENDAYS_TREND_SHIFT_Y_HD = 0
SEVENDAYS_TREND_SHIFT_X_SD = 0
SEVENDAYS_TREND_SHIFT_Y_SD = 0
SEVENDAYS_SUN_LABEL_SHIFT_X_HD = -26
SEVENDAYS_SUN_LABEL_SHIFT_Y_HD = -34
SEVENDAYS_SUN_LABEL_SHIFT_X_SD = -16
SEVENDAYS_SUN_LABEL_SHIFT_Y_SD = -20
SEVENDAYS_SUN_ICON_SHIFT_X_HD = -40
SEVENDAYS_SUN_ICON_SHIFT_Y_HD = -36
SEVENDAYS_SUN_ICON_SHIFT_X_SD = -24
SEVENDAYS_SUN_ICON_SHIFT_Y_SD = -22
SEVENDAYS_MIDDLE_ICON_SHIFT_X_HD = 13
SEVENDAYS_MIDDLE_ICON_SHIFT_Y_HD = 8
SEVENDAYS_MIDDLE_ICON_SHIFT_X_SD = 7
SEVENDAYS_MIDDLE_ICON_SHIFT_Y_SD = 5
SEVENDAYS_MIDDLE_ICON_SIZE_HD = 65
SEVENDAYS_MIDDLE_ICON_SIZE_SD = 43
SEVENDAYS_BOTTOM_ICON_SHIFT_X_HD = 10
SEVENDAYS_BOTTOM_ICON_SHIFT_X_SD = 6

PLUGIN_FOLDER_NAME = os.path.basename(PLUGIN_ROOT)
PLUGIN_SKIN_PREFIX = "/usr/lib/enigma2/python/Plugins/Extensions/%s" % PLUGIN_ID
LEGACY_PLUGIN_SKIN_PREFIX = "/usr/lib/enigma2/python/Plugins/Extensions/%s" % LEGACY_PLUGIN_ID

try:
    with open(os.path.join(PLUGIN_ROOT, 'version.txt'), 'r') as _f:
        version = _f.read().strip()
except Exception:
    version = '4.1 modified by iet5'

HTTP_HEADERS = {
    "User-Agent": "Enigma2-TheWeatherIet5/%s" % version,
    "Accept": "application/json,text/plain,*/*",
    "Accept-Encoding": "identity",
    "Connection": "close",
}
_background_assets_started = False


def _ensure_plugin_config():
    try:
        config_root = getattr(config.plugins, "TheWeatherIet5", None)
    except Exception:
        config_root = None
    if config_root is None:
        try:
            config.plugins.TheWeatherIet5 = ConfigSubsection()
            config_root = config.plugins.TheWeatherIet5
        except Exception:
            return None

    automatic_update_choices = _tw_auto_update_choices()
    weather_service_choices = list(WEATHER_SERVICE_CHOICES)
    detail_level_choices = [("more", _("More Details / Smaller font"))]
    temp_unit_choices = [("Celsius", _("Celsius")), ("Fahrenheit", _("Fahrenheit"))]
    windspeed_choices = [("km/h", "km/h"), ("m/s", "m/s")]
    background_choices = [(val, _("Background ") + val) for val in _available_background_values()]
    iconset_choices = [(DEFAULT_ICON_PACK, DEFAULT_ICON_PACK)]
    cachedata_choices = _tw_cache_choices()

    def _choice_values(choices):
        values = []
        for choice in list(choices or []):
            try:
                values.append(_ensure_text(choice[0]).strip())
            except Exception:
                pass
        return values

    def _coerce_bool(value, default):
        if isinstance(value, bool):
            return value
        normalized_value = _ensure_text(value).strip().lower()
        if normalized_value in ("1", "true", "yes", "on"):
            return True
        if normalized_value in ("0", "false", "no", "off"):
            return False
        return bool(default)

    def _coerce_choice(value, choices, default):
        allowed_values = _choice_values(choices)
        fallback_value = _ensure_text(default).strip()
        if fallback_value not in allowed_values and allowed_values:
            fallback_value = allowed_values[0]
        normalized_value = _ensure_text(value).strip()
        if normalized_value in allowed_values:
            return normalized_value
        return fallback_value

    def _ensure_cfg(name, factory):
        try:
            current_value = getattr(config_root, name, None)
        except Exception:
            current_value = None
        if current_value is not None and hasattr(current_value, "value"):
            return current_value
        try:
            current_value = factory()
            setattr(config_root, name, current_value)
            return current_value
        except Exception as err:
            try:
                _tw_log("Config item init failed for %s: %s" % (name, str(err)))
            except Exception:
                pass
        return None

    enabled_item = _ensure_cfg("enabled", lambda: ConfigYesNo(default=DEFAULT_CONFIG_VALUES["enabled"]))
    automatic_update_item = _ensure_cfg("automatic_update", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["automatic_update"], choices=automatic_update_choices))
    weatherservice_item = _ensure_cfg("weatherservice", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["weatherservice"], choices=weather_service_choices))
    weatherlocation_item = _ensure_cfg("weatherlocation", lambda: ConfigText(default=DEFAULT_CONFIG_VALUES["weatherlocation"], fixed_size=False))
    apikey_item = _ensure_cfg("apikey", lambda: ConfigText(default=DEFAULT_CONFIG_VALUES["apikey"], fixed_size=False))
    detaillevel_item = _ensure_cfg("detailLevel", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["detailLevel"], choices=detail_level_choices))
    tempunit_item = _ensure_cfg("tempUnit", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["tempUnit"], choices=temp_unit_choices))
    windspeed_item = _ensure_cfg("windspeedMetricUnit", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["windspeedMetricUnit"], choices=windspeed_choices))
    background_item = _ensure_cfg("background", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["background"], choices=background_choices))
    iconset_item = _ensure_cfg("iconset", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["iconset"], choices=iconset_choices))
    trendarrows_item = _ensure_cfg("trendarrows", lambda: ConfigYesNo(default=DEFAULT_CONFIG_VALUES["trendarrows"]))
    cachedata_item = _ensure_cfg("cachedata", lambda: ConfigSelection(default=DEFAULT_CONFIG_VALUES["cachedata"], choices=cachedata_choices))
    debug_item = _ensure_cfg("debug", lambda: ConfigYesNo(default=DEFAULT_CONFIG_VALUES["debug"]))

    for config_item, choices, default_value in (
        (automatic_update_item, automatic_update_choices, DEFAULT_CONFIG_VALUES["automatic_update"]),
        (weatherservice_item, weather_service_choices, DEFAULT_CONFIG_VALUES["weatherservice"]),
        (detaillevel_item, detail_level_choices, DEFAULT_CONFIG_VALUES["detailLevel"]),
        (tempunit_item, temp_unit_choices, DEFAULT_CONFIG_VALUES["tempUnit"]),
        (windspeed_item, windspeed_choices, DEFAULT_CONFIG_VALUES["windspeedMetricUnit"]),
        (background_item, background_choices, DEFAULT_CONFIG_VALUES["background"]),
        (iconset_item, iconset_choices, DEFAULT_CONFIG_VALUES["iconset"]),
        (cachedata_item, cachedata_choices, DEFAULT_CONFIG_VALUES["cachedata"]),
    ):
        if config_item is None:
            continue
        try:
            config_item.setChoices(choices, default=default_value)
        except Exception:
            pass
        try:
            config_item.value = _coerce_choice(getattr(config_item, "value", default_value), choices, default_value)
        except Exception:
            pass

    for config_item, default_value in (
        (enabled_item, DEFAULT_CONFIG_VALUES["enabled"]),
        (trendarrows_item, DEFAULT_CONFIG_VALUES["trendarrows"]),
        (debug_item, DEFAULT_CONFIG_VALUES["debug"]),
    ):
        if config_item is None:
            continue
        try:
            config_item.value = _coerce_bool(getattr(config_item, "value", default_value), default_value)
        except Exception:
            pass

    for config_item, default_value in (
        (weatherlocation_item, DEFAULT_CONFIG_VALUES["weatherlocation"]),
        (apikey_item, DEFAULT_CONFIG_VALUES["apikey"]),
    ):
        if config_item is None:
            continue
        try:
            config_item.value = _ensure_text(getattr(config_item, "value", default_value))
        except Exception:
            pass

    return config_root


try:
    _ensure_plugin_config()
except Exception as err:
    try:
        _tw_log("Plugin config bootstrap failed: %s" % str(err))
    except Exception:
        pass

def _build_action_map(owner, contexts, mapping, priority=-1, helpable=False):
    return build_action_map(owner, contexts, mapping, priority, helpable, _ui_text)

def _open_virtual_keyboard(session, callback, title, text=""):
    return open_virtual_keyboard(
        session,
        callback,
        title,
        text,
        text_converter=_ui_text,
        unavailable_message=_ui_text(_("Keyboard screen is not available on this image.")),
    )

def _append_unique_location(location_name):
    global SavedLocalWeather
    normalized_location = _canonicalize_embedded_default_location(location_name)
    if not normalized_location:
        return False
    if not _location_has_precise_coords(normalized_location):
        return False
    compare_key = _location_compare_key(normalized_location)
    for saved_location in list(SavedLocalWeather):
        if _location_compare_key(saved_location) == compare_key:
            return False
    SavedLocalWeather.append(normalized_location)
    return True


def _configured_weather_location():
    return _canonicalize_embedded_default_location(_runtime_config_value("weatherlocation"))


def _canonicalize_embedded_default_location(location_name):
    normalized_location = _normalize_location_input(location_name)
    if not normalized_location:
        return ""
    for legacy_location in LEGACY_DEFAULT_FALLBACK_LOCATIONS:
        if _location_compare_key(normalized_location) == _location_compare_key(legacy_location):
            return DEFAULT_FALLBACK_LOCATION
    return normalized_location


_cached_background_values = None

def _should_refresh_background_catalog():
    image_family = _runtime_image_family()
    device_family = _runtime_device_family()
    return bool(
        image_family in ("dreamos", "vti", "openatv", "open-source", "generic-enigma2") or
        device_family in ("dreambox", "vuplus")
    )

def _available_background_values():
    global _cached_background_values
    if _should_refresh_background_catalog():
        _cached_background_values = None
    if _cached_background_values is not None:
        return _cached_background_values

    import os
    import re
    choices = set()
    try:
        bg_dir = os.path.join(os.path.dirname(__file__), "Images", "background")
        if os.path.isdir(bg_dir):
            for f in os.listdir(bg_dir):
                match = re.match(r"^backgroundhd\+(\d+)\.png$", f, re.IGNORECASE)
                if match:
                    choices.add(int(match.group(1)))
                else:
                    match_non_hd = re.match(r"^background\+(\d+)\.png$", f, re.IGNORECASE)
                    if match_non_hd:
                        choices.add(int(match_non_hd.group(1)))
        
        if not choices:
            choices.add(1)
            
        sorted_choices = sorted(list(choices))
        _cached_background_values = [str(i) for i in sorted_choices]
        return _cached_background_values
    except Exception:
        return [str(i) for i in range(1, 17)]


def _normalize_background_value(background_value, default="1"):
    valid_values = _available_background_values()
    normalized_default = _ensure_text(default).strip()
    if normalized_default not in valid_values:
        normalized_default = valid_values[0]
    normalized_value = _ensure_text(background_value).strip()
    if normalized_value in valid_values:
        return normalized_value
    return normalized_default


def _configured_background():
    return _normalize_background_value(_runtime_config_value("background"))


TRACKED_CONFIG_KEYS = (
    "enabled",
    "automatic_update",
    "weatherservice",
    "weatherlocation",
    "apikey",
    "detailLevel",
    "tempUnit",
    "windspeedMetricUnit",
    "background",
    "iconset",
    "trendarrows",
    "cachedata",
    "debug",
)
BOOLEAN_CONFIG_KEYS = ("enabled", "trendarrows", "debug")


def _runtime_config_root():
    try:
        _ensure_plugin_config()
    except Exception:
        pass
    try:
        return getattr(config.plugins, "TheWeatherIet5", None)
    except Exception:
        return None


def _runtime_config_value(attr):
    config_root = _runtime_config_root()
    fallback_value = DEFAULT_CONFIG_VALUES.get(attr, "")
    if config_root is None or not hasattr(config_root, attr):
        return fallback_value
    config_item = getattr(config_root, attr)
    return getattr(config_item, "value", fallback_value)


def _serialize_config_value(attr, value):
    if attr in BOOLEAN_CONFIG_KEYS:
        return "true" if bool(value) else "false"
    return _ensure_text(value).strip()


def _coerce_saved_config_value(attr, value):
    text_value = _ensure_text(value).strip()
    if attr in BOOLEAN_CONFIG_KEYS:
        return text_value.lower() in ("1", "true", "yes", "on")
    if attr == "background":
        return _normalize_background_value(text_value)
    if attr == "automatic_update":
        valid_values = [choice[0] for choice in _tw_auto_update_choices()]
        return text_value if text_value in valid_values else DEFAULT_CONFIG_VALUES.get(attr, "0")
    if attr == "cachedata":
        valid_values = [choice[0] for choice in _tw_cache_choices()]
        return text_value if text_value in valid_values else DEFAULT_CONFIG_VALUES.get(attr, "30")
    if attr == "weatherservice":
        valid_values = [choice[0] for choice in WEATHER_SERVICE_CHOICES]
        return text_value if text_value in valid_values else DEFAULT_CONFIG_VALUES.get(attr, DEFAULT_WEATHER_SERVICE)
    if attr == "detailLevel":
        return text_value if text_value == "more" else DEFAULT_CONFIG_VALUES.get(attr, "more")
    if attr == "tempUnit":
        return text_value if text_value in ("Celsius", "Fahrenheit") else DEFAULT_CONFIG_VALUES.get(attr, "Celsius")
    if attr == "windspeedMetricUnit":
        return text_value if text_value in ("km/h", "m/s") else DEFAULT_CONFIG_VALUES.get(attr, "km/h")
    if attr == "iconset":
        return _sanitize_icon_pack(text_value or DEFAULT_CONFIG_VALUES.get(attr, DEFAULT_ICON_PACK))
    if text_value == "":
        return DEFAULT_CONFIG_VALUES.get(attr, "")
    return text_value


def _read_saved_settings_map():
    settings_map = {}
    for raw_line in _read_non_empty_lines(SETTINGS_FILE):
        if "=" not in raw_line:
            continue
        key, value = raw_line.split("=", 1)
        key = _ensure_text(key).strip()
        if not key:
            continue
        settings_map[key] = _ensure_text(value).strip()
    return settings_map


def _write_saved_settings_map(settings_map):
    lines = []
    for key in TRACKED_CONFIG_KEYS:
        if key not in settings_map:
            continue
        lines.append("%s=%s" % (key, _ensure_text(settings_map[key]).strip()))
    try:
        _write_non_empty_lines(SETTINGS_FILE, lines)
    except Exception:
        pass
    return settings_map


def _current_settings_snapshot():
    snapshot = {}
    for key in TRACKED_CONFIG_KEYS:
        snapshot[key] = _serialize_config_value(key, _runtime_config_value(key))
    snapshot["background"] = _normalize_background_value(snapshot.get("background", "1"))
    return snapshot


def _persist_runtime_settings():
    _ensure_plugin_config()
    snapshot = _current_settings_snapshot()
    _write_saved_settings_map(snapshot)
    return snapshot


def _load_runtime_settings():
    _ensure_plugin_config()
    settings_map = _read_saved_settings_map()
    if not settings_map:
        _persist_runtime_settings()
        return {}
    for key in TRACKED_CONFIG_KEYS:
        if key not in settings_map:
            continue
        try:
            _tw_set_cfg(key, _coerce_saved_config_value(key, settings_map.get(key, "")), save=False)
        except Exception:
            pass
    _persist_runtime_settings()
    return settings_map


def _initialize_runtime_storage():
    try:
        _ensure_directory(CONFIG_DIR)
        _ensure_directory(WEATHER_CACHE_DIR)
    except Exception:
        pass

    resolved_location = (
        _configured_weather_location() or
        _normalize_location_input(DEFAULT_FALLBACK_LOCATION)
    )
    resolved_background = _normalize_background_value(_configured_background(), DEFAULT_CONFIG_VALUES.get("background", "1"))
    resolved_icon_pack = _sanitize_icon_pack(_runtime_config_value("iconset") or DEFAULT_ICON_PACK)

    try:
        if not _read_non_empty_lines(SETTINGS_FILE):
            _persist_runtime_settings()
    except Exception:
        pass

    try:
        if not _read_non_empty_lines_with_fallback(LOCATIONS_FILE, LEGACY_LOCATIONS_FILE):
            _write_non_empty_lines(LOCATIONS_FILE, [resolved_location])
    except Exception:
        pass

    try:
        if not _read_non_empty_lines_with_fallback(LAST_LOCATION_FILE, LEGACY_LAST_LOCATION_FILE):
            _write_text_file(LAST_LOCATION_FILE, resolved_location)
    except Exception:
        pass

    try:
        if not _read_non_empty_lines_with_fallback(LAST_BACKGROUND_FILE, LEGACY_LAST_BACKGROUND_FILE):
            _write_text_file(LAST_BACKGROUND_FILE, resolved_background)
    except Exception:
        pass

    try:
        if not _read_non_empty_lines_with_fallback(ICONPACK_FILE, LEGACY_ICONPACK_FILES):
            _write_text_file(ICONPACK_FILE, resolved_icon_pack)
    except Exception:
        pass

    try:
        if not os.path.exists(BACKGROUND_STAMP_FILE):
            _write_text_file(BACKGROUND_STAMP_FILE, "0")
    except Exception:
        pass

    try:
        _tw_log("Runtime storage initialized under %s" % str(CONFIG_DIR))
    except Exception:
        pass

    return resolved_location


def _sync_active_background(background_value=None):
    normalized_background = _normalize_background_value(background_value, _configured_background())
    try:
        _write_text_file(LAST_BACKGROUND_FILE, normalized_background)
    except Exception:
        pass
    try:
        _tw_set_cfg("background", normalized_background)
    except Exception:
        pass
    _persist_runtime_settings()
    return normalized_background


def _restore_last_background():
    configured_background = _configured_background()
    last_backgrounds = _read_non_empty_lines_with_fallback(LAST_BACKGROUND_FILE, LEGACY_LAST_BACKGROUND_FILE)
    resolved_background = configured_background
    if last_backgrounds:
        resolved_background = _normalize_background_value(last_backgrounds[-1], configured_background)
    try:
        _tw_set_cfg("background", resolved_background)
    except Exception:
        pass
    try:
        if not last_backgrounds or resolved_background != _ensure_text(last_backgrounds[-1]).strip():
            _write_text_file(LAST_BACKGROUND_FILE, resolved_background)
    except Exception:
        pass
    try:
        _tw_log("Resolved start background: %s" % str(resolved_background))
    except Exception:
        pass
    return resolved_background


def _sync_active_location(location_name, add_to_favorites=False):
    normalized_location = _canonicalize_embedded_default_location(location_name)
    if not normalized_location:
        return ""
    try:
        _write_text_file(LAST_LOCATION_FILE, normalized_location)
    except Exception:
        pass
    try:
        _tw_set_cfg("weatherlocation", normalized_location)
    except Exception:
        pass
    _persist_runtime_settings()
    try:
        global localCity, cityNameDisplay
        localCity = normalized_location
        cityNameDisplay = _display_city_only(normalized_location)

        if not _location_has_precise_coords(normalized_location):
            _tw_log("Active location synchronized without adding to favorites: %s" % str(normalized_location))
            return normalized_location

        current_key = _location_compare_key(normalized_location)
        updated_locations = []
        found_existing = False
        for saved_location in list(SavedLocalWeather):
            if _location_compare_key(saved_location) == current_key:
                if not found_existing:
                    updated_locations.append(normalized_location)
                    found_existing = True
                continue
            updated_locations.append(saved_location)

        if add_to_favorites:
            if not found_existing:
                updated_locations.insert(0, normalized_location)
            else:
                updated_locations = [normalized_location] + [
                    saved_location for saved_location in list(updated_locations)
                    if _location_compare_key(saved_location) != current_key
                ]
            _tw_log("Active location added/promoted in favorites: %s" % str(normalized_location))
        elif not updated_locations and not found_existing:
            updated_locations = [normalized_location]
            _tw_log("Active location synchronized as the first saved favorite: %s" % str(normalized_location))
        elif found_existing:
            _tw_log("Active location synchronized without changing favorites order: %s" % str(normalized_location))
        else:
            _tw_log("Active location synchronized without storing in favorites order: %s" % str(normalized_location))

        SavedLocalWeather[:] = updated_locations
        _write_non_empty_lines(LOCATIONS_FILE, SavedLocalWeather)
    except Exception as e:
        _tw_log("Sync error in _sync_active_location: %s" % str(e))
    return normalized_location


def _ensure_default_location_available(force=False):
    global SavedLocalWeather
    default_location = _canonicalize_embedded_default_location(DEFAULT_FALLBACK_LOCATION)
    if not default_location:
        return ""
    try:
        _ensure_directory(CONFIG_DIR)
        _ensure_directory(WEATHER_CACHE_DIR)
    except Exception:
        pass
    normalized_existing = []
    seen_keys = set()
    for saved_location in list(SavedLocalWeather):
        normalized_saved = _canonicalize_embedded_default_location(saved_location)
        if not normalized_saved:
            continue
        compare_key = _location_compare_key(normalized_saved)
        if compare_key in seen_keys:
            continue
        seen_keys.add(compare_key)
        normalized_existing.append(normalized_saved)
    has_locations = bool(normalized_existing)
    if not force and has_locations:
        SavedLocalWeather[:] = normalized_existing
        return _normalize_location_input(SavedLocalWeather[0])
    reordered_locations = [default_location]
    default_key = _location_compare_key(default_location)
    for normalized_saved in normalized_existing:
        if _location_compare_key(normalized_saved) == default_key:
            continue
        reordered_locations.append(normalized_saved)
    SavedLocalWeather[:] = reordered_locations
    try:
        _write_non_empty_lines(LOCATIONS_FILE, SavedLocalWeather)
    except Exception:
        pass
    last_locations = _read_non_empty_lines_with_fallback(LAST_LOCATION_FILE, LEGACY_LAST_LOCATION_FILE)
    if force or not last_locations:
        try:
            _write_text_file(LAST_LOCATION_FILE, default_location)
        except Exception:
            pass
    try:
        if force or not _configured_weather_location():
            _tw_set_cfg("weatherlocation", default_location)
    except Exception:
        pass
    try:
        _tw_log("Embedded default location restored from plugin.py: %s" % str(default_location))
    except Exception:
        pass
    return default_location


def _bootstrap_embedded_default_city():
    try:
        _ensure_directory(CONFIG_DIR)
        _ensure_directory(WEATHER_CACHE_DIR)
    except Exception:
        pass
    locations = _read_non_empty_lines_with_fallback(LOCATIONS_FILE, LEGACY_LOCATIONS_FILE)
    if locations:
        return _canonicalize_embedded_default_location(locations[0])
    configured_location = _configured_weather_location()
    if configured_location:
        return configured_location
    last_locations = _read_non_empty_lines_with_fallback(LAST_LOCATION_FILE, LEGACY_LAST_LOCATION_FILE)
    if last_locations:
        resolved_last = _canonicalize_embedded_default_location(last_locations[-1])
        if resolved_last:
            return resolved_last
    return _ensure_default_location_available(force=True)

def _read_all_saved_locations():
    merged_locations = []
    seen_paths = set()
    candidate_paths = [LOCATIONS_FILE]
    # Once the dedicated locations file exists, treat it as the single source of truth.
    # This prevents deleted favorites from being resurrected by stale legacy files.
    primary_exists = False
    try:
        primary_exists = os.path.exists(LOCATIONS_FILE)
    except Exception:
        primary_exists = False
    if not primary_exists:
        for legacy_path in list(LEGACY_LOCATIONS_FILE or []):
            candidate_paths.append(legacy_path)
    for candidate_path in candidate_paths:
        if not candidate_path or candidate_path in seen_paths:
            continue
        seen_paths.add(candidate_path)
        for saved_location in _read_non_empty_lines(candidate_path):
            normalized_location = _canonicalize_embedded_default_location(saved_location)
            if normalized_location:
                merged_locations.append(normalized_location)
    return merged_locations

def _normalize_icon_pack_name(icon_pack):
    normalized_pack = _ensure_text(icon_pack).strip().strip("/\\").replace("\\", "/")
    if not normalized_pack:
        return ""
    return ICON_PACK_ALIASES.get(normalized_pack, normalized_pack)

def _icon_pack_has_files(icon_pack):
    normalized_pack = _normalize_icon_pack_name(icon_pack)
    if not normalized_pack:
        return False
    pack_dir = os.path.join(PLUGIN_ROOT, normalized_pack.replace("/", os.sep))
    if not os.path.isdir(pack_dir):
        return False
    for root_dir, _dirnames, filenames in os.walk(pack_dir):
        for filename in filenames:
            if filename and not filename.startswith("."):
                return True
    return False

def _sanitize_icon_pack(icon_pack):
    normalized_pack = _normalize_icon_pack_name(icon_pack)
    if normalized_pack and _icon_pack_has_files(normalized_pack):
        return normalized_pack
    return DEFAULT_ICON_PACK

def _available_icon_packs(preferred_pack=None):
    available_packs = []
    for candidate in (preferred_pack, iconpath, DEFAULT_ICON_PACK) + AVAILABLE_ICON_PACKS:
        if not candidate:
            continue
        candidate = _normalize_icon_pack_name(candidate)
        if not candidate or candidate in available_packs:
            continue
        if candidate == DEFAULT_ICON_PACK or _icon_pack_has_files(candidate):
            available_packs.append(candidate)
    if DEFAULT_ICON_PACK not in available_packs:
        available_packs.insert(0, DEFAULT_ICON_PACK)
    return tuple(available_packs)

def _icon_pack_display_name(icon_pack):
    display_names = {
        "Images": _("Default"),
        "Images/Default": _("Default"),
        "Images/Extra1": _("Extra1"),
        "Images/Extra2": _("Extra2"),
        "Images/Extra3": _("Extra3"),
    }
    return display_names.get(icon_pack, _ensure_text(os.path.basename(icon_pack)).strip() or _("Default"))

def _icon_pack_choices(preferred_pack=None):
    return [(pack, _icon_pack_display_name(pack)) for pack in _available_icon_packs(preferred_pack)]

def _icon_pack_candidates(preferred_pack=None):
    candidates = []
    for candidate in _available_icon_packs(preferred_pack):
        if not candidate:
            continue
        candidate = _normalize_icon_pack_name(candidate)
        if not candidate or candidate in candidates:
            continue
        if _icon_pack_has_files(candidate):
            candidates.append(candidate)
    return candidates

def _read_saved_icon_pack():
    iconpack_lines = _read_non_empty_lines_with_fallback(ICONPACK_FILE, LEGACY_ICONPACK_FILES)
    if not iconpack_lines:
        return ""
    return _sanitize_icon_pack(iconpack_lines[-1])

def _write_saved_icon_pack(icon_pack):
    safe_icon_pack = _sanitize_icon_pack(icon_pack)
    _write_text_file(ICONPACK_FILE, safe_icon_pack)
    return safe_icon_pack

def _skin_needs_legacy_color_cleanup():
    image_family = _runtime_image_family()
    device_family = _runtime_device_family()
    return image_family in ("dreamos", "vti", "openatv", "open-source") or device_family in ("vuplus", "dreambox")

def _normalize_skin_color_value(color_value):
    normalized_color = _ensure_text(color_value).strip()
    if len(normalized_color) == 9 and normalized_color.startswith("#") and _skin_needs_legacy_color_cleanup():
        return "#" + normalized_color[-6:]
    return normalized_color

def _plugin_relative_path(path):
    normalized_path = _ensure_text(path).replace("\\", "/").strip()
    if not normalized_path:
        return ""
    prefixes = sorted([PLUGIN_SKIN_PREFIX, LEGACY_PLUGIN_SKIN_PREFIX], key=len, reverse=True)
    for prefix in prefixes:
        prefix_clean = prefix.rstrip("/")
        if normalized_path.startswith(prefix_clean):
            if len(normalized_path) == len(prefix_clean):
                return ""
            if normalized_path[len(prefix_clean)] == "/":
                return normalized_path[len(prefix_clean) + 1:]
    plugin_prefixes = (
        PLUGIN_SKIN_PATH.rstrip("/"),
        PLUGIN_ROOT.replace("\\", "/").rstrip("/"),
    )
    for plugin_prefix in plugin_prefixes:
        marker = plugin_prefix + "/"
        if normalized_path.startswith(marker):
            return normalized_path[len(marker):]
    return normalized_path.lstrip("/")

def _plugin_absolute_path(relative_path):
    return os.path.join(PLUGIN_ROOT, relative_path.replace("/", os.sep))

def _plugin_skin_path(relative_path):
    return os.path.join(PLUGIN_SKIN_PATH, relative_path).replace("\\", "/")


def _runtime_supports_scaled_pixmaps():
    image_family = _runtime_image_family()
    device_family = _runtime_device_family()
    return bool(
        device_family in ("dreambox", "vuplus") or
        image_family in ("dreamos", "vti", "openatv", "open-source", "generic-enigma2")
    )


def _asset_directory_candidates(relative_dir):
    normalized_dir = _ensure_text(relative_dir).strip().strip("/")
    if not normalized_dir:
        return []
    parts = [part for part in normalized_dir.split("/") if part]
    if not parts:
        return []
    dir_name = parts[-1]
    dir_prefix = "/".join(parts[:-1])
    canonical_dir = LEGACY_ASSET_DIR_TO_CANONICAL.get(dir_name, dir_name)
    family_dirs = list(CANONICAL_ASSET_DIR_ALIASES.get(canonical_dir, (dir_name,)))
    ordered_dirs = []
    if _runtime_supports_scaled_pixmaps() and canonical_dir in family_dirs:
        ordered_dirs.append(canonical_dir)
    if dir_name not in ordered_dirs:
        ordered_dirs.append(dir_name)
    for family_dir in family_dirs:
        if family_dir not in ordered_dirs:
            ordered_dirs.append(family_dir)
    if canonical_dir not in ordered_dirs:
        ordered_dirs.append(canonical_dir)
    candidates = []
    for candidate_dir in ordered_dirs:
        if dir_prefix:
            candidates.append(dir_prefix + "/" + candidate_dir)
        else:
            candidates.append(candidate_dir)
    return candidates


def _background_skin_asset_path(background_value=None, use_fullhd=False):
    normalized_background = _normalize_background_value(background_value, _configured_background())
    relative_path = "Images/background/backgroundhd+%s.png" % normalized_background
    if use_fullhd:
        stem, ext = os.path.splitext(relative_path)
        fhd_relative_path = stem + "_fhd" + ext
        try:
            if os.path.exists(_plugin_absolute_path(fhd_relative_path)):
                return _plugin_skin_path(fhd_relative_path)
        except Exception:
            pass
    return _plugin_skin_path(relative_path)

def _png_files_in_dir(relative_dir):
    try:
        directory = _plugin_absolute_path(relative_dir)
        if not os.path.isdir(directory):
            return []
        return sorted([
            filename for filename in os.listdir(directory)
            if filename and filename.lower().endswith(".png") and os.path.isfile(os.path.join(directory, filename))
        ])
    except Exception:
        return []

def _fallback_asset_filenames(relative_dir, filename):
    relative_dir = _ensure_text(relative_dir).strip().strip("/")
    dir_name = relative_dir.split("/")[-1] if relative_dir else ""
    filename = _ensure_text(filename).strip()
    if not filename:
        return []
    stem, ext = os.path.splitext(filename)
    ext = ext or ".png"
    candidates = []
    shared_asset_fallbacks = {
        "sunupdownhd": ("sunupdownsd", "a"),
        "sunupdownsd": ("sunupdownhd", "a"),
        "sunpchd": ("sunpcsd", "N"),
        "sunpcsd": ("sunpchd", "N"),
        "rainhd": ("rainsd", "N"),
        "rainsd": ("rainhd", "N"),
        "rhhd": ("rhsd", "N"),
        "rhhd+": ("rhhd", "rhsd", "N"),
        "rhsd": ("rhhd", "N"),
        "turbinehd": ("turbine", "N"),
        "turbine": ("turbinehd", "N"),
        "tempcold": ("tempeven", "temphot", "N"),
        "tempeven": ("tempcold", "temphot", "N"),
        "temphot": ("tempeven", "tempcold", "N"),
    }
    if stem in shared_asset_fallbacks:
        for candidate_stem in shared_asset_fallbacks.get(stem, ()):
            candidates.append(candidate_stem + ext)
    if dir_name in ("icon", "iconhd", "iconbigsd", "iconbighd"):
        candidates.extend(["na" + ext, "a" + ext])
    elif dir_name in ("wind", "windhd", "windbig"):
        candidates.extend(["N" + ext, "NO" + ext])
    elif dir_name in ("lines", "linessd"):
        if stem.startswith("rain_"):
            candidates.append("rain_0" + ext)
        if stem.startswith("b") and stem[1:].lstrip("-").isdigit():
            candidates.append("b0" + ext)
        if stem.lstrip("-").isdigit():
            candidates.append("0" + ext)
        candidates.extend(["bar" + ext, "rdot" + ext, "bdot" + ext])
    elif dir_name == "background":
        candidates.extend(["backgroundhd+1" + ext, "backgroundhd" + ext])
    extra_pngs = _png_files_in_dir(relative_dir)
    if extra_pngs:
        candidates.append(extra_pngs[0])
    ordered = []
    seen = set()
    for candidate in candidates:
        candidate = _ensure_text(candidate).strip()
        if candidate and candidate not in seen:
            ordered.append(candidate)
            seen.add(candidate)
    return ordered

def _candidate_asset_relative_paths(relative_path):
    normalized_relative = _plugin_relative_path(relative_path)
    if not normalized_relative:
        return []
    parts = [part for part in normalized_relative.split("/") if part]
    if not parts:
        return []
    candidate_paths = [normalized_relative]
    if len(parts) >= 2:
        pack_name = _normalize_icon_pack_name(parts[0]) or parts[0]
        relative_inside_pack = "/".join(parts[1:])
        directory_inside_pack = "/".join(parts[1:-1])
        filename = parts[-1]
        pack_candidates = []
        for candidate_pack in (pack_name, DEFAULT_ICON_PACK):
            candidate_pack = _normalize_icon_pack_name(candidate_pack)
            if candidate_pack and candidate_pack not in pack_candidates:
                pack_candidates.append(candidate_pack)
        for candidate_pack in list(_icon_pack_candidates(pack_name)):
            if candidate_pack and candidate_pack not in pack_candidates:
                pack_candidates.append(candidate_pack)
        for candidate_pack in pack_candidates:
            candidate_dir = candidate_pack
            if directory_inside_pack:
                candidate_dir += "/" + directory_inside_pack
            for resolved_dir in _asset_directory_candidates(candidate_dir):
                candidate_paths.append(resolved_dir + "/" + filename)
                for fallback_filename in _fallback_asset_filenames(resolved_dir, filename):
                    candidate_paths.append(resolved_dir + "/" + fallback_filename)
    ordered = []
    seen = set()
    for candidate_path in candidate_paths:
        candidate_path = _ensure_text(candidate_path).strip().strip("/")
        if candidate_path and candidate_path not in seen:
            ordered.append(candidate_path)
            seen.add(candidate_path)
    return ordered

def _resolve_skin_asset_path(path):
    normalized_path = _ensure_text(path).replace("\\", "/")
    relative_candidates = _candidate_asset_relative_paths(normalized_path)
    for candidate_relative in relative_candidates:
        if os.path.exists(_plugin_absolute_path(candidate_relative)):
            return _plugin_skin_path(candidate_relative)
    relative_path = _plugin_relative_path(normalized_path)
    if relative_path and os.path.exists(_plugin_absolute_path(relative_path)):
        return _plugin_skin_path(relative_path)
    return normalized_path

def _runtime_font_scale():
    image_family = _runtime_image_family()
    device_family = _runtime_device_family()
    if device_family == "dreambox" or image_family == "dreamos":
        return 0.92
    if image_family == "openatv":
        return 1.10
    if image_family == "open-source":
        return 1.08
    if image_family == "vti":
        return 1.00
    return 1.00

def _scale_font_size_for_runtime(font_size, minimum=10):
    try:
        base_size = int(font_size)
    except Exception:
        return font_size
    scaled_size = int(round(float(base_size) * _runtime_font_scale()))
    if minimum is not None and scaled_size < int(minimum):
        return int(minimum)
    return scaled_size

def _normalize_skin_markup(skin):
    skin = _ensure_text(skin)

    def _replace_pixmap(match):
        return '%s="%s"' % (match.group("attr"), _resolve_skin_asset_path(match.group("path")))

    def _replace_color(match):
        return '%s="%s"' % (match.group("attr"), _normalize_skin_color_value(match.group("value")))

    def _replace_font(match):
        scaled_size = _scale_font_size_for_runtime(match.group("size"))
        return 'font="%s;%s"' % (match.group("name"), scaled_size)

    def _replace_pixmap_tag(match):
        attrs = match.group("attrs")
        if not _runtime_supports_scaled_pixmaps():
            return match.group(0)
        if re.search(r'\bscale\s*=', attrs, re.IGNORECASE):
            return match.group(0)
        return "<%s%s scale=\"1\"%s>" % (match.group("tag"), attrs, match.group("closing"))

    skin = SKIN_PIXMAP_PATTERN.sub(_replace_pixmap, skin)
    skin = SKIN_PIXMAP_TAG_PATTERN.sub(_replace_pixmap_tag, skin)
    skin = SKIN_COLOR_PATTERN.sub(_replace_color, skin)
    skin = SKIN_FONT_PATTERN.sub(_replace_font, skin)
    return skin.replace("Format:%-H:%M", "Format:%H:%M")

def _apply_skin_path(skin):
    return _normalize_skin_markup(skin)

def _plugin_descriptor_icon():
    # PluginDescriptor icons are most reliable when exposed from the plugin
    # root, while some older layouts still keep the source icon in Images/.
    for candidate in PLUGIN_DESCRIPTOR_ICON_CANDIDATES:
        try:
            candidate_path = os.path.join(PLUGIN_ROOT, candidate.replace("/", os.sep))
            if os.path.isfile(candidate_path):
                return candidate.replace("\\", "/")
        except Exception:
            pass
    return "plugin.png"

def _use_fullhd_layout():
    return FORCE_FULLHD_LAYOUT or sz_w > 1800

def _load_icon_pack():
    global iconpath
    saved_icon_pack = ""
    try:
        saved_icon_pack = _read_saved_icon_pack()
    except Exception:
        saved_icon_pack = ""
    if not saved_icon_pack:
        saved_icon_pack = _tw_cfg("iconset", "")
    iconpath = _sanitize_icon_pack(saved_icon_pack or DEFAULT_ICON_PACK)
    return iconpath

def _normalized_weather_service_value(service_name=None):
    requested_service = _ensure_text(service_name if service_name is not None else _tw_cfg("weatherservice", DEFAULT_WEATHER_SERVICE)).strip().lower()
    valid_values = [choice[0] for choice in WEATHER_SERVICE_CHOICES]
    if requested_service in valid_values:
        return requested_service
    return DEFAULT_WEATHER_SERVICE


def _legacy_cache_location_key(location_name):
    normalized_location = _normalize_location_input(location_name)
    return hashlib.md5(_ensure_binary(normalized_location)).hexdigest()


def _cache_location_key(location_name, service_name=None):
    normalized_location = _normalize_location_input(location_name)
    normalized_service = _normalized_weather_service_value(service_name)
    return hashlib.md5(_ensure_binary("%s|%s" % (normalized_service, normalized_location))).hexdigest()


def _get_weather_cache_file(location_name, service_name=None):
    return os.path.join(WEATHER_CACHE_DIR, "theweatheriet5_" + _cache_location_key(location_name, service_name) + ".json")


def _get_legacy_current_cache_file(location_name):
    return os.path.join(WEATHER_CACHE_DIR, "theweatheriet5_" + _legacy_cache_location_key(location_name) + ".json")


def _get_weather_cache_candidates(location_name, service_name=None, include_all_services=False):
    candidates = []
    if include_all_services:
        for weather_service_value, _weather_service_label in WEATHER_SERVICE_CHOICES:
            specific_cache = _get_weather_cache_file(location_name, weather_service_value)
            if specific_cache and specific_cache not in candidates:
                candidates.append(specific_cache)
    else:
        specific_cache = _get_weather_cache_file(location_name, service_name)
        if specific_cache:
            candidates.append(specific_cache)
    legacy_current_cache = _get_legacy_current_cache_file(location_name)
    if legacy_current_cache not in candidates:
        candidates.append(legacy_current_cache)
    cache_key = _legacy_cache_location_key(location_name)
    for legacy_dir in LEGACY_WEATHER_CACHE_DIRS:
        if legacy_dir:
            legacy_file = os.path.join(legacy_dir, cache_key + ".json")
            if legacy_file not in candidates:
                candidates.append(legacy_file)
    # Keep the legacy shared cache only as a read-only migration fallback.
    # Runtime writes now stay separated per provider and per location.
    if os.path.exists(DEFAULT_WEATHER_CACHE_FILE) and DEFAULT_WEATHER_CACHE_FILE not in candidates:
        candidates.append(DEFAULT_WEATHER_CACHE_FILE)
    return candidates


def _remove_file_quietly(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
            return True
    except Exception:
        pass
    return False


def _cache_file_matches_location(cache_file, location_name):
    try:
        if not cache_file or not os.path.exists(cache_file):
            return False
        with open(cache_file, "rb") as handle:
            payload = json.loads(_ensure_text(handle.read()))
        payload_location = _canonicalize_embedded_default_location(payload.get("location", ""))
        return bool(payload_location and _location_compare_key(payload_location) == _location_compare_key(location_name))
    except Exception:
        return False


def _purge_location_from_config_storage(location_name, replacement_location=None):
    target_location = _canonicalize_embedded_default_location(location_name)
    replacement_location = _canonicalize_embedded_default_location(replacement_location)
    if not target_location:
        return False

    target_key = _location_compare_key(target_location)
    changed = False

    try:
        current_locations = []
        for saved_location in _read_non_empty_lines(LOCATIONS_FILE):
            normalized_location = _canonicalize_embedded_default_location(saved_location)
            if not normalized_location or _location_compare_key(normalized_location) == target_key:
                changed = True
                continue
            current_locations.append(normalized_location)
        _write_non_empty_lines(LOCATIONS_FILE, current_locations)
    except Exception:
        pass

    try:
        last_locations = _read_non_empty_lines(LAST_LOCATION_FILE)
        last_location = _canonicalize_embedded_default_location(last_locations[-1]) if last_locations else ""
        if last_location and _location_compare_key(last_location) == target_key:
            _write_text_file(LAST_LOCATION_FILE, replacement_location or "")
            changed = True
    except Exception:
        pass

    try:
        settings_map = _read_saved_settings_map()
        saved_weather_location = _canonicalize_embedded_default_location(settings_map.get("weatherlocation", ""))
        if saved_weather_location and _location_compare_key(saved_weather_location) == target_key:
            settings_map["weatherlocation"] = replacement_location or ""
            _write_saved_settings_map(settings_map)
            changed = True
    except Exception:
        pass

    try:
        configured_location = _configured_weather_location()
        if configured_location and _location_compare_key(configured_location) == target_key:
            _tw_set_cfg("weatherlocation", replacement_location or "")
            changed = True
    except Exception:
        pass

    try:
        for cache_file in _get_weather_cache_candidates(target_location, include_all_services=True):
            if cache_file == DEFAULT_WEATHER_CACHE_FILE:
                if _cache_file_matches_location(cache_file, target_location):
                    if _remove_file_quietly(cache_file):
                        changed = True
                continue
            if _remove_file_quietly(cache_file):
                changed = True
    except Exception:
        pass

    if changed:
        try:
            _persist_runtime_settings()
        except Exception:
            pass
        try:
            _tw_log("Purged location from config storage: %s" % str(target_location))
        except Exception:
            pass
    return changed

def _apply_weather_payload(location_name, data, display_name):
    try:
        for day_data in list((data or {}).get("days") or []):
            if not isinstance(day_data, dict):
                continue
            day_icon = _ensure_text(day_data.get("iconcode", "")).strip().lower()
            if day_icon in ("a", "j", "n"):
                day_data["iconcode"] = "a"
            elif day_icon in ("aa", "jj", "nn"):
                day_data["iconcode"] = "aa"
            for hour_data in list(day_data.get("hours") or []):
                if not isinstance(hour_data, dict):
                    continue
                hour_icon = _ensure_text(hour_data.get("iconcode", "")).strip().lower()
                if hour_icon in ("a", "j", "n"):
                    hour_data["iconcode"] = "a"
                elif hour_icon in ("aa", "jj", "nn"):
                    hour_data["iconcode"] = "aa"
    except Exception:
        pass
    global weatherData, localCity, cityNameDisplay, lastUpdateTime
    weatherData = data
    localCity = _normalize_location_input(location_name)
    cityNameDisplay = _ensure_text(display_name or location_name)
    lastUpdateTime = time.strftime("%I:%M %p")

def _get_weather_days(payload=None):
    if payload is None:
        payload = weatherData
    if not isinstance(payload, dict):
        return []
    days = payload.get("days")
    if not isinstance(days, list):
        return []
    return days

def _day_payload_ready(day_data):
    if not isinstance(day_data, dict):
        return False
    if day_data.get("maxtemperature") is None or day_data.get("mintemperature") is None:
        return False
    if not _ensure_text(day_data.get("iconcode", "")).strip():
        return False
    if not _ensure_text(day_data.get("sunrise", "")).strip():
        return False
    if not _ensure_text(day_data.get("sunset", "")).strip():
        return False
    hours = day_data.get("hours")
    if not isinstance(hours, list) or not hours:
        return False
    for hour_data in hours:
        if isinstance(hour_data, dict) and hour_data.get("temperature") is not None:
            return True
    return False

def _weather_payload_ready(payload=None, min_days=8):
    days = _get_weather_days(payload)
    if len(days) < min_days:
        return False
    for day_index in range(0, min(7, len(days))):
        if not _day_payload_ready(days[day_index]):
            return False
    return True

def _open_sevendays_screen(session, callback=None):
    if not _weather_payload_ready():
        return False
    try:
        if callback:
            session.openWithCallback(callback, _sevendays_class())
        else:
            session.open(_sevendays_class())
        return True
    except Exception as e:
        _tw_log("sevendays open error: " + str(e))
    return False

def _save_weather_cache(location_name, data, display_name):
    try:
        _ensure_directory(WEATHER_CACHE_DIR)
        weather_service_value = _normalized_weather_service_value()
        payload = {
            "timestamp": int(time.time()),
            "location": _normalize_location_input(location_name),
            "service": weather_service_value,
            "display_name": _ensure_text(display_name or location_name),
            "weather": data,
        }
        payload_text = json.dumps(payload)
        _write_text_file(_get_weather_cache_file(location_name, weather_service_value), payload_text)
    except Exception as e:
        print("[TheWeather] cache save error: " + str(e))

def _load_weather_cache(location_name, max_age=None, allow_stale=False):
    requested_key = _location_compare_key(location_name)
    requested_service = _normalized_weather_service_value()
    for cache_file in _get_weather_cache_candidates(location_name, requested_service):
        if not os.path.exists(cache_file):
            continue
        try:
            with open(cache_file, "rb") as handle:
                payload = json.loads(_ensure_text(handle.read()))
            payload_location = _normalize_location_input(payload.get("location", ""))
            if payload_location and requested_key and _location_compare_key(payload_location) != requested_key:
                continue
            payload_service_raw = _ensure_text(payload.get("service", "")).strip().lower()
            payload_service = _normalized_weather_service_value(payload_service_raw or DEFAULT_WEATHER_SERVICE)
            if payload_service_raw:
                if payload_service != requested_service:
                    continue
            elif requested_service != DEFAULT_WEATHER_SERVICE:
                continue
            timestamp = int(payload.get("timestamp", 0) or 0)
            age = int(time.time()) - timestamp if timestamp else 0
            if timestamp and age > WEATHER_CACHE_STALE_AGE:
                continue
            if max_age is not None and timestamp and age > max_age and not allow_stale:
                continue
            data = payload.get("weather")
            if not isinstance(data, dict) or not data.get("days"):
                continue
            if cache_file == DEFAULT_WEATHER_CACHE_FILE:
                try:
                    _write_text_file(_get_weather_cache_file(location_name, requested_service), json.dumps(payload))
                    _tw_log("Migrated legacy shared cache into provider-specific cache for %s" % str(requested_service))
                except Exception:
                    pass
            global lastUpdateTime
            if timestamp:
                lastUpdateTime = time.strftime("%I:%M %p", time.localtime(timestamp))
            else:
                lastUpdateTime = time.strftime("%I:%M %p")
            _apply_weather_payload(location_name, data, payload.get("display_name") or payload_location or location_name)
            return True
        except Exception as e:
            print("[TheWeather] cache read error: " + str(e))
    return False

def _download_to_file(url, destination, timeout=NETWORK_TIMEOUT_STANDARD):
    response = _urlopen_compat(url, timeout)
    try:
        _write_binary_file(destination, response.read())
    finally:
        _close_response_quietly(response)

def _schedule_background_assets_update():
    global _background_assets_started
    if not _tw_auto_update_enabled():
        _tw_log("Background assets update skipped: automatic update disabled")
        return
    if _background_assets_started:
        return
    try:
        last_check = 0
        if os.path.exists(BACKGROUND_STAMP_FILE):
            with open(BACKGROUND_STAMP_FILE, "rb") as handle:
                last_check = int(_ensure_text(handle.read()).strip() or 0)
        if last_check and (int(time.time()) - last_check) < BACKGROUND_CHECK_INTERVAL:
            return
        _background_assets_started = True
        _write_text_file(BACKGROUND_STAMP_FILE, str(int(time.time())))
        _start_background_thread(_update_background_assets_safe)
    except Exception as e:
        print("[TheWeather] background schedule error: " + str(e))

def _update_background_assets_safe():
    global _background_assets_started
    try:
        _update_background_assets()
    except Exception as e:
        print("[TheWeather] background update error: " + str(e))
    _background_assets_started = False

def _stop_weather_open_timer(session):
    timer = getattr(session, "_weather_open_timer", None)
    callback = getattr(session, "_weather_open_callback", None)
    try:
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            if callback is not None:
                _disconnect_timer(timer, callback)
    except Exception as e:
        print("[TheWeather] weather timer cleanup error: " + str(e))
    try:
        session._weather_open_timer = None
    except Exception:
        pass
    try:
        session._weather_open_callback = None
    except Exception:
        pass

def _clear_session_update_timers(session):
    """Stop any deferred background timers when automatic update is disabled."""
    if session is None:
        return False
    stopped_any = False
    try:
        _stop_weather_open_timer(session)
        stopped_any = True
    except Exception:
        pass
    for timer_attr in ("_tw_restart_timer", "_tw_bg_restart_timer"):
        try:
            timer = getattr(session, timer_attr, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception:
                    pass
                setattr(session, timer_attr, None)
                stopped_any = True
        except Exception:
            pass
    return stopped_any

def _start_deferred_weather_open(session, location_name):
    from enigma import eTimer

    if not _tw_auto_update_enabled():
        _tw_log("Deferred weather open skipped: automatic update disabled")
        return False

    _stop_weather_open_timer(session)
    state = {"done": False, "success": False}

    def fetch_weather():
        try:
            cache_max_age = _tw_cache_max_age_seconds()
            if cache_max_age > 0 and _load_weather_cache(location_name, cache_max_age, False):
                _tw_log("Deferred open used valid cache window (%s seconds)" % str(cache_max_age))
                state["success"] = True
            else:
                state["success"] = bool(getLocalWeather(location_name))
                if not state["success"] and _load_weather_cache(location_name, None, True):
                    state["success"] = True
        except Exception as e:
            print("[TheWeather] deferred open error: " + str(e))
            state["success"] = False
        state["done"] = True

    def poll_weather():
        if not state["done"]:
            _start_timer(timer, 200)
            return
        _stop_weather_open_timer(session)
        if state["success"] and _open_sevendays_screen(session):
            return
        if _load_weather_cache(location_name, None, True) and _open_sevendays_screen(session):
            return
        try:
            session.open(_localcityscreen_class())
        except Exception as e:
            print("[TheWeather] deferred fallback error: " + str(e))

    timer = eTimer()
    session._weather_open_timer = timer
    session._weather_open_callback = poll_weather
    _connect_timer(timer, poll_weather)
    _start_background_thread(fetch_weather)
    _start_timer(timer, 200)
    return True

def _open_weather_screen(session, location_name, allow_async=False, callback=None):
    try:
        location_name = _normalize_location_input(location_name)
        if not location_name:
            return False
        if not _tw_auto_update_enabled():
            try:
                if _clear_session_update_timers(session):
                    _tw_log("Background timers cleared before manual weather open")
            except Exception:
                pass
        _load_icon_pack()
        _schedule_background_assets_update()
        location_name = _sync_active_location(location_name)
        _stop_weather_open_timer(session)
        cache_max_age = _tw_cache_max_age_seconds()
        # On manual plugin open, respect Cache data duration first.
        if cache_max_age > 0 and _load_weather_cache(location_name, cache_max_age, False) and _open_sevendays_screen(session, callback):
            _tw_log("Opened weather from valid cache window (%s seconds)" % str(cache_max_age))
            return True
        use_async_open = bool(allow_async and _tw_auto_update_enabled())
        if allow_async and not use_async_open:
            _tw_log("Async weather loading skipped: automatic update disabled")
        if use_async_open:
            try:
                if callback:
                    session.open(_weatherloading_class(), location_name, cache_max_age, callback=callback)
                else:
                    session.open(_weatherloading_class(), location_name, cache_max_age)
                return True
            except Exception as e:
                _tw_log("weatherloading open error for " + str(location_name) + ": " + str(e))
                return _start_deferred_weather_open(session, location_name)
        if getLocalWeather(location_name) and _open_sevendays_screen(session, callback):
            return True
        if _load_weather_cache(location_name, None, True) and _open_sevendays_screen(session, callback):
            return True
    except Exception as e:
        _tw_log("open weather screen error for " + str(location_name) + ": " + str(e))
    return False

def _refresh_weather_cache_worker(location_name):
    try:
        if not _tw_auto_update_enabled():
            _tw_log("Background weather refresh skipped: automatic update disabled")
            return False
        normalized_location = _normalize_location_input(location_name)
        if not normalized_location:
            return False
        cache_max_age = _tw_cache_max_age_seconds()
        if cache_max_age > 0 and _load_weather_cache(normalized_location, cache_max_age, False):
            _tw_log("Background weather refresh skipped: valid cache still active for %s seconds" % str(cache_max_age))
            return True
        getLocalWeather(normalized_location)
    except Exception as e:
        print("[TheWeather] async refresh error: " + str(e))
    return False

def _update_background_assets():
    # Disabled as per user request to use manual local backgrounds
    pass

def getLocalWeather(iscity=None):
    if not iscity:
        return False
    normalized_location = _normalize_location_input(iscity)
    try:
        from .WeatherProviders import get_weather
        data, disp_name = get_weather(normalized_location)
        if data and _weather_payload_ready(data):
            _apply_weather_payload(normalized_location, data, disp_name)
            _save_weather_cache(normalized_location, data, disp_name)
            _tw_log("Successfully fetched weather for " + str(normalized_location))
            return True
        if data:
            print("[TheWeather] incomplete weather payload for: " + normalized_location)
    except Exception as e:
        print("[TheWeather] error getting weather: " + str(e))

    if _load_weather_cache(normalized_location, None, True) and _weather_payload_ready():
        return True
    return False

def checkInternet():
    test_urls = [
        "https://api.open-meteo.com/v1/forecast?latitude=0&longitude=0&daily=temperature_2m_max&forecast_days=1",
        "https://geocoding-api.open-meteo.com/v1/search?name=cairo&count=1",
        "https://location.buienradar.nl/1.1/location/search?query=amsterdam",
    ]
    for test_url in test_urls:
        try:
            response = _urlopen_compat(test_url, NETWORK_TIMEOUT_SHORT)
            _close_response_quietly(response)
            return True
        except Exception:
            continue
    return False

def _load_saved_locations():
    global SavedLocalWeather
    SavedLocalWeather[:] = []
    try:
        _ensure_directory(CONFIG_DIR)
        _ensure_directory(WEATHER_CACHE_DIR)
    except Exception:
        pass
    _bootstrap_embedded_default_city()
    original_locations = _read_all_saved_locations()
    _tw_log("Read from files: %d initial entries" % len(original_locations))
    normalized_locations = []
    for saved_location in original_locations:
        normalized_location = _canonicalize_embedded_default_location(saved_location)
        if normalized_location and _append_unique_location(normalized_location):
            normalized_locations.append(normalized_location)
    _tw_log("After normalization and deduplication: %d entries" % len(SavedLocalWeather))
    canonical_locations = list(SavedLocalWeather)
    if normalized_locations:
        try:
            _write_non_empty_lines(LOCATIONS_FILE, SavedLocalWeather)
        except Exception:
            pass
    configured_location = _configured_weather_location()
    if configured_location and not original_locations and not SavedLocalWeather:
        if _append_unique_location(configured_location):
            _tw_log("Migrated configured weather location into favorites: %s" % str(configured_location))
    if not SavedLocalWeather:
        _tw_log("No favorites found, restoring default city.")
        _ensure_default_location_available(force=True)
    try:
        _write_non_empty_lines(LOCATIONS_FILE, SavedLocalWeather)
    except Exception:
        pass
    _tw_log("Final favorites count: %d" % len(SavedLocalWeather))

def _resolve_start_location():
    last_locations = _read_non_empty_lines_with_fallback(LAST_LOCATION_FILE, LEGACY_LAST_LOCATION_FILE)
    if last_locations:
        raw_location = last_locations[-1]
        resolved = _canonicalize_embedded_default_location(raw_location)
        if resolved and resolved != _ensure_text(raw_location).strip():
            try:
                _write_text_file(LAST_LOCATION_FILE, resolved)
                _tw_log("Migrated last location file to normalized format")
            except Exception:
                pass
        try:
            _tw_log("Start location from last file %s: %s" % (str(LAST_LOCATION_FILE), str(resolved)))
        except Exception:
            pass
        return resolved
    configured_location = _configured_weather_location()
    if configured_location:
        try:
            _tw_log("Start location from TheWeatherIet5 config: %s" % str(configured_location))
        except Exception:
            pass
        return configured_location
    if SavedLocalWeather:
        resolved = _canonicalize_embedded_default_location(SavedLocalWeather[0])
        try:
            _tw_log("Start location from favorites fallback: %s" % str(resolved))
        except Exception:
            pass
        return resolved
    default_location = _ensure_default_location_available(force=True)
    if default_location:
        try:
            _tw_log("Start location from embedded default: %s" % str(default_location))
        except Exception:
            pass
        return default_location
    try:
        _tw_log("No start location found. Last path checked: %s" % str(LAST_LOCATION_FILE))
    except Exception:
        pass
    return ""

_bind_screen_runtime()

def main(session, **kwargs):
    _tw_clear_log()
    _tw_log("Plugin started (main)")
    global iconpath
    _initialize_runtime_storage()
    _load_runtime_settings()
    _bootstrap_embedded_default_city()
    _restore_last_background()
    _load_saved_locations()
    location = _resolve_start_location()
    if not location:
        location = _ensure_default_location_available(force=True)
    try:
        _tw_log("Config dir: %s" % str(CONFIG_DIR))
        _tw_log("Resolved start location in main: %s" % str(location))
    except Exception:
        pass

    _load_icon_pack()
    _schedule_background_assets_update()

    def _on_plugin_exit(result=None):
        _tw_log("[Main] Plugin screen closed with result: %s" % str(result))
        if result == "RESTART_PLUGIN":
            # Fallback: plugin_screens.py now handles RESTART_PLUGIN directly via
            # _schedule_plugin_restart(). This path is kept for backward compatibility.
            _tw_log("[Main] Restart signal received, scheduling 1000ms delayed re-open...")
            from enigma import eTimer
            # Cancel bg-switch restart timer from plugin_screens to avoid double-launch
            try:
                bg_timer = getattr(session, "_tw_bg_restart_timer", None)
                if bg_timer is not None:
                    bg_timer.stop()
                    session._tw_bg_restart_timer = None
            except Exception:
                pass
            # Stop any previous restart timer
            try:
                old_timer = getattr(session, "_tw_restart_timer", None)
                if old_timer is not None:
                    old_timer.stop()
                    session._tw_restart_timer = None
            except Exception:
                pass

            session._tw_restart_timer = eTimer()

            def _restart():
                try:
                    t = getattr(session, "_tw_restart_timer", None)
                    if t is not None:
                        t.stop()
                    session._tw_restart_timer = None
                except Exception:
                    pass
                _tw_log("[Main] Restart timer fired, re-opening plugin now...")
                try:
                    main(session)
                    _tw_log("[Main] Restart: main(session) executed successfully")
                except Exception as e:
                    _tw_log("[Main] Restart: main(session) failed: %s" % str(e))

            try:
                session._tw_restart_timer.callback.append(_restart)
            except Exception:
                try:
                    session._tw_restart_timer.timeout.connect(_restart)
                except Exception:
                    pass
            session._tw_restart_timer.start(1000, True)

    if location and _open_weather_screen(session, location, True, _on_plugin_exit):
        return
    fallback_location = _ensure_default_location_available(force=True)
    if fallback_location and fallback_location != location and _open_weather_screen(session, fallback_location, True, _on_plugin_exit):
        return
    try:
        _tw_log("Opening startup location selector")
        session.open(_localcityscreen_class())
    except Exception as e:
        _tw_log("main localcityscreen open error: " + str(e))
        try:
            session.open(MessageBox, _ui_text(_("Startup screen error: ")) + _ui_text(str(e)), MESSAGEBOX_TYPE_ERROR)
        except Exception:
            pass

def _refresh_default_city_on_startup():
    location = ""
    try:
        _initialize_runtime_storage()
        if not _tw_auto_update_enabled():
            _tw_log("Startup refresh skipped: automatic update disabled")
            return
        _load_runtime_settings()
        _bootstrap_embedded_default_city()
        _restore_last_background()
        _load_saved_locations()
        location = _resolve_start_location()
        _load_icon_pack()
        _schedule_background_assets_update()
        if not location:
            _tw_log("Startup refresh skipped: no default city found")
            return
        _tw_log("Startup refresh for default city: %s" % str(location))
        cache_max_age = _tw_cache_max_age_seconds()
        if cache_max_age > 0 and _load_weather_cache(location, cache_max_age, False):
            _tw_log("Startup refresh skipped: valid cache still within %s seconds" % str(cache_max_age))
            return
        getLocalWeather(location)
    except Exception as e:
        _tw_log("Startup refresh error for %s: %s" % (str(location), str(e)))

def sessionstart(session, **kwargs):
    global _startup_refresh_started
    if _startup_refresh_started:
        return
    _startup_refresh_started = True
    _initialize_runtime_storage()
    _tw_log("Plugin sessionstart detected")
    if not _tw_auto_update_enabled():
        _tw_log("Session startup background refresh disabled by user setting")
        return
    _start_background_thread(_refresh_default_city_on_startup)

def Plugins(path, **kwargs):
    return [
        PluginDescriptor(name=PLUGIN_ID, description="WeatherInfo",
                         icon=_plugin_descriptor_icon(),
                         where=[PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU],
                         fnc=main),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart),
    ]
