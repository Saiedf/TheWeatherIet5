# -*- coding: utf-8 -*-

screens = []
_CLOSE_RESULT_SENTINEL = object()


def RemoveScreen(screen):
    try:
        while screen in screens:
            screens.remove(screen)
    except Exception:
        pass


def _tracked_screens_snapshot(exclude=None):
    tracked = []
    seen = set()
    for screen in list(screens):
        if screen is exclude:
            continue
        screen_id = id(screen)
        if screen_id in seen:
            continue
        seen.add(screen_id)
        tracked.append(screen)
    return tracked


def _close_tracked_screens(exclude=None):
    for screen in _tracked_screens_snapshot(exclude):
        try:
            screen.close()
        except Exception as e:
            print("[TheWeather] screen close error: " + str(e))
        finally:
            RemoveScreen(screen)


def AddNewScreen(screen):
    if screen not in screens:
        screens.append(screen)
    try:
        if not getattr(screen, "_theweather_screen_tracked", False):
            def _cleanup_screen():
                RemoveScreen(screen)

            screen.onClose.append(_cleanup_screen)
            screen._theweather_screen_tracked = True
    except Exception:
        pass


def ClosePlugin(screen=None, result=_CLOSE_RESULT_SENTINEL):
    if screen is not None:
        try:
            if result is _CLOSE_RESULT_SENTINEL:
                screen.close()
            else:
                screen.close(result)
        except Exception as e:
            print("[TheWeather] close plugin error: " + str(e))
        finally:
            RemoveScreen(screen)
        return
    _close_tracked_screens()
