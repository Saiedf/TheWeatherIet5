# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function and absolute_import are required
# for both Python 2.7 (Dreambox/Vu+ older images) and Python 3.12 (newer images)
from __future__ import print_function, absolute_import

from . import _

import os
import sys
import json
import threading
import re
import ast

# Python 2/3 compatible Enigma2 component imports
# These are available on all supported images (Dreambox, Vu+, OpenATV, VTI, OpenSource)
try:
    from Components.MultiContent import MultiContentEntryText
except Exception:
    MultiContentEntryText = None
try:
    from enigma import RT_HALIGN_LEFT
except Exception:
    RT_HALIGN_LEFT = 0

try:
    import ssl
except Exception:
    ssl = None

PY3 = sys.version_info[0] >= 3
if PY3:
    unicode = str
    from urllib.parse import quote as _urllib_quote
    from urllib.request import Request, urlopen
else:
    unicode = unicode
    from urllib import quote as _urllib_quote
    from urllib2 import Request, urlopen

DEFAULT_HTTP_HEADERS = {
    "User-Agent": "Enigma2-TheWeather",
    "Accept": "application/json,text/plain,*/*",
    "Accept-Encoding": "identity",
    "Connection": "close",
}

LEGACY_COORDS_LOCATION_RE = re.compile(
    r"^\(\s*(?:u)?['\"](?P<label>.+?)['\"]\s*,\s*(?P<lat>-?\d+(?:\.\d+)?)\s*,\s*(?P<lon>-?\d+(?:\.\d+)?)\s*\)$"
)

PLUGIN_ROOT = os.path.dirname(os.path.realpath(__file__))
PLUGIN_ID = "TheWeatherIet5"
LEGACY_PLUGIN_ID = "TheWeather"
THEWEATHERIET5_DATA_DIR = "/etc/enigma2/theweatheriet5"
THEWEATHERIET5_LOG_FILE = os.path.join(THEWEATHERIET5_DATA_DIR, "theweatheriet5.log")

def _read_first_text_file(paths):
    for path in list(paths or []):
        if not path:
            continue
        try:
            if os.path.exists(path):
                with open(path, "rb") as handle:
                    return _ensure_text(handle.read()).strip()
        except Exception:
            pass
    return ""

def _ensure_text(value):
    if value is None:
        return ""
    if PY3:
        if isinstance(value, bytes):
            return value.decode("utf-8", "ignore")
        return str(value)
    if isinstance(value, unicode):
        return value
    try:
        return value.decode("utf-8", "ignore")
    except Exception:
        try:
            return unicode(value)
        except Exception:
            return str(value)

def _ensure_binary(value):
    if value is None:
        value = ""
    if isinstance(value, bytes):
        return value
    text_value = _ensure_text(value)
    if PY3:
        return text_value.encode("utf-8", "ignore")
    if isinstance(text_value, unicode):
        return text_value.encode("utf-8", "ignore")
    return text_value

def _ui_text(value):
    text_value = _ensure_text(value)
    if PY3:
        return text_value
    try:
        if isinstance(text_value, unicode):
            return text_value.encode("utf-8", "ignore")
    except Exception:
        pass
    return str(text_value)

def _format_location_coordinate(value):
    try:
        text_value = ("%.6f" % float(value)).rstrip("0").rstrip(".")
        if text_value in ("", "-0"):
            return "0"
        return text_value
    except Exception:
        return ""

def _split_precise_location(location_name):
    location_text = " ".join(_ensure_text(location_name).strip().split())
    legacy_match = LEGACY_COORDS_LOCATION_RE.match(location_text)
    if legacy_match:
        label_text = " ".join(_ensure_text(legacy_match.group("label")).strip().split())
        lat_text = _format_location_coordinate(legacy_match.group("lat"))
        lon_text = _format_location_coordinate(legacy_match.group("lon"))
        return label_text, lat_text, lon_text
    if location_text.startswith("(") and location_text.endswith(")"):
        try:
            legacy_value = ast.literal_eval(location_text)
            if isinstance(legacy_value, tuple) and len(legacy_value) >= 3:
                label_text = " ".join(_ensure_text(legacy_value[0]).strip().split())
                lat_text = _format_location_coordinate(legacy_value[1])
                lon_text = _format_location_coordinate(legacy_value[2])
                if label_text and lat_text and lon_text:
                    return label_text, lat_text, lon_text
        except Exception:
            pass
    if "@" not in location_text:
        return "", "", ""
    label_text, coords_text = location_text.rsplit("@", 1)
    if "," not in coords_text:
        return " ".join(_ensure_text(label_text).strip().split()), "", ""
    lat_text, lon_text = coords_text.split(",", 1)
    lat_text = _format_location_coordinate(lat_text.strip())
    lon_text = _format_location_coordinate(lon_text.strip())
    label_text = " ".join(_ensure_text(label_text).strip().split())
    return label_text, lat_text, lon_text

def _quote_url_value(value):
    value = _ensure_text(value)
    if PY3:
        return _urllib_quote(value)
    if isinstance(value, unicode):
        value = value.encode("utf-8", "ignore")
    return _urllib_quote(value)

def _urlopen_compat(request, timeout=15, headers=None):
    prepared_headers = dict(DEFAULT_HTTP_HEADERS)
    if isinstance(headers, dict):
        prepared_headers.update(headers)
    if hasattr(request, "get_full_url"):
        prepared_request = request
        request_url = prepared_request.get_full_url()
        try:
            for header_key, header_value in prepared_headers.items():
                if not prepared_request.has_header(header_key):
                    prepared_request.add_header(header_key, header_value)
        except Exception:
            pass
    else:
        request_url = _ensure_text(request)
        prepared_request = Request(request_url, headers=prepared_headers)

    def _open_with_context(context=None):
        try:
            if context is not None:
                return urlopen(prepared_request, timeout=timeout, context=context)
            return urlopen(prepared_request, timeout=timeout)
        except TypeError:
            if context is not None:
                try:
                    return urlopen(prepared_request, None, timeout, context=context)
                except TypeError:
                    pass
            return urlopen(prepared_request, None, timeout)

    try:
        return _open_with_context()
    except Exception:
        if ssl is not None and request_url.startswith("https://"):
            try:
                return _open_with_context(ssl._create_unverified_context())
            except Exception:
                pass
        raise

def _parse_precise_location(location_name):
    label_text, lat_text, lon_text = _split_precise_location(location_name)
    if not lat_text or not lon_text:
        return None, None, label_text
    try:
        display_name = label_text or " ".join(_ensure_text(location_name).strip().split())
        return float(lat_text), float(lon_text), display_name
    except Exception:
        return None, None, label_text

def _read_json_url(request, timeout=15, headers=None):
    response = _urlopen_compat(request, timeout, headers)
    try:
        return json.loads(_ensure_text(response.read()))
    finally:
        _close_response_quietly(response)

def _close_response_quietly(response):
    try:
        if response is not None:
            response.close()
    except Exception:
        pass


def _tw_clear_log():
    """Clear the plugin log file inside the dedicated storage folder."""
    try:
        _ensure_directory(THEWEATHERIET5_DATA_DIR)
        with open(THEWEATHERIET5_LOG_FILE, "wb") as f:
            f.truncate(0)
    except Exception:
        pass

def _detect_runtime_profile():
    profile = {
        "python_major": int(sys.version_info[0]),
        "box_brand": "",
        "box_model": "",
        "image_distro": "",
        "is_dreambox": False,
        "is_vuplus": False,
        "is_vti": False,
        "is_openatv": False,
        "is_open_source": False,
    }

    def _contains_any(text_value, tokens):
        text_value = _ensure_text(text_value).lower()
        for token in list(tokens or []):
            if token and token in text_value:
                return True
        return False

    # Dreambox hardware identifiers - covers DM520, DM525, DM7080, DM820, DM900, DM920,
    # DM One, DM Two and future models that start with "dm" prefix.
    dreambox_markers = (
        "dreambox",
        "dream multimedia",
        "dream property",
        "dm520",
        "dm525",
        "dm7080",
        "dm820",
        "dm900",
        "dm920",
        "dm1200",
        "dm900ultra",
        "dm920ultra",
        "one",
        "two",
    )
    # Vu+ / Vuplus hardware identifiers - covers all known Vu+ STB models including 4K variants
    vuplus_markers = (
        "vu+",
        "vuplus",
        "vuduo",
        "vusolo",
        "vuultimo",
        "vuzero",
        "vuuno",
        "vuuno4k",
        "vuuno4kse",
        "vuduo4k",
        "vuduo4kse",
        "vusolo4k",
        "vuultimo4k",
        "vuzero4k",
        "vublack",
        "vublack4k",
    )
    # Open-source image markers - all major community Enigma2 distributions
    open_source_markers = (
        "openpli",
        "openvix",
        "openbh",
        "openblackhole",
        "openvision",
        "openhdf",
        "openspa",
        "egami",
        "teamblue",
        "openesi",
        "openmips",
        "openakb",
        "opensif",
        "pd-oe-alliance",
    )

    # Primary Dreambox detection: Debian-based package management is exclusive to DreamOS
    profile["is_dreambox"] = bool(
        os.path.exists("/usr/bin/apt-get") or
        os.path.exists("/usr/bin/dpkg") or
        os.path.exists("/etc/dpkg/origins/dreambox") or
        os.path.exists("/etc/dreambox-release")
    )
    # Read hardware identification from standard Enigma2 /proc paths and device tree
    brand_text = _read_first_text_file((
        "/proc/stb/info/brand",
        "/proc/stb/info/boxtype",
        "/proc/stb/info/model",
        "/proc/stb/info/vumodel",
        "/proc/stb/info/machinebuild",
        "/proc/stb/info/hwmodel",
        "/proc/device-tree/model",
        "/etc/hostname",
    )).replace("\x00", " ").lower()
    profile["box_model"] = brand_text
    # Dreambox hardware check: all DM-model boxes or explicit dreambox markers
    if brand_text.startswith("dm") or _contains_any(brand_text, dreambox_markers):
        profile["box_brand"] = "dreambox"
        profile["is_dreambox"] = True
    elif _contains_any(brand_text, vuplus_markers):
        # Vu+ boxes: vusolo, vuduo, vuuno, vuultimo, vuzero and 4K variants
        profile["box_brand"] = "vuplus"
        profile["is_vuplus"] = True

    # Read image/distro identification from known version and release files.
    # Priority: /etc/vtiversion.info (VTI-only) → /etc/image-version → /etc/branding →
    #           /etc/issue → /etc/os-release → /etc/opkg/all-feed.conf
    image_text = _read_first_text_file((
        "/etc/vtiversion.info",
        "/etc/image-version",
        "/etc/branding",
        "/etc/issue",
        "/etc/issue.net",
        "/etc/os-release",
        "/etc/opkg/all-feed.conf",
    )).replace("\x00", " ").lower()

    if "vti" in image_text or os.path.exists("/etc/vtiversion.info"):
        # VTI image - presence of /etc/vtiversion.info is the definitive marker
        profile["image_distro"] = "vti"
        profile["is_vti"] = True
    elif "openatv" in image_text or os.path.exists("/etc/opkg/arch.conf") and (
        _read_first_text_file(("/etc/opkg/arch.conf",)).find("openatv") >= 0
    ):
        # OpenATV image - identified by name in version files or opkg config
        profile["image_distro"] = "openatv"
        profile["is_openatv"] = True
    elif _contains_any(image_text, open_source_markers):
        # Other major open-source community images
        profile["image_distro"] = "open-source"
        profile["is_open_source"] = True
    elif profile["is_dreambox"]:
        # Dreambox with DreamOS (Debian-based) - no community image markers found
        profile["image_distro"] = "dreamos"
    elif image_text:
        # Any other image with text content defaults to open-source category
        profile["image_distro"] = "open-source"
        profile["is_open_source"] = True
    return profile

RUNTIME_PROFILE = _detect_runtime_profile()
CACHE_MINUTE_VALUES = ("0", "30", "60", "120")
AUTO_UPDATE_MINUTE_VALUES = ("0", "30", "60", "90", "120", "150", "180", "240", "300", "360", "420")

def _is_dreambox_image():
    return bool(RUNTIME_PROFILE.get("is_dreambox"))

def _is_vuplus_box():
    return bool(RUNTIME_PROFILE.get("is_vuplus"))

def _is_vti_image():
    return bool(RUNTIME_PROFILE.get("is_vti"))

def _is_openatv_image():
    return bool(RUNTIME_PROFILE.get("is_openatv"))

def _is_open_source_image():
    return bool(RUNTIME_PROFILE.get("is_open_source"))

def _runtime_device_family():
    if _is_dreambox_image():
        return "dreambox"
    if _is_vuplus_box():
        return "vuplus"
    return "generic-enigma2"

def _runtime_image_family():
    if _is_vti_image():
        return "vti"
    if _is_openatv_image():
        return "openatv"
    if _is_open_source_image():
        return "open-source"
    if _is_dreambox_image():
        return "dreamos"
    return "generic-enigma2"
# Note: MultiContentEntryText and RT_HALIGN_LEFT are imported at the top of this module
# for Python 2/3 compatibility and to avoid import order issues across all Enigma2 images.


def _tw_log(message):
    """Log a message with timestamp inside the dedicated storage folder."""
    try:
        from time import strftime, localtime, time
        t = strftime("%Y-%m-%d %H:%M:%S", localtime(time()))
        msg = "[TheWeather] %s: %s\n" % (t, _ensure_text(message))
        _ensure_directory(THEWEATHERIET5_DATA_DIR)
        # Ensure we write binary strings for compatibility across Python 2/3
        with open(THEWEATHERIET5_LOG_FILE, "ab") as f:
            f.write(_ensure_binary(msg))
    except Exception:
        pass


def _ensure_directory(path):
    if not path or os.path.isdir(path):
        return
    try:
        os.makedirs(path)
    except Exception:
        if not os.path.isdir(path):
            raise


def _existing_paths(primary_path, legacy_paths=None):
    paths = []
    if primary_path:
        paths.append(primary_path)
    if legacy_paths:
        if isinstance(legacy_paths, (list, tuple)):
            paths.extend(list(legacy_paths))
        else:
            paths.append(legacy_paths)
    seen = set()
    ordered_paths = []
    for path in paths:
        if path and path not in seen:
            ordered_paths.append(path)
            seen.add(path)
    return ordered_paths


def _read_non_empty_lines(path):
    try:
        with open(path, "rb") as handle:
            return [line.strip() for line in _ensure_text(handle.read()).splitlines() if line.strip()]
    except Exception:
        return []


def _read_non_empty_lines_with_fallback(primary_path, legacy_paths=None):
    for candidate_path in _existing_paths(primary_path, legacy_paths):
        lines = _read_non_empty_lines(candidate_path)
        if lines:
            return lines
    return []


def _write_text_file(path, content):
    directory = os.path.dirname(path)
    if directory:
        _ensure_directory(directory)
    with open(path, "wb") as handle:
        handle.write(_ensure_binary(content))


def _write_binary_file(path, content):
    directory = os.path.dirname(path)
    if directory:
        _ensure_directory(directory)
    with open(path, "wb") as handle:
        handle.write(content)


def _write_non_empty_lines(path, lines):
    cleaned_lines = []
    for line in list(lines or []):
        text_line = _ensure_text(line).strip()
        if text_line:
            cleaned_lines.append(text_line)
    _write_text_file(path, "\n".join(cleaned_lines))


def _set_component_text(component, value):
    safe_value = _ui_text(value)
    try:
        component.setText(safe_value)
    except Exception:
        component.text = safe_value


def _format_temperature_text(value, decimals=0, default="NA"):
    try:
        if decimals > 0:
            return str(("%." + str(decimals) + "f") % float(value))
        return str(int(round(float(value))))
    except Exception:
        return default


def _format_percent_text(value, default=""):
    try:
        return str(int(round(float(value)))) + "%"
    except Exception:
        return default


def _format_speed_text(value, default=""):
    try:
        unit = _tw_wind_unit()
        if unit == "m/s":
            return "{:.1f} m/s".format(float(value) / 3.6)
        return str(value) + " km/h"
    except Exception:
        return default


def _get_hour_precipitation(hour_data):
    if not isinstance(hour_data, dict):
        return ""
    if hour_data.get("precipation") is not None:
        return hour_data.get("precipation")
    if hour_data.get("precipitation") is not None:
        return hour_data.get("precipitation")
    return ""


def _populate_hour_slot(screen, slot_index, hour_data):
    if hour_data:
        _temp_val = _tw_convert_temp(hour_data.get("temperature"))
        _temp_str = _format_temperature_text(_temp_val, 0, "") + _tw_temp_suffix()
        _set_component_text(screen["dayHour" + str(slot_index)], str(hour_data.get("hour", "")) + _("h"))
        _set_component_text(screen["dayTemp" + str(slot_index)], '{:>4}'.format(_temp_str))
        _set_component_text(screen["dayPercent" + str(slot_index)], _format_percent_text(_get_hour_precipitation(hour_data), ""))
        _set_component_text(screen["daySpeed" + str(slot_index)], _format_speed_text(hour_data.get("windspeed"), ""))
        _set_component_text(screen["sunPercent" + str(slot_index)], _format_percent_text(hour_data.get("sunshine"), ""))
        _set_component_text(screen["humidityPercent" + str(slot_index)], _format_percent_text(hour_data.get("humidity"), ""))
        return
    _set_component_text(screen["dayHour" + str(slot_index)], "")
    _set_component_text(screen["dayTemp" + str(slot_index)], "")
    _set_component_text(screen["dayPercent" + str(slot_index)], "")
    _set_component_text(screen["daySpeed" + str(slot_index)], "")
    _set_component_text(screen["sunPercent" + str(slot_index)], "")
    _set_component_text(screen["humidityPercent" + str(slot_index)], "")


def _connect_timer(timer, callback):
    try:
        timer.callback.append(callback)
    except Exception:
        try:
            timer_conn = timer.timeout.connect(callback)
            timer._theweather_timer_conn = timer_conn
        except Exception:
            pass


def _disconnect_timer(timer, callback):
    try:
        timer.callback.remove(callback)
    except Exception:
        try:
            timer_conn = getattr(timer, "_theweather_timer_conn", None)
            if timer_conn is not None:
                try:
                    timer_conn.remove(callback)
                except Exception:
                    pass
                timer._theweather_timer_conn = None
                return
            timer.timeout.disconnect(callback)
        except Exception:
            pass


def _start_timer(timer, delay_ms):
    try:
        timer.start(delay_ms, True)
    except TypeError:
        timer.start(delay_ms)


def _start_background_thread(target, args=None):
    """Start a daemon background thread compatible with Python 2.7 and Python 3.12."""
    if args is None:
        args = ()
    try:
        worker = threading.Thread(target=target, args=args)
        # Use worker.daemon instead of the deprecated setDaemon() method.
        # worker.daemon = True works in both Python 2.7 and Python 3.x
        try:
            worker.daemon = True
        except Exception:
            # Fallback to setDaemon for very old Python 2 environments
            try:
                worker.setDaemon(True)
            except Exception:
                pass
        worker.start()
        return worker
    except Exception as e:
        print("[TheWeather] thread start error: " + str(e))
        return None


def _capitalize_city_token(token):
    token = _ensure_text(token).strip()
    if not token:
        return ""
    return token[:1].upper() + token[1:].lower()


def _normalize_city_name(city_name):
    city_name = " ".join(_ensure_text(city_name).strip().split())
    if not city_name:
        return ""
    normalized_words = []
    for word in city_name.split(" "):
        normalized_words.append("-".join([_capitalize_city_token(part) for part in word.split("-")]))
    return " ".join(normalized_words)


def _split_location_choice_label(label_text):
    label_text = " ".join(_ensure_text(label_text).strip().split())
    if not label_text:
        return "", ""
    if "," not in label_text:
        return label_text, label_text
    city_text, details_text = label_text.split(",", 1)
    city_text = city_text.strip()
    details_text = details_text.strip()
    if not details_text:
        details_text = city_text
    return city_text, details_text


def _estimate_text_width(text, font_size, padding=0, min_width=0, max_width=None):
    text = _ensure_text(text).strip()
    width = int(padding)
    if text:
        narrow_chars = " .,:;|!'`ijlItfr"
        wide_chars = "MWQGOD@#%&"
        for char in text:
            if char in narrow_chars:
                width += max(6, int(font_size * 0.32))
            elif char in wide_chars:
                width += max(10, int(font_size * 0.82))
            else:
                width += max(8, int(font_size * 0.58))
    if width < min_width:
        width = min_width
    if max_width is not None and width > max_width:
        width = max_width
    return width


def _build_location_search_row(result, use_fullhd):
    display_label = _ensure_text(result.get("label", "")).strip()
    city_text, details_text = _split_location_choice_label(display_label)
    if use_fullhd:
        row_left = 25
        row_height = 62
        row_width = 1635
        city_font = 40
        details_font = 34
        gap = 26
        right_padding = 30
        city_min_width = 165
        city_max_width = 620
        min_details_width = 320
    else:
        row_left = 18
        row_height = 40
        row_width = 1100
        city_font = 26
        details_font = 22
        gap = 16
        right_padding = 20
        city_min_width = 120
        city_max_width = 400
        min_details_width = 220

    city_width = _estimate_text_width(city_text, city_font, padding=18, min_width=city_min_width, max_width=city_max_width)
    max_city_width = row_width - right_padding - gap - min_details_width
    if city_width > max_city_width:
        city_width = max_city_width
    if city_width < city_min_width:
        city_width = city_min_width

    details_x = row_left + city_width + gap
    details_width = row_width - city_width - gap - right_padding
    if details_width < min_details_width:
        details_width = min_details_width

    return [
        result,
        MultiContentEntryText(pos=(row_left, 0), size=(city_width, row_height), font=0, flags=RT_HALIGN_LEFT, text=_ui_text(city_text), color_sel=0x00D2D226),
        MultiContentEntryText(pos=(details_x, 0), size=(details_width, row_height), font=1, flags=RT_HALIGN_LEFT, text=_ui_text(details_text), color_sel=0x00D2D226),
    ]


def _location_compare_key(location_name):
    label_text, lat_text, lon_text = _split_precise_location(location_name)
    if lat_text and lon_text:
        return "@%s,%s" % (lat_text, lon_text)
    return _ensure_text(location_name).strip().lower()


def _location_has_precise_coords(location_name):
    label_text, lat_text, lon_text = _split_precise_location(location_name)
    return bool(label_text and lat_text and lon_text)


def _normalize_location_input(searchterm):
    if searchterm is None:
        return ""
    normalized = " ".join(_ensure_text(searchterm).strip().split())
    if not normalized:
        return ""
    label_text, lat_text, lon_text = _split_precise_location(normalized)
    if label_text and lat_text and lon_text:
        return "%s@%s,%s" % (label_text, lat_text, lon_text)
    if "-" in normalized:
        city_name, city_id = normalized.rsplit("-", 1)
        city_name = _normalize_city_name(city_name)
        city_id = city_id.strip()
        if city_name and city_id.isdigit():
            return "%s-%s" % (city_name, city_id)
    if "_" in normalized:
        city_name, country_code = normalized.rsplit("_", 1)
        city_name = _normalize_city_name(city_name)
        country_code = country_code.strip().lower()
        if city_name and country_code:
            return "%s_%s" % (city_name, country_code)
    return _normalize_city_name(normalized)


def _location_label(location_name):
    normalized_location = _normalize_location_input(location_name)
    label_text, lat_text, lon_text = _split_precise_location(normalized_location)
    if label_text and lat_text and lon_text:
        return label_text
    if "_" in normalized_location:
        city_name, country_code = normalized_location.rsplit("_", 1)
        if country_code.isalpha():
            normalized_location = city_name
    if "-" in normalized_location:
        city_name, city_id = normalized_location.rsplit("-", 1)
        if city_id.isdigit():
            normalized_location = city_name
    return normalized_location

def _tw_cfg(attr, default=None):
    try:
        from Components.config import config
        return getattr(config.plugins.TheWeatherIet5, attr).value
    except Exception:
        return default


def _tw_set_cfg(attr, value, save=True):
    try:
        from Components.config import config
        config_root = getattr(config.plugins, "TheWeatherIet5", None)
        if config_root is None or not hasattr(config_root, attr):
            return False
        config_item = getattr(config_root, attr)
        config_item.value = value
        if save:
            try:
                config_item.save()
            except Exception:
                pass
        return True
    except Exception:
        return False


def _tw_temp_unit():
    """Return temperature unit: 'Celsius' or 'Fahrenheit'."""
    return _tw_cfg("tempUnit", "Celsius")


def _tw_temp_suffix():
    """Return degree+unit symbol."""
    suffix = u"\u00B0F" if _tw_temp_unit() == "Fahrenheit" else u"\u00B0C"
    if PY3:
        return suffix
    return suffix.encode("utf-8")


def _tw_convert_temp(celsius_value):
    """Convert from Celsius to Fahrenheit if that unit is selected."""
    if _tw_temp_unit() != "Fahrenheit":
        return celsius_value
    try:
        return float(celsius_value) * 9.0 / 5.0 + 32.0
    except Exception:
        return celsius_value


def _tw_wind_unit():
    """Return wind speed unit: 'km/h' or 'm/s'."""
    return _tw_cfg("windspeedMetricUnit", "km/h")


def _tw_debug():
    """Return True if debug logging is enabled."""
    return bool(_tw_cfg("debug", False))


def _tw_cache_enabled():
    """
    Return True if cache is enabled.
    TheWeatherIet5 cachedata: '0' = Disabled, '30'/'60'/'120' = minutes.
    """
    val = str(_tw_cfg("cachedata", "0"))
    try:
        return int(val) > 0
    except Exception:
        return False

def _tw_cache_minutes():
    """Return cache validity duration in minutes (0 = disabled)."""
    val = str(_tw_cfg("cachedata", "0"))
    try:
        return max(0, int(val))
    except Exception:
        return 0

def _tw_cache_max_age_seconds():
    """Return cache validity in seconds for manual plugin opens."""
    return _tw_cache_minutes() * 60

def _tw_cache_choices():
    choices = []
    for value in CACHE_MINUTE_VALUES:
        if value == "0":
            choices.append((value, _("Disabled")))
        else:
            choices.append((value, value))
    return choices

def _tw_auto_update_choices():
    choices = []
    for value in AUTO_UPDATE_MINUTE_VALUES:
        if value == "0":
            choices.append((value, _("Disabled")))
        else:
            choices.append((value, value))
    return choices

def _tw_auto_update_minutes():
    """Return automatic background update interval in minutes (0 = disabled)."""
    val = str(_tw_cfg("automatic_update", "0"))
    val_lower = val.strip().lower()
    if val_lower in ("true", "yes", "on"):
        return 30
    if val_lower in ("false", "no", "off"):
        return 0
    try:
        return max(0, int(val))
    except Exception:
        return 0


def _tw_auto_update_enabled():
    """Return True if automatic background update is enabled."""
    return _tw_auto_update_minutes() > 0

def _tw_choice_values(choices):
    return [_ensure_text(choice[0]).strip() for choice in choices]

def _tw_next_choice_value(current_value, choices, default_value=None, legacy_map=None):
    values = _tw_choice_values(choices)
    if not values:
        return _ensure_text(default_value).strip()
    normalized_value = _ensure_text(current_value).strip().lower()
    if legacy_map:
        normalized_value = _ensure_text(legacy_map.get(normalized_value, normalized_value)).strip()
    if default_value is None:
        default_value = values[0]
    default_value = _ensure_text(default_value).strip() or values[0]
    try:
        current_index = values.index(normalized_value)
    except Exception:
        try:
            current_index = values.index(default_value)
        except Exception:
            current_index = 0
    return values[(current_index + 1) % len(values)]


def _tw_map_wind_direction(direction):
    """
    Map English wind direction abbreviations to legacy icon filenames.
    N -> N, NE -> NO, E -> O, SE -> ZO, S -> Z, SW -> ZW, W -> W, NW -> NW
    """
    mapping = {
        "N": "N",
        "NE": "NO",
        "E": "O",
        "SE": "ZO",
        "S": "Z",
        "SW": "ZW",
        "W": "W",
        "NW": "NW",
    }
    return mapping.get(str(direction).upper(), str(direction))


def _tw_get_safe_wind_icon(icon_pack, direction, style="windhd"):
    """
    Find a valid wind icon file, trying common mappings and fallbacks.
    Returns the filename without extension (e.g., 'ZW').
    """
    normalized_pack = _ensure_text(icon_pack).strip().strip("/\\").replace("\\", "/") or "Images"
    normalized_style = _ensure_text(style).strip().strip("/\\").replace("\\", "/") or "wind"
    english_dir = str(direction).upper()
    dutch_dir = _tw_map_wind_direction(english_dir)
    pack_names = [normalized_pack]
    if normalized_pack != "Images":
        pack_names.append("Images")
    candidates = [english_dir, dutch_dir, "N", "NO", "O", "Z", "ZW", "NW", "na"]
    style_candidates = []
    wind_style_family = ("wind", "windhd", "windbig")
    if normalized_style in wind_style_family:
        if _runtime_device_family() in ("dreambox", "vuplus") or _runtime_image_family() in ("dreamos", "vti", "openatv", "open-source", "generic-enigma2"):
            style_candidates.append("wind")
        style_candidates.append(normalized_style)
        for fallback_style in wind_style_family:
            if fallback_style not in style_candidates:
                style_candidates.append(fallback_style)
    else:
        style_candidates = [normalized_style, "wind"]

    for pack_name in pack_names:
        for candidate_style in style_candidates:
            base_dir = os.path.join(PLUGIN_ROOT, pack_name.replace("/", os.sep), candidate_style)
            if not os.path.isdir(base_dir):
                continue
            for cand in candidates:
                if cand and os.path.isfile(os.path.join(base_dir, cand + ".png")):
                    return cand
            try:
                filenames = sorted([
                    os.path.splitext(filename)[0]
                    for filename in os.listdir(base_dir)
                    if filename.lower().endswith(".png")
                ])
                if filenames:
                    return filenames[0]
            except Exception:
                pass

    return "N"


def _display_city_only(location_value):
    location_text = _ensure_text(location_value).strip()
    try:
        label_text, _lat_text, _lon_text = _split_precise_location(location_text)
        if label_text:
            location_text = label_text
    except Exception:
        pass

    if "@" in location_text:
        location_text = location_text.split("@", 1)[0].strip()
    if "," in location_text:
        location_text = location_text.split(",", 1)[0].strip()
    return location_text or _("Not set")


