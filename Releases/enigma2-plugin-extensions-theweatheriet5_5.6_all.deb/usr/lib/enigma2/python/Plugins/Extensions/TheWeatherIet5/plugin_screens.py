# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function ensures print() works as function in Python 2.7
# absolute_import enforces explicit relative imports for Python 2.7 and Python 3.x compatibility
from __future__ import print_function, absolute_import

from . import _

from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText

# Safely import enigma symbols - some may be absent on certain image builds.
# gFont is available on Dreambox, Vu+, OpenATV, VTI and all standard open-source images.
# RT_HALIGN_LEFT / RT_HALIGN_RIGHT are used for MultiContent list alignment.
# eListboxPythonMultiContent is the core multi-column list engine.
# eTimer is used for deferred screen open and auto-update scheduling.
try:
    from enigma import RT_HALIGN_LEFT, RT_HALIGN_RIGHT, eListboxPythonMultiContent, eTimer, gFont
except ImportError:
    # Fallback: import each symbol individually so partial availability still works
    try:
        from enigma import RT_HALIGN_LEFT
    except ImportError:
        RT_HALIGN_LEFT = 0
    try:
        from enigma import RT_HALIGN_RIGHT
    except ImportError:
        RT_HALIGN_RIGHT = 1
    try:
        from enigma import eListboxPythonMultiContent
    except ImportError:
        eListboxPythonMultiContent = None
    try:
        from enigma import eTimer
    except ImportError:
        eTimer = None
    try:
        from enigma import gFont
    except ImportError:
        gFont = None

from Screens.Screen import Screen
import math
import time
import sys
import datetime

# Python version detection - used throughout for conditional behaviour
PY3 = sys.version_info[0] >= 3
from .plugin import (
    DEFAULT_ICON_PACK,
    MESSAGEBOX_TYPE_ERROR,
    MESSAGEBOX_TYPE_INFO,
    MessageBox,
    MovingPixmap,
    build_action_map,
    lastUpdateTime,
    SavedLocalWeather,
    localCity,
    _open_weather_screen,
    _load_saved_locations,
    _load_weather_cache,
    _icon_pack_has_files,
    _available_icon_packs,
    _icon_pack_display_name,
    _scale_font_size_for_runtime,
    _sanitize_icon_pack,
    _background_skin_asset_path,
    _ensure_default_location_available,
    _persist_runtime_settings,
    _purge_location_from_config_storage,
    _sync_active_background,
    version,
    iconpath,
    _write_saved_icon_pack,
    LOCATIONS_FILE,
)
from .plugin_utils import (
    _build_location_search_row,
    _connect_timer,
    _disconnect_timer,
    _ensure_text,
    _format_speed_text,
    _format_temperature_text,
    _location_compare_key,
    _location_has_precise_coords,
    _location_label,
    _normalize_location_input,
    _populate_hour_slot,
    _set_component_text,
    _start_background_thread,
    _start_timer,
    _ui_text,
    _write_non_empty_lines,
    _tw_convert_temp,
    _tw_temp_suffix,
    _tw_auto_update_choices,
    _tw_auto_update_minutes,
    _tw_cache_choices,
    _tw_cfg,
    _is_dreambox_image,
    _is_vti_image,
    _is_openatv_image,
    _is_open_source_image,
    _tw_get_safe_wind_icon,
    _tw_log,
    _tw_next_choice_value,
    _display_city_only,
)
from .screen_tracking import AddNewScreen, ClosePlugin
from .weather_display import (
    _format_day_summary_label,
    _format_day_temperature_label,
    _get_day_label_parts,
    _get_day_sunrise_sunset_text,
    _get_display_hour_for_day,
    _get_mapping_value,
    _get_temperature_line_layout,
    _get_temperature_shift,
    icontotext,
    winddirtext,
)

_PLUGIN_RUNTIME = None
_PLUGIN_RESTART_TIMERS = []
_SCREEN_CLOSE_SENTINEL = object()

def _hold_plugin_restart_timer(timer):
    try:
        _PLUGIN_RESTART_TIMERS.append(timer)
    except Exception:
        pass


def _release_plugin_restart_timer(timer):
    try:
        _PLUGIN_RESTART_TIMERS.remove(timer)
    except Exception:
        pass


def _schedule_plugin_restart(session, target_location=None, delay_ms=1000):
    target_location = _normalize_location_input(target_location)
    if not target_location:
        target_location = _normalize_location_input(_tw_cfg("weatherlocation", ""))
    if not target_location:
        target_location = _runtime_local_city()
    if not target_location:
        return False

    try:
        timer = eTimer()

        def _restart():
            try:
                timer.stop()
            except Exception:
                pass
            try:
                _disconnect_timer(timer, _restart)
            except Exception:
                pass
            _release_plugin_restart_timer(timer)
            try:
                _open_weather_screen(session, target_location, allow_async=True)
            except Exception as e:
                _tw_log("Plugin restart reopen error: %s" % str(e))

        _connect_timer(timer, _restart)
        _hold_plugin_restart_timer(timer)
        _start_timer(timer, int(delay_ms))
        return True
    except Exception as e:
        _tw_log("Plugin restart timer error: %s" % str(e))
        try:
            return bool(_open_weather_screen(session, target_location, allow_async=True))
        except Exception as reopen_error:
            _tw_log("Plugin restart immediate reopen error: %s" % str(reopen_error))
            return False


PLUGIN_ID = globals().get("PLUGIN_ID", "TheWeatherIet5")
cityNameDisplay = globals().get("cityNameDisplay", "")

_SEVENDAYS_RUNTIME_DEFAULTS = {
    "SEVENDAYS_MAIN_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_MAIN_ICON_SHIFT_Y_HD": 0,
    "SEVENDAYS_WIND_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_WIND_ICON_SHIFT_Y_HD": 0,
    "SEVENDAYS_CITY_SHIFT_X_HD": 0,
    "SEVENDAYS_CITY_SHIFT_Y_HD": 0,
    "SEVENDAYS_TEMP_SHIFT_X_HD": 0,
    "SEVENDAYS_TEMP_SHIFT_Y_HD": 0,
    "SEVENDAYS_TEMP_UNIT_SHIFT_X_HD": -42,
    "SEVENDAYS_TEMP_UNIT_SHIFT_Y_HD": -2,
    "SEVENDAYS_FEELS_SHIFT_X_HD": 0,
    "SEVENDAYS_FEELS_SHIFT_Y_HD": 0,
    "SEVENDAYS_WEATHER_TYPE_SHIFT_X_HD": 0,
    "SEVENDAYS_WEATHER_TYPE_SHIFT_Y_HD": 0,
    "SEVENDAYS_WIND_TEXT_SHIFT_X_HD": 0,
    "SEVENDAYS_WIND_TEXT_SHIFT_Y_HD": 0,
    "SEVENDAYS_TREND_SHIFT_X_HD": 0,
    "SEVENDAYS_TREND_SHIFT_Y_HD": 0,
    "SEVENDAYS_SUN_LABEL_SHIFT_X_HD": 0,
    "SEVENDAYS_SUN_LABEL_SHIFT_Y_HD": 0,
    "SEVENDAYS_SUN_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_SUN_ICON_SHIFT_Y_HD": 0,
    "SEVENDAYS_MIDDLE_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_MIDDLE_ICON_SHIFT_Y_HD": 0,
    "SEVENDAYS_MIDDLE_ICON_SIZE_HD": 72,
    "SEVENDAYS_BOTTOM_ICON_SHIFT_X_HD": 0,
    "SEVENDAYS_MAIN_ICON_SHIFT_X_SD": 0,
    "SEVENDAYS_MAIN_ICON_SHIFT_Y_SD": 0,
    "SEVENDAYS_WIND_ICON_SHIFT_X_SD": 0,
    "SEVENDAYS_WIND_ICON_SHIFT_Y_SD": 0,
    "SEVENDAYS_CITY_SHIFT_X_SD": 0,
    "SEVENDAYS_CITY_SHIFT_Y_SD": 0,
    "SEVENDAYS_TEMP_SHIFT_X_SD": 0,
    "SEVENDAYS_TEMP_SHIFT_Y_SD": 0,
    "SEVENDAYS_TEMP_UNIT_SHIFT_X_SD": -34,
    "SEVENDAYS_TEMP_UNIT_SHIFT_Y_SD": -2,
    "SEVENDAYS_FEELS_SHIFT_X_SD": 0,
    "SEVENDAYS_FEELS_SHIFT_Y_SD": 0,
    "SEVENDAYS_WEATHER_TYPE_SHIFT_X_SD": 0,
    "SEVENDAYS_WEATHER_TYPE_SHIFT_Y_SD": 0,
    "SEVENDAYS_WIND_TEXT_SHIFT_X_SD": 0,
    "SEVENDAYS_WIND_TEXT_SHIFT_Y_SD": 0,
    "SEVENDAYS_TREND_SHIFT_X_SD": 0,
    "SEVENDAYS_TREND_SHIFT_Y_SD": 0,
    "SEVENDAYS_SUN_LABEL_SHIFT_X_SD": 0,
    "SEVENDAYS_SUN_LABEL_SHIFT_Y_SD": 0,
    "SEVENDAYS_SUN_ICON_SHIFT_X_SD": 0,
    "SEVENDAYS_SUN_ICON_SHIFT_Y_SD": 0,
    "SEVENDAYS_MIDDLE_ICON_SHIFT_X_SD": 0,
    "SEVENDAYS_MIDDLE_ICON_SHIFT_Y_SD": 0,
    "SEVENDAYS_MIDDLE_ICON_SIZE_SD": 48,
    "SEVENDAYS_BOTTOM_ICON_SHIFT_X_SD": 0,
}
for _runtime_name, _runtime_value in list(_SEVENDAYS_RUNTIME_DEFAULTS.items()):
    globals().setdefault(_runtime_name, _runtime_value)

def _runtime_callable(name):
    value = _runtime_plugin_value(name, None)
    if callable(value):
        return value
    return None

def _apply_skin_path(skin_text):
    skin_applier = _runtime_callable("_apply_skin_path")
    if skin_applier is not None:
        try:
            return skin_applier(skin_text)
        except Exception:
            pass
    return skin_text

def _use_fullhd_layout():
    fullhd_checker = _runtime_callable("_use_fullhd_layout")
    if fullhd_checker is not None:
        try:
            return bool(fullhd_checker())
        except Exception:
            pass
    try:
        from enigma import getDesktop
        desktop = getDesktop(0)
        if desktop is not None:
            desktop_size = desktop.size()
            return int(desktop_size.width()) >= 1920
    except Exception:
        pass
    return False

def _move_pixmap(pixmap, pos_x, pos_y, speed=0):
    pixmap_mover = _runtime_callable("_move_pixmap")
    if pixmap_mover is not None:
        try:
            return pixmap_mover(pixmap, pos_x, pos_y, speed)
        except Exception:
            pass
    try:
        if hasattr(pixmap, "moveTo") and hasattr(pixmap, "startMoving"):
            pixmap.moveTo(int(pos_x), int(pos_y), int(speed or 0))
            pixmap.startMoving()
            return
    except Exception:
        pass
    try:
        from enigma import ePoint
        if hasattr(pixmap, "instance") and pixmap.instance is not None:
            pixmap.instance.move(ePoint(int(pos_x), int(pos_y)))
    except Exception:
        pass

def _open_virtual_keyboard(session, callback, title, text_value):
    keyboard_opener = _runtime_callable("_open_virtual_keyboard")
    if keyboard_opener is not None:
        return keyboard_opener(session, callback, title, text_value)
    try:
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        return session.openWithCallback(callback, VirtualKeyBoard, title=title, text=text_value)
    except Exception:
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        return session.openWithCallback(callback, VirtualKeyBoard, title=title)

def _sync_active_location(location_name, add_to_favorites=False):
    sync_location = _runtime_callable("_sync_active_location")
    if sync_location is not None:
        try:
            return sync_location(location_name, add_to_favorites=add_to_favorites)
        except TypeError:
            return sync_location(location_name)
    return None

def _tw_cache_max_age_seconds():
    cache_max_age = _runtime_callable("_tw_cache_max_age_seconds")
    if cache_max_age is not None:
        try:
            return int(cache_max_age() or 0)
        except Exception:
            pass
    return 0

def _resolve_start_location():
    start_location_resolver = _runtime_callable("_resolve_start_location")
    if start_location_resolver is not None:
        try:
            return start_location_resolver()
        except Exception:
            pass
    return _normalize_location_input(_tw_cfg("weatherlocation", "")) or _runtime_local_city()

def _bootstrap_embedded_default_city():
    bootstrap_default_city = _runtime_callable("_bootstrap_embedded_default_city")
    if bootstrap_default_city is not None:
        try:
            return bootstrap_default_city()
        except Exception:
            pass
    return None

def getLocalWeather(location_name):
    weather_loader = _runtime_callable("getLocalWeather")
    if weather_loader is not None:
        return weather_loader(location_name)
    return False

def bind_runtime(runtime_globals=None):
    global _PLUGIN_RUNTIME, cityNameDisplay, PLUGIN_ID
    if runtime_globals is not None:
        _PLUGIN_RUNTIME = runtime_globals
    if not isinstance(_PLUGIN_RUNTIME, dict):
        return
    for name, value in list(_PLUGIN_RUNTIME.items()):
        if name.startswith('__'):
            continue
        globals()[name] = value
    try:
        cityNameDisplay = _ensure_text(_PLUGIN_RUNTIME.get("cityNameDisplay", cityNameDisplay)).strip()
    except Exception:
        pass
    try:
        PLUGIN_ID = _ensure_text(_PLUGIN_RUNTIME.get("PLUGIN_ID", PLUGIN_ID)).strip() or PLUGIN_ID
    except Exception:
        pass

def _runtime_saved_locations():
    try:
        plugin_runtime = sys.modules.get(getattr(_load_saved_locations, "__module__", ""))
        if plugin_runtime is not None and hasattr(plugin_runtime, "SavedLocalWeather"):
            return plugin_runtime.SavedLocalWeather
    except Exception:
        pass
    return SavedLocalWeather

def _runtime_plugin_module():
    try:
        return sys.modules.get(getattr(_load_saved_locations, "__module__", ""))
    except Exception:
        return None

def _runtime_plugin_value(name, default=None):
    plugin_runtime = _runtime_plugin_module()
    if plugin_runtime is not None and hasattr(plugin_runtime, name):
        try:
            return getattr(plugin_runtime, name)
        except Exception:
            pass
    return globals().get(name, default)

def _runtime_local_city():
    return _normalize_location_input(_runtime_plugin_value("localCity", ""))


def _runtime_font(size):
    # Use the skin's built-in "Regular" font family so setFont() works correctly
    # on Dreambox, Vu+, OpenATV, VTI and all open-source images.
    # Avoids setFont() entirely - uses the skin font directly via gFont.
    if gFont is None:
        # gFont unavailable on this image build - skip font override gracefully
        return None
    try:
        return gFont("Regular", _scale_font_size_for_runtime(size))
    except Exception:
        try:
            return gFont("Regular", size)
        except Exception:
            return None

def _runtime_city_display_name():
    display_name = _ensure_text(_runtime_plugin_value("cityNameDisplay", "")).strip()
    if display_name:
        return display_name
    active_location = _runtime_local_city() or _normalize_location_input(_tw_cfg("weatherlocation", ""))
    if active_location:
        return _location_label(active_location)
    return ""

def _refresh_screen_city_label(screen):
    try:
        if "city1" in screen:
            _set_component_text(screen["city1"], _runtime_city_display_name())
    except Exception:
        pass


def _close_screen_instance(screen, result=_SCREEN_CLOSE_SENTINEL):
    """Close one screen safely on Dreambox, Vu+, OpenATV, VTi and open-source images."""
    if screen is None:
        return False
    try:
        _tw_log(
            "Closing screen %s (dreambox=%s, vti=%s, openatv=%s, opensource=%s, py3=%s)" % (
                screen.__class__.__name__,
                str(_is_dreambox_image()),
                str(_is_vti_image()),
                str(_is_openatv_image()),
                str(_is_open_source_image()),
                str(PY3),
            )
        )
    except Exception:
        pass
    try:
        if result is _SCREEN_CLOSE_SENTINEL:
            ClosePlugin(screen)
        else:
            ClosePlugin(screen, result)
        return True
    except TypeError:
        pass
    except Exception as e:
        try:
            _tw_log("Tracked close failed for %s: %s" % (screen.__class__.__name__, str(e)))
        except Exception:
            pass
    try:
        if result is _SCREEN_CLOSE_SENTINEL:
            screen.close()
        else:
            screen.close(result)
        return True
    except Exception as e:
        try:
            _tw_log("Direct close failed for %s: %s" % (screen.__class__.__name__, str(e)))
        except Exception:
            pass
    return False

def _close_plugin_safely(screen):
    """Close the top-level plugin screen gracefully on all images."""
    if screen is None:
        return
    try:
        if _is_openatv_image() or _is_open_source_image():
            if _close_screen_instance(screen):
                return
    except Exception:
        pass
    try:
        if _close_screen_instance(screen):
            return
    except Exception:
        pass
    try:
        ClosePlugin()
    except Exception:
        try:
            screen.close()
        except Exception:
            pass

def _start_auto_update_timer_for_screen(screen):
    minutes = _tw_auto_update_minutes()
    _stop_auto_update_timer_for_screen(screen)
    if minutes <= 0:
        _tw_log("Auto Update timer not started: automatic update disabled")
        return
    try:
        screen._auto_refresh_timer = eTimer()
        _connect_timer(screen._auto_refresh_timer, screen._on_auto_update_timer)
        _start_timer(screen._auto_refresh_timer, int(minutes) * 60 * 1000)
        _tw_log("Auto Update timer started: %s min" % str(minutes))
    except Exception as e:
        _tw_log("Auto Update timer start error: %s" % str(e))

def _stop_auto_update_timer_for_screen(screen):
    try:
        timer = getattr(screen, "_auto_refresh_timer", None)
        if timer is not None:
            _disconnect_timer(timer, screen._on_auto_update_timer)
            try:
                timer.stop()
            except Exception:
                pass
            screen._auto_refresh_timer = None
    except Exception:
        pass

def _handle_auto_update_timer_for_screen(screen, allow_start_location=False):
    try:
        minutes = _tw_auto_update_minutes()
        if minutes <= 0:
            _tw_log("Auto Update timer fired after disable request; stopping timer")
            _stop_auto_update_timer_for_screen(screen)
            return
        from .plugin import _refresh_weather_cache_worker
        location = _runtime_local_city()
        if not location and allow_start_location:
            resolver = globals().get("_resolve_start_location")
            if callable(resolver):
                location = _normalize_location_input(resolver())
        if location:
            _tw_log("Auto Update timer triggered for %s" % str(location))
            _start_background_thread(_refresh_weather_cache_worker, (location,))
    except Exception as e:
        _tw_log("Auto Update timer error: %s" % str(e))
    _stop_auto_update_timer_for_screen(screen)
    _start_auto_update_timer_for_screen(screen)

def _sevendays_header_layout(fullhd):
    if fullhd:
        layout = {
            "main_icon": (700 + SEVENDAYS_MAIN_ICON_SHIFT_X_HD, 108 + SEVENDAYS_MAIN_ICON_SHIFT_Y_HD),
            "wind_icon": (1268 + SEVENDAYS_WIND_ICON_SHIFT_X_HD, 366 + SEVENDAYS_WIND_ICON_SHIFT_Y_HD),
            "city": (540 + SEVENDAYS_CITY_SHIFT_X_HD, 34 + SEVENDAYS_CITY_SHIFT_Y_HD),
            "temp": (950 + SEVENDAYS_TEMP_SHIFT_X_HD, 120 + SEVENDAYS_TEMP_SHIFT_Y_HD),
            "temp_degree": (1210 + SEVENDAYS_TEMP_UNIT_SHIFT_X_HD, 116 + SEVENDAYS_TEMP_UNIT_SHIFT_Y_HD),
            "temp_unit": (1242 + SEVENDAYS_TEMP_UNIT_SHIFT_X_HD, 126 + SEVENDAYS_TEMP_UNIT_SHIFT_Y_HD),
            "feels": (950 + SEVENDAYS_FEELS_SHIFT_X_HD, 248 + SEVENDAYS_FEELS_SHIFT_Y_HD),
            "weather_type": (950 + SEVENDAYS_WEATHER_TYPE_SHIFT_X_HD, 308 + SEVENDAYS_WEATHER_TYPE_SHIFT_Y_HD),
            "wind_text": (950 + SEVENDAYS_WIND_TEXT_SHIFT_X_HD, 360 + SEVENDAYS_WIND_TEXT_SHIFT_Y_HD),
            "trend": (1180 + SEVENDAYS_TREND_SHIFT_X_HD, 155 + SEVENDAYS_TREND_SHIFT_Y_HD),
            "sun_label": (680 + SEVENDAYS_SUN_LABEL_SHIFT_X_HD, 390 + SEVENDAYS_SUN_LABEL_SHIFT_Y_HD),
            "sun_icon": (715 + SEVENDAYS_SUN_ICON_SHIFT_X_HD, 316 + SEVENDAYS_SUN_ICON_SHIFT_Y_HD),
        }
        if _is_openatv_image():
            layout["main_icon"] = (layout["main_icon"][0], layout["main_icon"][1] + 18)
        return layout
    layout = {
        "main_icon": (422 + SEVENDAYS_MAIN_ICON_SHIFT_X_SD, 76 + SEVENDAYS_MAIN_ICON_SHIFT_Y_SD),
        "wind_icon": (778 + SEVENDAYS_WIND_ICON_SHIFT_X_SD, 234 + SEVENDAYS_WIND_ICON_SHIFT_Y_SD),
        "city": (405 + SEVENDAYS_CITY_SHIFT_X_SD, 37 + SEVENDAYS_CITY_SHIFT_Y_SD),
        "temp": (565 + SEVENDAYS_TEMP_SHIFT_X_SD, 88 + SEVENDAYS_TEMP_SHIFT_Y_SD),
        "temp_degree": (704 + SEVENDAYS_TEMP_UNIT_SHIFT_X_SD, 84 + SEVENDAYS_TEMP_UNIT_SHIFT_Y_SD),
        "temp_unit": (732 + SEVENDAYS_TEMP_UNIT_SHIFT_X_SD, 88 + SEVENDAYS_TEMP_UNIT_SHIFT_Y_SD),
        "feels": (565 + SEVENDAYS_FEELS_SHIFT_X_SD, 176 + SEVENDAYS_FEELS_SHIFT_Y_SD),
        "weather_type": (565 + SEVENDAYS_WEATHER_TYPE_SHIFT_X_SD, 208 + SEVENDAYS_WEATHER_TYPE_SHIFT_Y_SD),
        "wind_text": (565 + SEVENDAYS_WIND_TEXT_SHIFT_X_SD, 240 + SEVENDAYS_WIND_TEXT_SHIFT_Y_SD),
        "trend": (752 + SEVENDAYS_TREND_SHIFT_X_SD, 99 + SEVENDAYS_TREND_SHIFT_Y_SD),
        "sun_label": (416 + SEVENDAYS_SUN_LABEL_SHIFT_X_SD, 248 + SEVENDAYS_SUN_LABEL_SHIFT_Y_SD),
        "sun_icon": (426 + SEVENDAYS_SUN_ICON_SHIFT_X_SD, 206 + SEVENDAYS_SUN_ICON_SHIFT_Y_SD),
    }
    if _is_openatv_image():
        layout["main_icon"] = (layout["main_icon"][0], layout["main_icon"][1] + 12)
    return layout

def _sevendays_middle_icon_position(day, fullhd):
    if fullhd:
        return (
            131 + (248 * day) + SEVENDAYS_MIDDLE_ICON_SHIFT_X_HD,
            498 + SEVENDAYS_MIDDLE_ICON_SHIFT_Y_HD,
        )
    return (
        87 + (165 * day) + SEVENDAYS_MIDDLE_ICON_SHIFT_X_SD,
        334 + SEVENDAYS_MIDDLE_ICON_SHIFT_Y_SD,
    )

def _sevendays_middle_icon_geometry(day, fullhd):
    icon_x, icon_y = _sevendays_middle_icon_position(day, fullhd)
    if fullhd:
        return icon_x, icon_y, SEVENDAYS_MIDDLE_ICON_SIZE_HD
    return icon_x, icon_y, SEVENDAYS_MIDDLE_ICON_SIZE_SD

def _sevendays_main_icon_animation_start(target_x, target_y, fullhd):
    if fullhd:
        if _is_dreambox_image() and not PY3:
            return target_x - 300, target_y
        if _is_vti_image():
            return target_x, target_y + 60
        if _is_openatv_image():
            return target_x - 300, target_y
        if _is_open_source_image():
            return target_x, target_y + 70
        return target_x, target_y + 64
    if _is_dreambox_image() and not PY3:
        return target_x - 200, target_y
    if _is_vti_image():
        return target_x, target_y + 36
    if _is_openatv_image():
        return target_x - 200, target_y
    if _is_open_source_image():
        return target_x, target_y + 42
    return target_x, target_y + 38

def _forecast_graph_temp_unit_layout(fullhd):
    # Keep the degree/unit label visible on Dreambox, VU+, OpenATV, VTI, and open-source images.
    if fullhd:
        layout = {"x_shift": 6, "y_shift": 0, "width": 42, "height": 54, "font": 28}
        if _is_dreambox_image() and not PY3:
            layout["x_shift"] = 4
            layout["width"] = 40
        elif _is_vti_image():
            layout["x_shift"] = 7
            layout["width"] = 44
        elif _is_openatv_image() or _is_open_source_image():
            layout["x_shift"] = 8
            layout["width"] = 46
        return layout

    layout = {"x_shift": 4, "y_shift": 0, "width": 28, "height": 36, "font": 18}
    if _is_dreambox_image() and not PY3:
        layout["x_shift"] = 4
        layout["width"] = 28
    elif _is_vti_image():
        layout["x_shift"] = 5
        layout["width"] = 30
    elif _is_openatv_image() or _is_open_source_image():
        layout["x_shift"] = 6
        layout["width"] = 32
    return layout

def _sevendays_day_temp_layout(fullhd):
    # Reserve enough room for values such as 25 deg C / 25 deg F inside the day cards on every image family.
    if fullhd:
        layout = {
            "max_x_shift": 0,
            "max_width": 84,
            "max_height": 54,
            "max_font": 48,
            "max_unit_x_shift": 56,
            "max_unit_width": 22,
            "max_unit_height": 54,
            "max_unit_font": 44,
            "min_x_shift": 4,
            "min_width": 104,
            "min_height": 36,
            "min_font": 28,
        }
        if _is_dreambox_image() and not PY3:
            layout["max_width"] = 86
            layout["max_unit_x_shift"] = 62
            layout["min_width"] = 108
        elif _is_vti_image():
            layout["max_width"] = 88
            layout["max_unit_x_shift"] = 60
            layout["min_x_shift"] = 6
            layout["min_width"] = 112
        elif _is_openatv_image() or _is_open_source_image():
            layout["max_width"] = 90
            layout["max_unit_x_shift"] = 62
            layout["min_x_shift"] = 8
            layout["min_width"] = 116
        return layout

    layout = {
        "max_x_shift": 0,
        "max_width": 54,
        "max_height": 36,
        "max_font": 32,
        "max_unit_x_shift": 32,
        "max_unit_width": 14,
        "max_unit_height": 36,
        "max_unit_font": 28,
        "min_x_shift": 4,
        "min_width": 54,
        "min_height": 22,
        "min_font": 18,
    }
    if _is_dreambox_image() and not PY3:
        layout["max_width"] = 56
        layout["max_unit_x_shift"] = 37
        layout["min_width"] = 56
    elif _is_vti_image():
        layout["max_width"] = 58
        layout["max_unit_x_shift"] = 34
        layout["min_x_shift"] = 6
        layout["min_width"] = 58
    elif _is_openatv_image() or _is_open_source_image():
        layout["max_width"] = 60
        layout["max_unit_x_shift"] = 35
        layout["min_x_shift"] = 8
        layout["min_width"] = 60
    return layout

def _sevendays_bottom_icon_position(slot, fullhd):
    if fullhd:
        return (
            120 + (216 * slot) + SEVENDAYS_BOTTOM_ICON_SHIFT_X_HD,
            749,
        )
    return (
        80 + (144 * slot) + SEVENDAYS_BOTTOM_ICON_SHIFT_X_SD,
        494,
    )


def _main_temp_unit_parts():
    suffix_text = _ensure_text(_tw_temp_suffix())
    if not suffix_text:
        return u"", u""
    degree_text = u"\u00B0" if u"\u00B0" in suffix_text else suffix_text[:1]
    if degree_text == u"\u00B0":
        unit_text = suffix_text.replace(u"\u00B0", u"", 1)
    else:
        unit_text = suffix_text[1:]
    return degree_text, unit_text

def _day_card_max_temp_parts(value, default="--"):
    degree_text, unit_text = _main_temp_unit_parts()
    value_text = _format_temperature_text(value, 0, default) + degree_text
    return value_text, unit_text

def _get_hourly_strip_entries(day_data, day_index, max_slots=8):
    hours = []
    if isinstance(day_data, dict):
        hours = list(day_data.get("hours") or [])
    if not hours:
        return []

    visible_hours = list(hours)
    if day_index == 0:
        current_hour = datetime.datetime.now().hour
        remaining_hours = []
        for hour_item in visible_hours:
            try:
                hour_value = int(_get_mapping_value(hour_item, "hour"))
            except Exception:
                hour_value = None
            if hour_value is not None and hour_value >= current_hour:
                remaining_hours.append(hour_item)
        if remaining_hours:
            visible_hours = remaining_hours

    if day_index == 0:
        step = int(math.ceil(float(len(visible_hours)) / float(max_slots)))
    else:
        step = 3
    if step < 1:
        step = 1

    slots = []
    for slot_index in range(max_slots):
        hour_index = slot_index * step
        if hour_index < len(visible_hours):
            slots.append(visible_hours[hour_index])
    return slots

def _forecast_provider_name(payload=None):
    if payload is None:
        payload = globals().get("weatherData")
    if isinstance(payload, dict):
        provider_name = _ensure_text(payload.get("provider", payload.get("service", ""))).strip().lower()
        if provider_name:
            return provider_name
    normalizer = _runtime_plugin_value("_normalized_weather_service_value")
    if callable(normalizer):
        try:
            return _ensure_text(normalizer()).strip().lower()
        except Exception:
            pass
    return _ensure_text(_tw_cfg("weatherservice", "open-meteo")).strip().lower()


def _forecast_screen_day_count(data_days, default_limit=16, payload=None):
    total_days = len(list(data_days or []))
    if total_days <= 0:
        return 0
    safe_limit = int(default_limit or 0)
    if _forecast_provider_name(payload) == "buienradar":
        safe_limit = 14
    if isinstance(payload, dict):
        payload_limit = payload.get("screen_days", payload.get("forecast_days", 0))
        try:
            payload_limit = int(payload_limit or 0)
        except Exception:
            payload_limit = 0
        if payload_limit > 0:
            safe_limit = min(safe_limit or payload_limit, payload_limit)
    if safe_limit <= 0:
        safe_limit = total_days
    return max(0, min(safe_limit, total_days))


def _forecast_day_column_offset(fullhd, visible_days):
    visible_days = int(visible_days or 0)
    if visible_days <= 0:
        return 0
    max_slots = 16
    slot_step = 113 if fullhd else 74
    if visible_days >= max_slots:
        return 0
    return int(((max_slots - visible_days) * slot_step) / 2)


def _forecast_days_screen_class(payload=None):
    if _forecast_provider_name(payload) == "buienradar":
        return FourteenDays
    return SixteenDays

class sevendays(Screen):
    def __init__(self, session):
        bind_runtime()
        Screen.__init__(self, session)
        AddNewScreen(self)
        self["lastUpdate"] = StaticText()
        self["background"] = Pixmap()
        dayinfoblok = ""
        global weatherData
        dataDays = weatherData["days"]
        self.selected = 0
        self._return_action_block_until = 0.0
        self._settings_open_timer = None
        self._settings_open_pending = False
        self._settings_open_callback = None
        self._plugin_close_timer = None
        self._plugin_close_pending = False
        self._plugin_close_callback = None
        protemp = []
        peocpic = ""
        try:
            for procdays in dataDays:
                for prochours in procdays["hours"]:
                    protemp.append(round(prochours["temperature"]))
                if len(protemp) > 3:
                    break
        except Exception:
            pass
        try:
            if protemp[0] > protemp[1]:
                peocpic = "tempcold.png"
            elif protemp[0] < protemp[1]:
                peocpic = "temphot.png"
            else:
                peocpic = "tempeven.png"
        except Exception:
            pass
        _tw_log("Sevendays main screen initializing")
        layout_hd = _sevendays_header_layout(True)
        layout_sd = _sevendays_header_layout(False)
        card_temp_layout_hd = _sevendays_day_temp_layout(True)
        card_temp_layout_sd = _sevendays_day_temp_layout(False)
        sunrise_label_text = _get_day_sunrise_sunset_text(dataDays[0]) if dataDays else "--:-- - --:--"
        if _use_fullhd_layout():
            for day in range(0, min(7, len(dataDays))):
                hourCount = 0
                day_data = dataDays[day]
                representative_hour = _get_display_hour_for_day(day_data, day)
                _raw_wind = _get_mapping_value(representative_hour, "winddirection") or _get_mapping_value(day_data, "winddirection") or "na"
                windForce = _tw_get_safe_wind_icon(iconpath, _raw_wind, "windhd")
                dataHour = _ensure_text(_get_mapping_value(representative_hour, "iconcode") or _get_mapping_value(day_data, "iconcode") or "na")
                losticon = _ensure_text(_get_mapping_value(day_data, "iconcode") or "na")
                middle_icon_x, middle_icon_y, middle_icon_size = _sevendays_middle_icon_geometry(day, True)
                dayinfoblok += """
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str(layout_hd["main_icon"][0]) + """,""" + str(layout_hd["main_icon"][1]) + """\" size="153,153" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconbighd/""" + str(dataHour) + """.png" zPosition="1" alphatest="blend"/>
                    <widget name="bigDirIcon1""" + str(day) + """" position=\"""" + str(layout_hd["wind_icon"][0]) + """,""" + str(layout_hd["wind_icon"][1]) + """\" size="52,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/""" + str(windForce) + """.png" zPosition="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/""" + str(losticon) + """.png" position=\"""" + str(middle_icon_x) + """,""" + str(middle_icon_y) + """\" size=\"""" + str(middle_icon_size) + """,""" + str(middle_icon_size) + """\" zPosition="3" transparent="0" alphatest="blend"/>
                    <widget render="Label" source="smallday2""" + str(day) + """" position=\"""" + str(138 + (248 * day)) + """,461" size="135,40" zPosition="3" valign="center" halign="left" font="Regular;34" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="maxtemp2""" + str(day) + """" position=\"""" + str(130 + card_temp_layout_hd["max_x_shift"] + (248 * day)) + """,571" size=\"""" + str(card_temp_layout_hd["max_width"]) + """,""" + str(card_temp_layout_hd["max_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_hd["max_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
                    <widget render="Label" source="maxtemp2Unit""" + str(day) + """" position=\"""" + str(130 + card_temp_layout_hd["max_unit_x_shift"] + (248 * day)) + """,571" size=\"""" + str(card_temp_layout_hd["max_unit_width"]) + """,""" + str(card_temp_layout_hd["max_unit_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_hd["max_unit_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="minitemp2""" + str(day) + """" position=\"""" + str(240 + card_temp_layout_hd["min_x_shift"] + (248 * day)) + """,587" size=\"""" + str(card_temp_layout_hd["min_width"]) + """,""" + str(card_temp_layout_hd["min_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_hd["min_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="weathertype""" + str(day) + """" position=\"""" + str(105 + (248 * day)) + """,617" size="220,86" zPosition="3" valign="center" halign="center" font="Regular;24" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="sunriseLabel" position=\"""" + str(layout_hd["sun_label"][0]) + """,""" + str(layout_hd["sun_label"][1]) + """\" size="240,44" zPosition="3" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/sunupdownhd.png" zPosition="3" position=\"""" + str(layout_hd["sun_icon"][0]) + """,""" + str(layout_hd["sun_icon"][1]) + """\" size="132,66" alphatest="blend"/>"""
                dataHour = _get_hourly_strip_entries(day_data, day, 8)
                self["bigWeerIcon1" + str(day)] = MovingPixmap()
                self["bigDirIcon1" + str(day)] = Pixmap()
                self["smallday2" + str(day)] = StaticText()
                self["maxtemp2" + str(day)] = StaticText()
                self["maxtemp2Unit" + str(day)] = StaticText()
                self["minitemp2" + str(day)] = StaticText()
                self["weathertype" + str(day)] = StaticText()
                self["sunriseLabel" + str(day)] = StaticText()
                for hourCount in range(8):
                    if hourCount < len(dataHour):
                        data = dataHour[hourCount]
                    else:
                        data = {"iconcode": "na"}
                    bottom_icon_x, bottom_icon_y = _sevendays_bottom_icon_position(hourCount, True)
                    dayinfoblok += """<widget name="dayIcon""" + str(day) + "" + str(hourCount) + """" position=\"""" + str(bottom_icon_x) + """,""" + str(bottom_icon_y) + """\" size="72,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/""" + data.get("iconcode", "na") + """.png" zPosition="1" alphatest="blend"/>"""
                    self["dayIcon" + str(day) + str(hourCount)] = Pixmap()
            # Note: sunriseLabel and sun_icon are added per-day inside the day loop above.
            # No duplicate entry needed here outside the loop.

            for hour in range(0, 8):
                dayinfoblok += """
                    <widget render="Label" source="dayHour""" + str(hour) + """" position=\"""" + str(195 + (216 * hour)) + """,757" size="90,36" zPosition="3" valign="center" halign="right" font="Regular;33" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dayTemp""" + str(hour) + """" position=\"""" + str(120 + (216 * hour)) + """,820" size="180,54" zPosition="3" valign="center" halign="left" font="Regular;48" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="sunPercent""" + str(hour) + """" position=\"""" + str(168 + (216 * hour)) + """,883" size="123,32" zPosition="3" valign="center" halign="left" font="Regular;27" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dayPercent""" + str(hour) + """" position=\"""" + str(168 + (216 * hour)) + """,922" size="120,30" zPosition="3" valign="center" halign="left" font="Regular;27" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="humidityPercent""" + str(hour) + """" position=\"""" + str(168 + (216 * hour)) + """,961" size="123,32" zPosition="3" valign="center" halign="left" font="Regular;27" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="daySpeed""" + str(hour) + """" position=\"""" + str(168 + (216 * hour)) + """,1000" size="123,32" zPosition="3" valign="center" halign="left" font="Regular;27" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/sunpchd.png" position=\"""" + str(114 + (216 * hour)) + """,879" size="36,36" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/rainhd.png" position=\"""" + str(116 + (216 * hour)) + """,921" size="30,30" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/rhhd.png" position=\"""" + str(120 + (216 * hour)) + """,960" size="23,30" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/turbinehd.png" position=\"""" + str(119 + (216 * hour)) + """,997" size="38,38" zPosition="3" alphatest="blend"/>"""
                self["dayHour" + str(hour)] = StaticText()
                self["dayTemp" + str(hour)] = StaticText()
                self["sunPercent" + str(hour)] = StaticText()
                self["dayPercent" + str(hour)] = StaticText()
                self["humidityPercent" + str(hour)] = StaticText()
                self["daySpeed" + str(hour)] = StaticText()
            skin = """
                    <screen name="sevenday" title="seven" flags="wfNoBorder" position="center,center" size="1920,1080">
                    <widget name="background" position="center,center" size="1920,1080" pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=True) + """\" zPosition="0" alphatest="blend"/>
                    <widget render="Label" source="lastUpdate" position="60,40" size="600,50" transparent="1" zPosition="1" font="Regular;32" valign="center" halign="left" foregroundColor="#55ff55" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget source="global.CurrentTime" render="Label" position="1608,30" size="250,50" transparent="1" zPosition="1" font="Regular;38" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="1360,76" size="500,38" transparent="1" zPosition="1" font="Regular;26" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget name="yellowdot" position="285,468" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/buttons/yeldothd.png" zPosition="3" alphatest="blend"/>
                    <widget render="Label" source="city1" position=\"""" + str(layout_hd["city"][0]) + """,""" + str(layout_hd["city"][1]) + """\" size="840,72" zPosition="3" valign="center" halign="center" font="Regular;50" transparent="1"/>
                    <widget render="Label" source="bigTempValue" position=\"""" + str(layout_hd["temp"][0]) + """,""" + str(layout_hd["temp"][1]) + """\" size="280,128" zPosition="3" valign="center" halign="left" font="Regular;118" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigTempDegree" position=\"""" + str(layout_hd["temp_degree"][0]) + """,""" + str(layout_hd["temp_degree"][1]) + """\" size="40,72" zPosition="3" valign="center" halign="left" font="Regular;100" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigTempUnit" position=\"""" + str(layout_hd["temp_unit"][0]) + """,""" + str(layout_hd["temp_unit"][1]) + """\" size="110,110" zPosition="3" valign="center" halign="left" font="Regular;104" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigWeatherType" position=\"""" + str(layout_hd["weather_type"][0]) + """,""" + str(layout_hd["weather_type"][1]) + """\" size="560,44" zPosition="3" valign="center" halign="left" font="Regular;32" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="feelsLikeTemp" position=\"""" + str(layout_hd["feels"][0]) + """,""" + str(layout_hd["feels"][1]) + """\" size="420,44" zPosition="3" valign="center" halign="left" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="windDir" position=\"""" + str(layout_hd["wind_text"][0]) + """,""" + str(layout_hd["wind_text"][1]) + """\" size="420,44" zPosition="3" valign="center" halign="left" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>""" + dayinfoblok + """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/menubutton.png" position="1500,42" size="85,54" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/okbutton.png" position="1610,42" size="54,54" alphatest="blend"/>
                    </screen>"""
        else:
            for day in range(0, min(7, len(dataDays))):
                hourCount = 0
                day_data = dataDays[day]
                representative_hour = _get_display_hour_for_day(day_data, day)
                _raw_wind = _get_mapping_value(representative_hour, "winddirection") or _get_mapping_value(day_data, "winddirection") or "na"
                windForce = _tw_get_safe_wind_icon(iconpath, _raw_wind, "wind")
                dataHour = _ensure_text(_get_mapping_value(representative_hour, "iconcode") or _get_mapping_value(day_data, "iconcode") or "na")
                losticon = _ensure_text(_get_mapping_value(day_data, "iconcode") or "na")
                middle_icon_x, middle_icon_y, middle_icon_size = _sevendays_middle_icon_geometry(day, False)
                dayinfoblok += """
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str(layout_sd["main_icon"][0]) + """,""" + str(layout_sd["main_icon"][1]) + """\" size="90,90" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconbigsd/""" + str(dataHour) + """.png" zPosition="1" alphatest="blend"/>
                    <widget name="bigDirIcon1""" + str(day) + """" position=\"""" + str(layout_sd["wind_icon"][0]) + """,""" + str(layout_sd["wind_icon"][1]) + """\" size="28,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/""" + str(windForce) + """.png" zPosition="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/""" + str(losticon) + """.png" position=\"""" + str(middle_icon_x) + """,""" + str(middle_icon_y) + """\" size=\"""" + str(middle_icon_size) + """,""" + str(middle_icon_size) + """\" zPosition="3" transparent="0" alphatest="blend"/>
                    <widget render="Label" source="smallday2""" + str(day) + """" position=\"""" + str(92 + (165 * day)) + """,308" size="90,24" zPosition="3" valign="center" halign="left" font="Regular;22" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="maxtemp2""" + str(day) + """" position=\"""" + str(92 + card_temp_layout_sd["max_x_shift"] + (165 * day)) + """,382" size=\"""" + str(card_temp_layout_sd["max_width"]) + """,""" + str(card_temp_layout_sd["max_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_sd["max_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
                    <widget render="Label" source="maxtemp2Unit""" + str(day) + """" position=\"""" + str(92 + card_temp_layout_sd["max_unit_x_shift"] + (165 * day)) + """,382" size=\"""" + str(card_temp_layout_sd["max_unit_width"]) + """,""" + str(card_temp_layout_sd["max_unit_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_sd["max_unit_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="minitemp2""" + str(day) + """" position=\"""" + str(160 + card_temp_layout_sd["min_x_shift"] + (165 * day)) + """,395" size=\"""" + str(card_temp_layout_sd["min_width"]) + """,""" + str(card_temp_layout_sd["min_height"]) + """\" zPosition="3" valign="center" halign="left" font="Regular;""" + str(card_temp_layout_sd["min_font"]) + """" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="weathertype""" + str(day) + """" position=\"""" + str(77 + (165 * day)) + """,416" size="138,44" zPosition="3" valign="center" halign="center" font="Regular;16" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="sunriseLabel" position=\"""" + str(layout_sd["sun_label"][0]) + """,""" + str(layout_sd["sun_label"][1]) + """\" size="200,40" zPosition="3" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/sunupdownsd.png" zPosition="3" position=\"""" + str(layout_sd["sun_icon"][0]) + """,""" + str(layout_sd["sun_icon"][1]) + """\" size="80,40" alphatest="blend"/>"""
                dataHour = _get_hourly_strip_entries(day_data, day, 8)
                self["bigWeerIcon1" + str(day)] = MovingPixmap()
                self["bigDirIcon1" + str(day)] = Pixmap()
                self["smallday2" + str(day)] = StaticText()
                self["maxtemp2" + str(day)] = StaticText()
                self["maxtemp2Unit" + str(day)] = StaticText()
                self["minitemp2" + str(day)] = StaticText()
                self["weathertype" + str(day)] = StaticText()
                self["sunriseLabel" + str(day)] = StaticText()
                for hourCount in range(8):
                    if hourCount < len(dataHour):
                        data = dataHour[hourCount]
                    else:
                        data = {"iconcode": "na"}
                    bottom_icon_x, bottom_icon_y = _sevendays_bottom_icon_position(hourCount, False)
                    dayinfoblok += """<widget name="dayIcon""" + str(day) + "" + str(hourCount) + """" position=\"""" + str(bottom_icon_x) + """,""" + str(bottom_icon_y) + """\" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/""" + data.get("iconcode", "na") + """.png" zPosition="1" alphatest="blend"/>"""
                    self["dayIcon" + str(day) + str(hourCount)] = Pixmap()
            dayinfoblok += """
                    <widget render="Label" source="sunriseLabel" position=\"""" + str(layout_sd["sun_label"][0]) + """,""" + str(layout_sd["sun_label"][1]) + """\" size="200,40" zPosition="3" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/sunupdownsd.png" zPosition="3" position=\"""" + str(layout_sd["sun_icon"][0]) + """,""" + str(layout_sd["sun_icon"][1]) + """\" size="80,40" alphatest="blend"/>"""

            for hour in range(0, 8):
                dayinfoblok += """
                    <widget render="Label" source="dayHour""" + str(hour) + """" position=\"""" + str(130 + (144 * hour)) + """,506" size="60,24" zPosition="3" valign="center" halign="right" font="Regular;22" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dayTemp""" + str(hour) + """" position=\"""" + str(80 + (144 * hour)) + """,540" size="120,36" zPosition="3" valign="center" halign="left" font="Regular;32" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="sunPercent""" + str(hour) + """" position=\"""" + str(112 + (144 * hour)) + """,580" size="82,21" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dayPercent""" + str(hour) + """" position=\"""" + str(112 + (144 * hour)) + """,606" size="80,20" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="humidityPercent""" + str(hour) + """" position=\"""" + str(112 + (144 * hour)) + """,632" size="80,20" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="daySpeed""" + str(hour) + """" position=\"""" + str(112 + (144 * hour)) + """,658" size="82,21" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/sunpcsd.png" position=\"""" + str(76 + (144 * hour)) + """,578" size="24,24" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/rainsd.png" position=\"""" + str(77 + (144 * hour)) + """,605" size="20,20" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/rhsd.png" position=\"""" + str(79 + (144 * hour)) + """,632" size="16,20" zPosition="3" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/wind/turbine.png" position=\"""" + str(79 + (144 * hour)) + """,656" size="25,25" zPosition="3" alphatest="blend"/>"""
                self["dayHour" + str(hour)] = StaticText()
                self["dayTemp" + str(hour)] = StaticText()
                self["sunPercent" + str(hour)] = StaticText()
                self["dayPercent" + str(hour)] = StaticText()
                self["humidityPercent" + str(hour)] = StaticText()
                self["daySpeed" + str(hour)] = StaticText()
            skin = """
                    <screen name="sevenday" title="seven" flags="wfNoBorder" position="center,center" size="1280,720">
                    <widget name="background" position="center,center" size="1280,720" pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=False) + """\" zPosition="0" alphatest="blend"/>
                    <widget render="Label" source="lastUpdate" position="40,25" size="400,35" transparent="1" zPosition="1" font="Regular;22" valign="center" halign="left" foregroundColor="#55ff55" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget source="global.CurrentTime" render="Label" position="1091,12" size="150,55" transparent="1" zPosition="1" font="Regular;24" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="941,32" size="300,55" transparent="1" zPosition="1" font="Regular;16" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget name="yellowdot" position="184,307" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/buttons/yeldot.png" zPosition="3" alphatest="blend"/>
                    <widget render="Label" source="city1" position=\"""" + str(layout_sd["city"][0]) + """,""" + str(layout_sd["city"][1]) + """\" size="470,42" zPosition="3" valign="center" halign="center" font="Regular;28" transparent="1"/>
                    <widget render="Label" source="bigTempValue" position=\"""" + str(layout_sd["temp"][0]) + """,""" + str(layout_sd["temp"][1]) + """\" size="160,76" zPosition="3" valign="center" halign="left" font="Regular;72" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigTempDegree" position=\"""" + str(layout_sd["temp_degree"][0]) + """,""" + str(layout_sd["temp_degree"][1]) + """\" size="28,44" zPosition="3" valign="center" halign="left" font="Regular;64" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigTempUnit" position=\"""" + str(layout_sd["temp_unit"][0]) + """,""" + str(layout_sd["temp_unit"][1]) + """\" size="72,68" zPosition="3" valign="center" halign="left" font="Regular;68" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="bigWeatherType" position=\"""" + str(layout_sd["weather_type"][0]) + """,""" + str(layout_sd["weather_type"][1]) + """\" size="320,30" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="feelsLikeTemp" position=\"""" + str(layout_sd["feels"][0]) + """,""" + str(layout_sd["feels"][1]) + """\" size="236,30" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="windDir" position=\"""" + str(layout_sd["wind_text"][0]) + """,""" + str(layout_sd["wind_text"][1]) + """\" size="230,30" zPosition="3" valign="center" halign="left" font="Regular;18" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>""" + dayinfoblok + """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/menubuttonsd.png" position="1015,29" size="55,36" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/okbuttonsd.png" position="1085,29" size="36,36" alphatest="blend"/>
                    </screen>"""

        self["city1"] = StaticText()
        _set_component_text(self["city1"], _runtime_city_display_name())
        self["bigTempValue"] = StaticText()
        self["bigTempDegree"] = StaticText()
        self["bigTempUnit"] = StaticText()
        self["bigWeatherType"] = StaticText()
        self["feelsLikeTemp"] = StaticText()
        self["windDir"] = StaticText()
        self["yellowdot"] = MovingPixmap()
        for hour in range(0, 8):
            self["dayHour" + str(hour)] = StaticText()
            _set_component_text(self["dayHour" + str(hour)], "00h")
            self["dayTemp" + str(hour)] = StaticText()
            _set_component_text(self["dayTemp" + str(hour)], "--" + _tw_temp_suffix())
            self["sunPercent" + str(hour)] = StaticText()
            _set_component_text(self["sunPercent" + str(hour)], "--%")
            self["dayPercent" + str(hour)] = StaticText()
            _set_component_text(self["dayPercent" + str(hour)], "--%")
            self["humidityPercent" + str(hour)] = StaticText()
            _set_component_text(self["humidityPercent" + str(hour)], "--%")
            self["daySpeed" + str(hour)] = StaticText()
            _set_component_text(self["daySpeed" + str(hour)], "--Km/h")
            for day in range(0, min(7, len(dataDays))):
                try:
                    self["dayIcon" + str(day) + str(hour)].hide()
                except Exception:
                    pass
        dataDays = weatherData["days"]
        self["sunriseLabel"] = StaticText()
        _set_component_text(self["sunriseLabel"], sunrise_label_text)
        for day in range(0, min(7, len(dataDays))):
            day_data = dataDays[day]
            iconclass = _ensure_text(_get_mapping_value(day_data, "iconcode") or "na")
            info1 = _format_day_summary_label(day_data)
            _raw_min = _get_mapping_value(day_data, "mintemp", "mintemperature")
            _raw_max = _get_mapping_value(day_data, "maxtemp", "maxtemperature")
            info2 = '{:>3}'.format(_format_day_temperature_label(_tw_convert_temp(_raw_min)))
            info3_value, info3_unit = _day_card_max_temp_parts(_tw_convert_temp(_raw_max), "--")
            info3 = '{:>3}'.format(info3_value)

            self["smallday2" + str(day)] = StaticText()
            _set_component_text(self["smallday2" + str(day)], info1)
            self["maxtemp2" + str(day)] = StaticText()
            _set_component_text(self["maxtemp2" + str(day)], info3)
            self["maxtemp2Unit" + str(day)] = StaticText()
            _set_component_text(self["maxtemp2Unit" + str(day)], info3_unit)
            self["minitemp2" + str(day)] = StaticText()
            _set_component_text(self["minitemp2" + str(day)], info2)
            self["weathertype" + str(day)] = StaticText()
            _set_component_text(self["weathertype" + str(day)], icontotext(iconclass))
        if PY3 and (_is_openatv_image() or _is_open_source_image()):
            # OpenATV/open-source keeps the older 5.3 ActionMap path because it
            # behaved correctly there before the Dreambox-specific menu changes.
            self["myActionMap"] = ActionMap(
                ["SetupActions", "ColorActions", "MenuActions"],
                {
                    "menu": self.KeyMenu,
                    "left": self.left,
                    "right": self.right,
                    "yellow": self.keyYellow,
                    "blue": self.keyBlue,
                    "ok": self.fourteendays,
                    "cancel": self.cancel,
                    "red": self.exit,
                },
                -1
            )
        else:
            self["myActionMap"] = build_action_map(
                self,
                ["TheWeatherIet5Actions", "SetupActions", "ColorActions", "MenuActions"],
                {
                    "menu": self.KeyMenu,
                    "openMenu": self.KeyMenu,
                    "left": self.left,
                    "right": self.right,
                    "yellow": self.keyYellow,
                    "blue": self.keyBlue,
                    "ok": self.fourteendays,
                    "cancel": self.cancel,
                    "red": self.exit,
                },
                -1
            )
        self.skin = _apply_skin_path(skin)
        try:
            _sync_active_background()
        except Exception:
            pass
        self.onLayoutFinish.append(self._refresh_background_pixmap)
        self.updateFrameselect()
        self._auto_refresh_timer = None
        self.onClose.append(self._stop_auto_update_timer)
        self.onClose.append(self._cleanup_settings_open_timer)
        self.onClose.append(self._cleanup_plugin_close_timer)
        self._start_auto_update_timer()

    def _refresh_background_pixmap(self):
        try:
            background_path = _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=_use_fullhd_layout())
            background_widget = self["background"]
        except Exception:
            return False
        try:
            background_instance = getattr(background_widget, "instance", None)
            if background_instance is not None and hasattr(background_instance, "setPixmapFromFile"):
                background_instance.setPixmapFromFile(background_path)
                try:
                    background_widget.show()
                except Exception:
                    pass
                return True
        except Exception as e:
            _tw_log("Background pixmap refresh error: %s" % str(e))
        return False

    def updateFrameselect(self):
        global weatherData
        dataDays = weatherData["days"]
        visible_days = min(7, len(dataDays))
        if visible_days < 1:
            return
        _refresh_screen_city_label(self)
        if self.selected < 0:
            self.selected = visible_days - 1
        elif self.selected >= visible_days:
            self.selected = 0

        if _use_fullhd_layout():
            _move_pixmap(self["yellowdot"], 285 + (248 * self.selected), 468, 10)
        else:
            _move_pixmap(self["yellowdot"], 184 + (165 * self.selected), 307, 10)
        selected_day = dataDays[self.selected]
        dataPerHour = _get_hourly_strip_entries(selected_day, self.selected, 8)
        selected_hour = _get_display_hour_for_day(selected_day, self.selected)
        _set_component_text(self["lastUpdate"], _("Last update: ") + lastUpdateTime)

        _degree_text, _unit_text = _main_temp_unit_parts()
        _set_component_text(self["bigTempValue"], "NA")
        _set_component_text(self["bigTempDegree"], _degree_text)
        _set_component_text(self["bigTempUnit"], _unit_text)
        _set_component_text(self["bigWeatherType"], "na")
        _set_component_text(self["feelsLikeTemp"], _("Feels Like: ") + "NA" + _tw_temp_suffix())
        _set_component_text(self["windDir"], _("Wind direction: ") + "NA")
        try:
            display_temp = _get_mapping_value(selected_hour, "temperature")
            if display_temp is None:
                display_temp = _get_mapping_value(selected_day, "maxtemperature")
            display_feels = _get_mapping_value(selected_hour, "feeltemperature", "temperature")
            display_wind = _get_mapping_value(selected_hour, "winddirection") or _get_mapping_value(selected_day, "winddirection")
            display_icon = _get_mapping_value(selected_hour, "iconcode") or _get_mapping_value(selected_day, "iconcode") or "na"
            _conv_temp   = _tw_convert_temp(display_temp)
            _conv_feels  = _tw_convert_temp(display_feels)
            _degree_text, _unit_text = _main_temp_unit_parts()
            _unit_sfx    = _tw_temp_suffix()
            _set_component_text(self["bigTempValue"], '{:>4}'.format(_format_temperature_text(_conv_temp, 1, "NA")))
            _set_component_text(self["bigTempDegree"], _degree_text)
            _set_component_text(self["bigTempUnit"], _unit_text)
            _set_component_text(self["feelsLikeTemp"], _("Feels Like: ") + _format_temperature_text(_conv_feels, 1, "NA") + _unit_sfx)
            _set_component_text(self["windDir"], _("Wind direction: ") + str(winddirtext(display_wind)))
            _set_component_text(self["bigWeatherType"], icontotext(str(display_icon)))
        except Exception:
            pass

        for day in range(0, visible_days):
            self["bigWeerIcon1" + str(day)].hide()
            self["bigDirIcon1" + str(day)].hide()

        try:
            use_fullhd = _use_fullhd_layout()
            target_layout = _sevendays_header_layout(use_fullhd)
            target_x = target_layout["main_icon"][0]
            target_y = target_layout["main_icon"][1]
            start_x, start_y = _sevendays_main_icon_animation_start(target_x, target_y, use_fullhd)

            sel_icon = self["bigWeerIcon1" + str(self.selected)]
            _move_pixmap(sel_icon, start_x, start_y, 0)
            self["bigWeerIcon1" + str(self.selected)].show()
            _move_pixmap(sel_icon, target_x, target_y, 20)
        except Exception:
            pass

        self["bigWeerIcon1" + str(self.selected)].show()
        self["bigDirIcon1" + str(self.selected)].show()

        for perHourUpdate in range(0, 8):
            for day in range(0, visible_days):
                self["dayIcon" + str(day) + str(perHourUpdate)].hide()
            try:
                if perHourUpdate < len(dataPerHour):
                    self["dayIcon" + str(self.selected) + str(perHourUpdate)].show()
                    _populate_hour_slot(self, perHourUpdate, dataPerHour[perHourUpdate])
                else:
                    _populate_hour_slot(self, perHourUpdate, None)
            except Exception:
                # Could not update hour slot - safely skip and leave defaults
                pass

    def KeyMenu(self):
        # Open Theweather setting screen on MENU button press.
        try:
            _tw_log("[Sevendays] MENU key pressed, attempting to open settings")
            if self._defer_ui_actions_on_current_image():
                _tw_log("[Sevendays] Deferring settings open to avoid blank/freeze state on this image")
                self._schedule_settings_open(delay_ms=120)
            else:
                self._open_settings_screen()
        except Exception as e:
            _tw_log("[Sevendays] KeyMenu error: " + str(e))
            print("[TheWeather] KeyMenu error: " + str(e))
            try:
                self.session.open(MessageBox, _("Settings screen could not be opened."), MESSAGEBOX_TYPE_INFO)
            except Exception:
                pass

    def _cleanup_settings_open_timer(self):
        timer = getattr(self, "_settings_open_timer", None)
        callback = getattr(self, "_settings_open_callback", None)
        try:
            if timer is not None:
                timer.stop()
        except Exception:
            pass
        try:
            if timer is not None and callback is not None:
                _disconnect_timer(timer, callback)
        except Exception:
            pass
        self._settings_open_timer = None
        self._settings_open_pending = False
        self._settings_open_callback = None

    def _cleanup_plugin_close_timer(self):
        timer = getattr(self, "_plugin_close_timer", None)
        callback = getattr(self, "_plugin_close_callback", None)
        try:
            if timer is not None:
                timer.stop()
        except Exception:
            pass
        try:
            if timer is not None and callback is not None:
                _disconnect_timer(timer, callback)
        except Exception:
            pass
        self._plugin_close_timer = None
        self._plugin_close_pending = False
        self._plugin_close_callback = None

    def _defer_ui_actions_on_current_image(self):
        return bool(
            _is_dreambox_image() and not PY3
        )

    def _open_settings_screen(self):
        self._settings_open_pending = False
        self._settings_open_timer = None
        self._settings_open_callback = None
        from .TheWeatherSetting import TheweatherSetting
        _tw_log("[Sevendays] Imported TheweatherSetting, opening screen...")
        self.session.openWithCallback(self._return_from_settings, TheweatherSetting)
        _tw_log("[Sevendays] openWithCallback executed")

    def _schedule_settings_open(self, delay_ms=120):
        if getattr(self, "_settings_open_pending", False):
            return True
        try:
            timer = eTimer()
            self._settings_open_timer = timer
            self._settings_open_pending = True

            def _run():
                self._cleanup_settings_open_timer()
                try:
                    self._open_settings_screen()
                except Exception as e:
                    _tw_log("[Sevendays] Deferred settings open error: %s" % str(e))
                    try:
                        self.session.open(MessageBox, _("Settings screen could not be opened."), MESSAGEBOX_TYPE_INFO)
                    except Exception:
                        pass

            self._settings_open_callback = _run
            _connect_timer(timer, _run)
            _start_timer(timer, int(delay_ms))
            return True
        except Exception as e:
            _tw_log("[Sevendays] Failed to schedule settings open: %s" % str(e))
            self._cleanup_settings_open_timer()
            self._open_settings_screen()
            return True

    def _close_plugin_screen_now(self):
        self._plugin_close_pending = False
        self._plugin_close_timer = None
        self._plugin_close_callback = None
        _close_plugin_safely(self)

    def _schedule_plugin_close(self, delay_ms=120):
        if getattr(self, "_plugin_close_pending", False):
            return True
        try:
            timer = eTimer()
            self._plugin_close_timer = timer
            self._plugin_close_pending = True

            def _run():
                self._cleanup_plugin_close_timer()
                try:
                    self._close_plugin_screen_now()
                except Exception as e:
                    _tw_log("[Sevendays] Deferred plugin close error: %s" % str(e))
                    try:
                        _close_plugin_safely(self)
                    except Exception:
                        pass

            self._plugin_close_callback = _run
            _connect_timer(timer, _run)
            _start_timer(timer, int(delay_ms))
            return True
        except Exception as e:
            _tw_log("[Sevendays] Failed to schedule plugin close: %s" % str(e))
            self._cleanup_plugin_close_timer()
            self._close_plugin_screen_now()
            return True

    def _return_from_locations(self, selected_location=None):
        _tw_log("Returning from Locations screen, refreshing main UI")
        """Refresh display after Location management or selection."""
        try:
            _load_saved_locations()
            target_location = _normalize_location_input(selected_location)
            
            if not target_location:
                target_location = _normalize_location_input(_tw_cfg("weatherlocation", ""))

            if target_location:
                if _open_weather_screen(self.session, target_location, allow_async=True):
                    _close_screen_instance(self)
                    return
            
            _refresh_screen_city_label(self)
            self.updateFrameselect()
        except Exception:
            pass

    def _schedule_post_settings_action(self, callback, delay_ms=450):
        try:
            timer = eTimer()
            self._post_settings_action_timer = timer

            def _run():
                try:
                    timer.stop()
                except Exception:
                    pass
                self._post_settings_action_timer = None
                try:
                    callback()
                except Exception as e:
                    _tw_log("Post-settings action error: %s" % str(e))

            try:
                timer.callback.append(_run)
            except Exception:
                timer.timeout.connect(_run)
            timer.start(int(delay_ms), True)
            return True
        except Exception as e:
            _tw_log("Failed to schedule post-settings action: %s" % str(e))
            try:
                callback()
                return True
            except Exception as cb_err:
                _tw_log("Immediate post-settings action error: %s" % str(cb_err))
                return False

    def _open_city_search_from_settings(self):
        try:
            _open_virtual_keyboard(self.session, self._on_settings_city_search_text, _("Enter cityname e.g. london or cairo"), "")
            return True
        except Exception as e:
            _tw_log("Failed to open city search from settings: %s" % str(e))
            try:
                self.session.open(MessageBox, _("Keyboard screen is not available on this image."), MESSAGEBOX_TYPE_INFO)
            except Exception:
                pass
            return False

    def _on_settings_city_search_text(self, searchterm=None):
        searchterm = _ensure_text(searchterm).strip()
        if not searchterm:
            return
        try:
            from .WeatherProviders import search_locations
            results = search_locations(searchterm) or []
            if not results:
                try:
                    self.session.open(MessageBox, _("No matching cities found. Check spelling."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass
                return
            self.session.openWithCallback(self._return_from_locations, locationsearchresultscreen, searchterm, results)
        except Exception as e:
            _tw_log("Settings city search error: %s" % str(e))

    def _open_manage_favorites_from_settings(self):
        try:
            self.session.openWithCallback(self._return_from_locations, localcityscreen, reopen_via_callback=True)
            return True
        except Exception as e:
            _tw_log("Failed to open favorites from settings: %s" % str(e))
            try:
                self.session.open(MessageBox, _("Favorites screen could not be opened."), MESSAGEBOX_TYPE_INFO)
            except Exception:
                pass
            return False

    def _reload_main_weather_view(self, target_city=None, add_to_favorites=False):
        target_city = _normalize_location_input(target_city)
        if not target_city:
            target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))
        if not target_city:
            target_city = _runtime_local_city()
        if not target_city:
            return False

        try:
            _sync_active_location(target_city, add_to_favorites=bool(add_to_favorites))
        except Exception as e:
            _tw_log("Reload main weather sync error: %s" % str(e))

        loaded = False
        try:
            cache_max_age = _tw_cache_max_age_seconds()
            if cache_max_age > 0:
                loaded = bool(_load_weather_cache(target_city, cache_max_age, False))
            if not loaded:
                weather_loader = _runtime_plugin_value("getLocalWeather")
                if callable(weather_loader):
                    loaded = bool(weather_loader(target_city))
            if not loaded:
                loaded = bool(_load_weather_cache(target_city, None, True))
        except Exception as e:
            _tw_log("Reload main weather load error: %s" % str(e))

        try:
            self.selected = 0
        except Exception:
            pass
        _refresh_screen_city_label(self)
        try:
            self.updateFrameselect()
        except Exception as e:
            _tw_log("Reload main weather refresh error: %s" % str(e))
        return loaded

    def _return_from_settings(self, result=None, *args):
        _tw_log("Returning from Settings screen, checking for updates. Result: %s" % str(result))

        if result == "RESTART_PLUGIN":
            target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))
            _tw_log("[Sevendays] Restart signal received, closing plugin and scheduling delayed re-open for city: %s" % str(target_city))
            try:
                if _schedule_plugin_restart(self.session, target_city, delay_ms=1000):
                    _close_screen_instance(self)
                    return
            except Exception as e:
                _tw_log("[Sevendays] Direct restart scheduling error: %s" % str(e))
            _tw_log("[Sevendays] Falling back to parent restart signaling path")
            _close_screen_instance(self, "RESTART_PLUGIN")
            return

        # Check if settings returned a specific internal action
        action_name = None
        action_payload = None
        if isinstance(result, (tuple, list)) and result:
            action_name = result[0]
            if len(result) > 1:
                action_payload = result[1]
        elif isinstance(result, str) and result.startswith("action:"):
            action_name = result.replace("action:", "")

        if action_name == "refresh_background":
            target_city = _normalize_location_input(action_payload)
            if not target_city:
                try:
                    target_city = _normalize_location_input(getattr(self.session, "_tw_settings_refresh_city", ""))
                except Exception:
                    target_city = ""
            try:
                self.session._tw_settings_refresh_city = ""
            except Exception:
                pass
            if not target_city:
                target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))
            _tw_log("[Sevendays] Dreambox background refresh requested for city: %s" % str(target_city))
            try:
                if target_city and _open_weather_screen(self.session, target_city, allow_async=True):
                    _close_screen_instance(self)
                    return
            except Exception as e:
                _tw_log("Dreambox background re-open error: %s" % str(e))
            try:
                self._refresh_background_pixmap()
            except Exception:
                pass
            try:
                self._reload_main_weather_view(target_city, add_to_favorites=bool(target_city))
            except Exception:
                pass
            return

        if action_name == "reload_weather_screen":
            target_city = _normalize_location_input(action_payload)
            if not target_city:
                target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))
            _tw_log("[Sevendays] Full weather screen reopen requested for city: %s" % str(target_city))
            try:
                if target_city and _open_weather_screen(self.session, target_city, allow_async=True):
                    _close_screen_instance(self)
                    return
            except Exception as e:
                _tw_log("Weather screen reopen error: %s" % str(e))
            try:
                self._reload_main_weather_view(target_city, add_to_favorites=bool(target_city))
            except Exception:
                pass
            return

        try:
            if _is_dreambox_image() and not PY3:
                self._refresh_background_pixmap()
        except Exception:
            pass

        if action_name == "select_location":
            self._schedule_post_settings_action(self._open_city_search_from_settings, delay_ms=500)
            return
        if action_name == "manage_favorites":
            self._schedule_post_settings_action(self._open_manage_favorites_from_settings, delay_ms=500)
            return

        # If a city name was returned directly (as a simple string) or True
        try:
            target_city = None
            if isinstance(result, str) and not result.startswith("action:"):
                target_city = _normalize_location_input(result)

            if not target_city:
                target_city = _normalize_location_input(_tw_cfg("weatherlocation", ""))

            _tw_log("Refreshing weather for city: %s" % str(target_city))
            self._reload_main_weather_view(target_city, add_to_favorites=bool(target_city))
        except Exception as e:
            _tw_log("Error in _return_from_settings: %s" % str(e))
            _refresh_screen_city_label(self)
            self.updateFrameselect()

    def _block_return_action(self):
        self._return_action_block_until = time.time() + 0.4

    def _consume_return_action(self):
        if time.time() <= self._return_action_block_until:
            self._return_action_block_until = 0.0
            return True
        return False

    def left(self):
        self.selected -= 1
        self.updateFrameselect()

    def right(self):
        self.selected += 1
        self.updateFrameselect()

    def exit(self):
        if self._consume_return_action():
            return
        if self._defer_ui_actions_on_current_image():
            self._schedule_plugin_close(delay_ms=120)
            return
        _close_plugin_safely(self)

    def cancel(self):
        if self._consume_return_action():
            return
        if self._defer_ui_actions_on_current_image():
            self._schedule_plugin_close(delay_ms=120)
            return
        _close_plugin_safely(self)

    def keyYellow(self):
        self._switch_favorite_city(-1)

    def keyBlue(self):
        self._switch_favorite_city(1)

    def _switch_favorite_city(self, direction):
        # Guard against rapid double-press: if a switch is already in progress, ignore.
        if getattr(self, "_city_switch_in_progress", False):
            _tw_log("City switch ignored: previous switch still in progress")
            return
        self._city_switch_in_progress = True
        _tw_log("Switching favorite city (direction: %d)" % direction)

        try:
            # Always refresh the saved locations list before navigating
            try:
                _load_saved_locations()
            except Exception as e:
                _tw_log("Failed to load saved locations: %s" % str(e))

            # Build a deduplicated list of valid favorite cities
            favorites = []
            seen_keys = set()
            for saved_location in list(_runtime_saved_locations()):
                normalized_location = _normalize_location_input(saved_location)
                if not normalized_location:
                    continue
                compare_key = _location_compare_key(normalized_location)
                if compare_key in seen_keys:
                    continue
                seen_keys.add(compare_key)
                favorites.append(normalized_location)

            if not favorites:
                _tw_log("Navigation skipped: SavedLocalWeather is empty")
                try:
                    self.session.open(MessageBox, _("No saved cities. Add a city first."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass
                return

            if len(favorites) < 2:
                _tw_log("Navigation skipped: only %d city saved (%s)" % (len(favorites), str(favorites)))
                try:
                    self.session.open(MessageBox, _("Only one favorite city is saved."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass
                return

            # Determine the currently displayed city using a robust key comparison
            current_city = _runtime_local_city()
            if not current_city:
                try:
                    current_city = _normalize_location_input(_resolve_start_location())
                except Exception:
                    current_city = ""
            current_key = _location_compare_key(current_city) if current_city else ""

            current_index = -1
            for i, city in enumerate(favorites):
                if _location_compare_key(city) == current_key:
                    current_index = i
                    break
            _tw_log("Current city: %s, index: %d in favorites list of %d" % (
                str(current_city), current_index, len(favorites)))

            if current_index == -1:
                # Current city not found — pick edge city based on direction
                _tw_log("Current city not found in favorites, picking edge city based on direction")
                current_index = 0 if direction > 0 else len(favorites) - 1
                new_index = current_index
            else:
                new_index = (current_index + direction) % len(favorites)

            new_city = favorites[new_index]
            new_city_key = _location_compare_key(new_city)

            _tw_log("Switching to: %s (index %d)" % (str(new_city), new_index))

            if new_city_key == current_key:
                _tw_log("City switch skipped: new city is same as current (%s)" % str(new_city))
                return

            # ----------------------------------------------------------------
            # PHASE 1 — Try cache first (disk read only, instant, never blocks).
            # _load_weather_cache() reads a local JSON file — no network call.
            # Cache hit → sync open new sevendays → THEN close current.
            # No race condition because both calls complete before returning.
            # ----------------------------------------------------------------
            cache_loaded = False
            try:
                cache_max_age = _tw_cache_max_age_seconds()
                if cache_max_age > 0:
                    cache_loaded = bool(_load_weather_cache(new_city, cache_max_age, False))
                if not cache_loaded:
                    # Accept stale cache too — still instant and no network
                    cache_loaded = bool(_load_weather_cache(new_city, None, True))
            except Exception as cache_err:
                _tw_log("Cache pre-load error: %s" % str(cache_err))
                cache_loaded = False

            if cache_loaded:
                _tw_log("Cache hit for %s — instant sync switch" % str(new_city))
                _sync_active_location(new_city, add_to_favorites=True)
                try:
                    from .plugin import _open_sevendays_screen as _open_sd
                    if _open_sd(self.session):
                        _close_screen_instance(self)
                        return
                except Exception as sd_err:
                    _tw_log("Sync sevendays open error: %s" % str(sd_err))
                # Fallback: refresh in-place if new screen open failed
                try:
                    self.selected = 0
                    _refresh_screen_city_label(self)
                    self.updateFrameselect()
                except Exception:
                    pass
                return

            # ----------------------------------------------------------------
            # PHASE 2 — No cache: fetch from network in a BACKGROUND THREAD.
            # The UI thread is NEVER blocked — screen stays fully responsive.
            # The current screen stays open while loading; when done it is
            # refreshed in-place via updateFrameselect() — no open/close race.
            # ----------------------------------------------------------------
            _tw_log("No cache for %s — starting background fetch" % str(new_city))
            _sync_active_location(new_city, add_to_favorites=True)
            # Show the new city name immediately so the switch feels responsive
            try:
                _refresh_screen_city_label(self)
            except Exception:
                pass

            fetch_state = {"done": False, "success": False}
            poll_timer_ref = [None]

            def _bg_fetch():
                # Runs in a background thread — safe to do network I/O here
                try:
                    weather_loader = _runtime_plugin_value("getLocalWeather")
                    if callable(weather_loader):
                        fetch_state["success"] = bool(weather_loader(new_city))
                    if not fetch_state["success"]:
                        fetch_state["success"] = bool(_load_weather_cache(new_city, None, True))
                except Exception as fetch_err:
                    _tw_log("Background fetch error: %s" % str(fetch_err))
                    fetch_state["success"] = False
                finally:
                    fetch_state["done"] = True

            def _poll_result():
                # Runs on the main UI thread via eTimer — safe to touch widgets
                if not fetch_state["done"]:
                    # Still loading — check again in 300 ms
                    try:
                        _start_timer(poll_timer_ref[0], 300)
                    except Exception:
                        pass
                    return
                # Fetch complete — stop the polling timer
                try:
                    t = poll_timer_ref[0]
                    if t is not None:
                        t.stop()
                        _disconnect_timer(t, _poll_result)
                        poll_timer_ref[0] = None
                except Exception:
                    pass
                # Refresh the sevendays screen in-place with the new city data
                if fetch_state["success"]:
                    try:
                        self.selected = 0
                        _refresh_screen_city_label(self)
                        self.updateFrameselect()
                        _tw_log("In-place refresh done for %s" % str(new_city))
                    except Exception as refresh_err:
                        _tw_log("In-place refresh error: %s" % str(refresh_err))
                else:
                    _tw_log("Background fetch failed for %s — display unchanged" % str(new_city))
                # Clear the switch guard so next press is accepted
                self._city_switch_in_progress = False

            try:
                t = eTimer()
                poll_timer_ref[0] = t
                _connect_timer(t, _poll_result)
                _start_background_thread(_bg_fetch)
                _start_timer(t, 300)
                # Guard is cleared by _poll_result — return here without clearing it
                return
            except Exception as timer_err:
                _tw_log("Poll timer setup error: %s" % str(timer_err))
                # Fallback: try a direct in-place reload (may briefly block on old images)
                try:
                    self._reload_main_weather_view(new_city, add_to_favorites=True)
                except Exception:
                    pass

        except Exception as e:
            _tw_log("_switch_favorite_city error: %s" % str(e))
        finally:
            # Clear the guard. The async polling path returns early above so this
            # finally block only runs for the sync paths and error cases.
            self._city_switch_in_progress = False

    def _start_auto_update_timer(self):
        _start_auto_update_timer_for_screen(self)

    def _stop_auto_update_timer(self):
        _stop_auto_update_timer_for_screen(self)

    def _on_auto_update_timer(self):
        _handle_auto_update_timer_for_screen(self, True)

    def fourteendays(self):
        try:
            self.session.openWithCallback(self._return_from_fourteen, _forecast_days_screen_class(weatherData))
        except Exception as e:
            print("[TheWeather] fourteendays error: " + str(e))

    def _return_from_fourteen(self, *args):
        try:
            _refresh_screen_city_label(self)
            self.updateFrameselect()
        except Exception:
            pass

class fourteen(Screen):
    def __init__(self, session):
        bind_runtime()
        Screen.__init__(self, session)
        AddNewScreen(self)
        self._screen_closed = False
        global weatherData
        dataDays = list(weatherData.get("days") or [])
        visible_days = _forecast_screen_day_count(dataDays, 16, weatherData)
        is_fourteen_screen = _forecast_provider_name(weatherData) == "buienradar"
        screen_title = "14 Days Forecast" if is_fourteen_screen else "16 Days Forecast"
        screen_name = "FourteenDays" if is_fourteen_screen else "SexteenDays"
        if _use_fullhd_layout():
            dayinfoblok = ""
            x_offset = _forecast_day_column_offset(True, visible_days)
            temp_unit_layout = _forecast_graph_temp_unit_layout(True)
            lines_size = {'-1.png': [122, 15], '-2.png': [122, 30], '-3.png': [122, 45], '-4.png': [122, 60],
                          '-5.png': [122, 75], '-6.png': [122, 90], '-7.png': [122, 105], '-8.png': [122, 120],
                          '-9.png': [122, 135], '-10.png': [122, 150], '-11.png': [122, 165], '-12.png': [122, 180],
                          '-13.png': [122, 195], '-14.png': [122, 210], '-15.png': [122, 225], '0.png': [122, 5],
                          '1.png': [122, 15], '2.png': [122, 30], '3.png': [122, 45], '4.png': [122, 60],
                          '5.png': [122, 75], '6.png': [122, 90], '7.png': [122, 105], '8.png': [122, 120],
                          '9.png': [122, 135], '10.png': [122, 150], '11.png': [122, 165], '12.png': [122, 180],
                          '13.png': [122, 195], '14.png': [122, 210], '15.png': [122, 225], 'b-1.png': [122, 15],
                          'b-2.png': [122, 30], 'b-3.png': [122, 45], 'b-4.png': [122, 60], 'b-5.png': [122, 75],
                          'b-6.png': [122, 90], 'b-7.png': [122, 105], 'b-8.png': [122, 120], 'b-9.png': [122, 135],
                          'b-10.png': [122, 150], 'b-11.png': [122, 165], 'b-12.png': [122, 180], 'b-13.png': [122, 195],
                          'b-14.png': [122, 210], 'b-15.png': [122, 225], 'b0.png': [122, 5], 'b1.png': [122, 15],
                          'b2.png': [122, 30], 'b3.png': [122, 45], 'b4.png': [122, 60], 'b5.png': [122, 75],
                          'b6.png': [122, 90], 'b7.png': [122, 105], 'b8.png': [122, 120], 'b9.png': [122, 135],
                          'b10.png': [122, 150], 'b11.png': [122, 165], 'b12.png': [122, 180], 'b13.png': [122, 195],
                          'b14.png': [122, 210], 'b15.png': [122, 225]}
            maxheightshift = _get_temperature_shift(dataDays, 1200, 15, 12, 660)
            for day in range(0, visible_days):
                dagenbefore = dataDays[day]
                plot = _get_temperature_line_layout(dataDays, day, 1200, 15, maxheightshift, 80, 1000)
                curtemp = plot["max_temp"]
                tempdiff = plot["max_diff"]
                lineheight = plot["max_lineheight"]
                yposline = plot["max_ypos"]
                # shiftstart = 130
                rainamount = int(float(dagenbefore["precipitationmm"]) * 2)
                if 1 < rainamount < 10:
                    rainamount = 10
                elif rainamount > 100:
                    rainamount = 100
                curtempcold = plot["min_temp"]
                tempdiffcold = plot["min_diff"]
                lineheightcold = plot["min_lineheight"]
                yposlinecold = plot["min_ypos"]
                if day < (visible_days - 1):
                    linesize = """size="%s,%s\"""" % (lines_size[(str(tempdiff) + ".png")][0], lines_size[(str(tempdiff) + ".png")][1])
                    linesizeb = """size="%s,%s\"""" % (lines_size["b" + (str(tempdiffcold) + ".png")][0], lines_size[(str(tempdiffcold) + ".png")][1])
                    dayinfoblok += """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/""" + str(tempdiff) + """.png" position=\"""" + str((40 + (113 * day)) + 59 + x_offset) + """,""" + str(yposline) + """\" """ + linesize + """ zPosition="10" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/b""" + str(tempdiffcold) + """.png" position=\"""" + str((40 + (113 * day)) + 59 + x_offset) + """,""" + str(yposlinecold) + """\" """ + linesizeb + """ zPosition="10" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/bar.png" position=\"""" + str((40 + (113 * day)) + 120 + x_offset) + """,140" size="10,900" zPosition="10" transparent="0" alphatest="blend"/>
                    """
                closedrainbar = int(round(rainamount // 3) * 3)
                dayinfoblok += """
                    <widget render="Label" source="rainfall""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,560" size="113,54" valign="center" halign="center" zPosition="20" font="Regular;24" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="windspeed""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,435" size="113,54" valign="center" halign="center" zPosition="20" font="Regular;24" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="rainfallUnit""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,560" size="113,54" valign="center" halign="center" zPosition="20" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rain_""" + str(closedrainbar) + """.png" position=\"""" + str((38 + (113 * day)) + 45 + x_offset) + """,""" + str((562) - closedrainbar) + """\" size="60,""" + str(closedrainbar) + """\" zPosition="12" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rainstond.png" position=\"""" + str((20 + (113 * day)) + 45 + x_offset) + """,""" + str((560)) + """\" size="70,10" zPosition="15" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/rdot.png" position=\"""" + str(((40 + (113 * day)) + 59) - 12 + x_offset) + """,""" + str((plot["max_dot_y"] - 12)) + """\" size="25,25" zPosition="10" transparent="0" alphatest="blend"/>
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str((40 + (113 * day)) + 28 + x_offset) + """,267" size="72,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/iconhd/""" + str(dagenbefore["iconcode"]) + """.png" zPosition="1" alphatest="blend"/>

                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/lines/bdot.png" position=\"""" + str(((40 + (113 * day)) + 59) - 12 + x_offset) + """,""" + str((plot["min_dot_y"] - 12)) + """\" size="25,25" zPosition="10" transparent="0" alphatest="blend"/>
                    <widget name="wind""" + str(day) + """" position=\"""" + str((40 + (113 * day)) + 36 + x_offset) + """,375" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windbig/""" + _tw_get_safe_wind_icon(iconpath, dagenbefore["winddirection"], "windbig") + """.png" zPosition="2" transparent="1" alphatest="blend"/>
                    <widget render="Label" source="dayOfWeek""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,155" size="113,54" valign="center" halign="center" zPosition="15" font="Regular;45" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dateOfWeek""" + str(day) + """" position=\"""" + str((47 + (113 * day)) + x_offset) + """,195" size="113,54" valign="center" halign="center" zPosition="15" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMax""" + str(day) + """" position=\"""" + str(((40 + (113 * day)) - 15) + 59 + x_offset) + """,""" + str(((yposline - 45) + lineheight)) + """\" size="62,54" zPosition="15" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMaxUnit""" + str(day) + """" position=\"""" + str(((40 + (113 * day)) - 15) + 98 + temp_unit_layout["x_shift"] + x_offset) + """,""" + str(((yposline - 45) + lineheight) + temp_unit_layout["y_shift"]) + """\" size=\"""" + str(temp_unit_layout["width"]) + """,""" + str(temp_unit_layout["height"]) + """\" zPosition="15" font="Regular;""" + str(temp_unit_layout["font"]) + """" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>

                    <widget render="Label" source="lineTempMin""" + str(day) + """" position=\"""" + str(((40 + (113 * day)) - 15) + 59 + x_offset) + """,""" + str((yposlinecold + 15) + lineheightcold) + """\" size="62,54" zPosition="15" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMinUnit""" + str(day) + """" position=\"""" + str(((40 + (113 * day)) - 15) + 98 + temp_unit_layout["x_shift"] + x_offset) + """,""" + str(((yposlinecold + 15) + lineheightcold) + temp_unit_layout["y_shift"]) + """\" size=\"""" + str(temp_unit_layout["width"]) + """,""" + str(temp_unit_layout["height"]) + """\" zPosition="15" font="Regular;""" + str(temp_unit_layout["font"]) + """" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    """
            skin = """
                    <screen name=\"""" + screen_name + """\" position="center,center" size="1920,1080" title=\"""" + screen_title + """\">
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/bgbluhd.png" position="center,center" size="1920,1080" zPosition="0" alphatest="blend"/>
                    <widget source="global.CurrentTime" render="Label" position="1608,30" size="250,50" transparent="1" zPosition="1" font="Regular;38" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="1360,76" size="500,38" transparent="1" zPosition="1" font="Regular;26" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget render="Label" source="city1" position="540,34" size="840,72" zPosition="3" valign="center" halign="center" font="Regular;54" transparent="1" />
                    """ + dayinfoblok + """
                    </screen>"""

            for day in range(0, visible_days):
                dagenbefore = dataDays[day]
                plot = _get_temperature_line_layout(dataDays, day, 1200, 15, maxheightshift, 80, 1000)
                self["windspeed" + str(day)] = StaticText()
                _set_component_text(self["windspeed" + str(day)], _format_speed_text(dagenbefore["windspeed"]))
                self["rainfall" + str(day)] = StaticText()
                _set_component_text(self["rainfall" + str(day)], str(dagenbefore["precipitationmm"]) + " mm")
                self["rainfallUnit" + str(day)] = StaticText()
                _set_component_text(self["rainfallUnit" + str(day)], "")
                day_name, day_date = _get_day_label_parts(dagenbefore, "%d-%m")
                self["lineTempMax" + str(day)] = StaticText()
                _set_component_text(self["lineTempMax" + str(day)], '{:>3}'.format(_format_temperature_text(_tw_convert_temp(_get_mapping_value(dagenbefore, "maxtemperature")), 0, "NA")))
                self["lineTempMaxUnit" + str(day)] = StaticText()
                _set_component_text(self["lineTempMaxUnit" + str(day)], _tw_temp_suffix())
                self["lineTempMin" + str(day)] = StaticText()
                _set_component_text(self["lineTempMin" + str(day)], '{:>3}'.format(_format_temperature_text(_tw_convert_temp(_get_mapping_value(dagenbefore, "mintemperature")), 0, "NA")))
                self["lineTempMinUnit" + str(day)] = StaticText()
                _set_component_text(self["lineTempMinUnit" + str(day)], _tw_temp_suffix())

                self["bigWeerIcon1" + str(day)] = Pixmap()
                self["wind" + str(day)] = Pixmap()
                self["city1"] = StaticText()
                _set_component_text(self["city1"], _runtime_city_display_name())
                self["dayOfWeek" + str(day)] = StaticText()
                _set_component_text(self["dayOfWeek" + str(day)], str(day_name).upper())
                self["dateOfWeek" + str(day)] = StaticText()
                _set_component_text(self["dateOfWeek" + str(day)], str(day_date))
        else:
            dayinfoblok = ""
            x_offset = _forecast_day_column_offset(False, visible_days)
            temp_unit_layout = _forecast_graph_temp_unit_layout(False)
            lines_size = {'-1.png': [82, 10], '-2.png': [82, 20], '-3.png': [82, 30], '-4.png': [82, 40],
                          '-5.png': [82, 50], '-6.png': [82, 60], '-7.png': [82, 70], '-8.png': [82, 80],
                          '-9.png': [82, 90], '-10.png': [82, 100], '-11.png': [82, 110], '-12.png': [82, 120],
                          '-13.png': [82, 130], '-14.png': [82, 140], '-15.png': [82, 150], '0.png': [82, 3],
                          '1.png': [82, 10], '2.png': [82, 20], '3.png': [82, 30], '4.png': [82, 40],
                          '5.png': [82, 50], '6.png': [82, 60], '7.png': [82, 70], '8.png': [82, 80],
                          '9.png': [82, 90], '10.png': [82, 100], '11.png': [82, 110], '12.png': [82, 120],
                          '13.png': [82, 130], '14.png': [82, 140], '15.png': [82, 150], 'b-1.png': [82, 10],
                          'b-2.png': [82, 20], 'b-3.png': [82, 30], 'b-4.png': [82, 40], 'b-5.png': [82, 50],
                          'b-6.png': [82, 60], 'b-7.png': [82, 70], 'b-8.png': [82, 80], 'b-9.png': [82, 90],
                          'b-10.png': [82, 110], 'b-11.png': [82, 110], 'b-12.png': [82, 120], 'b-13.png': [82, 130],
                          'b-14.png': [82, 140], 'b-15.png': [82, 150], 'b0.png': [82, 3], 'b1.png': [82, 10],
                          'b2.png': [82, 20], 'b3.png': [82, 30], 'b4.png': [82, 40], 'b5.png': [82, 50],
                          'b6.png': [82, 60], 'b7.png': [82, 70], 'b8.png': [82, 80], 'b9.png': [82, 90],
                          'b10.png': [82, 100], 'b11.png': [82, 110], 'b12.png': [82, 120], 'b13.png': [82, 130],
                          'b14.png': [82, 140], 'b15.png': [82, 150]}
            maxheightshift = _get_temperature_shift(dataDays, 800, 10, 12, 460)
            for day in range(0, visible_days):
                dagenbefore = dataDays[day]
                plot = _get_temperature_line_layout(dataDays, day, 800, 10, maxheightshift, 52, 670)
                curtemp = plot["max_temp"]
                tempdiff = plot["max_diff"]
                lineheight = plot["max_lineheight"]
                yposline = plot["max_ypos"]
                rainamount = int(float(dagenbefore["precipitationmm"]) * 2)
                if 1 < rainamount < 10:
                    rainamount = 10
                elif rainamount > 100:
                    rainamount = 100
                curtempcold = plot["min_temp"]
                tempdiffcold = plot["min_diff"]
                lineheightcold = plot["min_lineheight"]
                yposlinecold = plot["min_ypos"]
                if day < (visible_days - 1):
                    linesize = """size="%s,%s\"""" % (lines_size[(str(tempdiff) + ".png")][0], lines_size[(str(tempdiff) + ".png")][1])
                    linesizeb = """size="%s,%s\"""" % (lines_size["b" + (str(tempdiffcold) + ".png")][0], lines_size[(str(tempdiffcold) + ".png")][1])
                    dayinfoblok += """
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/""" + str(tempdiff) + """.png" position=\"""" + str((30 + (74 * day)) + 39 + x_offset) + """,""" + str(yposline) + """\" """ + linesize + """ zPosition="10" transparent="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/b""" + str(tempdiffcold) + """.png" position=\"""" + str((30 + (74 * day)) + 39 + x_offset) + """,""" + str(yposlinecold) + """\" """ + linesizeb + """ zPosition="10" transparent="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/bar.png" position=\"""" + str((30 + (74 * day)) + 80 + x_offset) + """,93" size="3,590" zPosition="10" transparent="0" alphatest="blend"/>
                    """

                closedrainbar = int(round(rainamount // 3) * 3)
                dayinfoblok += """
                    <widget render="Label" source="rainfall""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,375" size="74,36" valign="center" halign="center" zPosition="20" font="Regular;16" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="windspeed""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,290" size="74,36" valign="center" halign="center" zPosition="20" font="Regular;19" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="rainfallUnit""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,375" size="74,36" valign="center" halign="center" zPosition="20" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rain_""" + str(closedrainbar) + """.png" position=\"""" + str((24 + (74 * day)) + 30 + x_offset) + """,""" + str((380) - closedrainbar) + """\" size="40,""" + str(closedrainbar) + """\" zPosition="12" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rainstond.png" position=\"""" + str((8 + (74 * day)) + 30 + x_offset) + """,""" + str((375)) + """\" size="64,7" zPosition="15" transparent="0" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/rdot.png" position=\"""" + str(((31 + (74 * day)) + 39) - 8 + x_offset) + """,""" + str((plot["max_dot_y"] - 8)) + """\" size="18,18" zPosition="10" transparent="0" alphatest="blend"/>
                    <widget name="bigWeerIcon1""" + str(day) + """" position=\"""" + str((31 + (74 * day)) + 19 + x_offset) + """,178" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/icon/""" + str(dagenbefore["iconcode"]) + """.png" zPosition="1" alphatest="blend"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/linessd/bdot.png" position=\"""" + str(((31 + (74 * day)) + 39) - 8 + x_offset) + """,""" + str((plot["min_dot_y"] - 8)) + """\" size="18,18" zPosition="10" transparent="0" alphatest="blend"/>
                    <widget name="wind""" + str(day) + """" position=\"""" + str((24 + (74 * day)) + 27 + x_offset) + """,250" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/windhd/""" + _tw_get_safe_wind_icon(iconpath, dagenbefore["winddirection"], "windhd") + """.png" zPosition="2" transparent="1" alphatest="blend"/>
                    <widget render="Label" source="dayOfWeek""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,103" size="74,36" valign="center" halign="center" zPosition="15" font="Regular;30" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="dateOfWeek""" + str(day) + """" position=\"""" + str((36 + (74 * day)) + x_offset) + """,130" size="74,36" valign="center" halign="center" zPosition="15" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMax""" + str(day) + """" position=\"""" + str(((47 + (74 * day)) - 10) + 26 + x_offset) + """,""" + str(((yposline - 35) + lineheight)) + """\" size="38,36" zPosition="15" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMaxUnit""" + str(day) + """" position=\"""" + str(((47 + (74 * day)) - 10) + 52 + temp_unit_layout["x_shift"] + x_offset) + """,""" + str(((yposline - 35) + lineheight) + temp_unit_layout["y_shift"]) + """\" size=\"""" + str(temp_unit_layout["width"]) + """,""" + str(temp_unit_layout["height"]) + """\" zPosition="15" font="Regular;""" + str(temp_unit_layout["font"]) + """" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMin""" + str(day) + """" position=\"""" + str(((50 + (74 * day)) - 10) + 26 + x_offset) + """,""" + str((yposlinecold + 10) + lineheightcold) + """\" size="38,36" zPosition="15" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget render="Label" source="lineTempMinUnit""" + str(day) + """" position=\"""" + str(((50 + (74 * day)) - 10) + 52 + temp_unit_layout["x_shift"] + x_offset) + """,""" + str(((yposlinecold + 10) + lineheightcold) + temp_unit_layout["y_shift"]) + """\" size=\"""" + str(temp_unit_layout["width"]) + """,""" + str(temp_unit_layout["height"]) + """\" zPosition="15" font="Regular;""" + str(temp_unit_layout["font"]) + """" foregroundColor="#00ff00" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    """
            skin = """
                    <screen name=\"""" + screen_name + """\" position="center,center" size="1280,720" title=\"""" + screen_title + """\">
                    <ePixmap pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=False) + """\" position="center,center" size="1280,720" zPosition="0" alphatest="blend"/>
                    <widget source="global.CurrentTime" render="Label" position="1091,12" size="150,55" transparent="1" zPosition="1" font="Regular;24" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="941,32" size="300,55" transparent="1" zPosition="1" font="Regular;16" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget render="Label" source="city1" position="406,30" size="470,43" zPosition="3" valign="center" halign="center" font="Regular;32" transparent="1" />
                    """ + dayinfoblok + """
                    </screen>"""
            for day in range(0, visible_days):
                dagenbefore = dataDays[day]
                plot = _get_temperature_line_layout(dataDays, day, 800, 10, maxheightshift, 52, 670)
                self["windspeed" + str(day)] = StaticText()
                _set_component_text(self["windspeed" + str(day)], _format_speed_text(dagenbefore["windspeed"]))
                self["rainfall" + str(day)] = StaticText()
                _set_component_text(self["rainfall" + str(day)], str(dagenbefore["precipitationmm"]) + " mm")
                self["rainfallUnit" + str(day)] = StaticText()
                _set_component_text(self["rainfallUnit" + str(day)], "")
                day_name, day_date = _get_day_label_parts(dagenbefore, "%d-%m")
                self["lineTempMax" + str(day)] = StaticText()
                _set_component_text(self["lineTempMax" + str(day)], '{:>3}'.format(_format_temperature_text(_tw_convert_temp(_get_mapping_value(dagenbefore, "maxtemperature")), 0, "NA")))
                self["lineTempMaxUnit" + str(day)] = StaticText()
                _set_component_text(self["lineTempMaxUnit" + str(day)], _tw_temp_suffix())
                self["lineTempMin" + str(day)] = StaticText()
                _set_component_text(self["lineTempMin" + str(day)], '{:>3}'.format(_format_temperature_text(_tw_convert_temp(_get_mapping_value(dagenbefore, "mintemperature")), 0, "NA")))
                self["lineTempMinUnit" + str(day)] = StaticText()
                _set_component_text(self["lineTempMinUnit" + str(day)], _tw_temp_suffix())

                self["bigWeerIcon1" + str(day)] = Pixmap()
                self["wind" + str(day)] = Pixmap()
                self["city1"] = StaticText()
                _set_component_text(self["city1"], _runtime_city_display_name())
                self["dayOfWeek" + str(day)] = StaticText()
                _set_component_text(self["dayOfWeek" + str(day)], str(day_name).upper())
                self["dateOfWeek" + str(day)] = StaticText()
                _set_component_text(self["dateOfWeek" + str(day)], str(day_date))
        self.session = session
        self.skin = _apply_skin_path(skin)
        self["myActionMap"] = ActionMap(["SetupActions"], {"ok": self.dayseven, "cancel": self.cancel, "red": self.exit}, -1)
        self.onClose.append(self._cleanup)

    def _cleanup(self):
        self._screen_closed = True

    def dayseven(self):
        if self._screen_closed:
            return
        self._screen_closed = True
        _close_screen_instance(self)

    def exit(self):
        if self._screen_closed:
            return
        self._screen_closed = True
        _close_screen_instance(self)

    def cancel(self):
        if self._screen_closed:
            return
        self._screen_closed = True
        _close_screen_instance(self)

class FourteenDays(fourteen):
    pass


class SixteenDays(fourteen):
    pass


# Keep the legacy class name for compatibility with older skins/imports.
SexteenDays = SixteenDays

class weatherloading(Screen):
    def __init__(self, session, location_name, cache_max_age=0, callback=None):
        bind_runtime()
        self.cache_max_age = int(cache_max_age or 0)
        self.parent_callback = callback
        if _use_fullhd_layout():
            skin = """
                    <screen name="weatherloading" position="center,center" size="1920,1080" title="Weather Loading">
                    <ePixmap pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=True) + """\" position="center,center" size="1920,1080" zPosition="0" alphatest="blend"/>
                    <widget name="title" position="0,200" size="1920,72" zPosition="2" valign="center" halign="center" font="Regular;56" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="location" position="0,380" size="1920,68" zPosition="2" valign="center" halign="center" font="Regular;52" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="status" position="260,500" size="1400,62" zPosition="2" valign="center" halign="center" font="Regular;42" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/buttons/red34.png" position="852,686" size="34,34" alphatest="blend"/>
                    <widget name="key_red" position="900,678" size="220,42" zPosition="2" font="Regular;38" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""
        else:
            skin = """
                    <screen name="weatherloading" position="center,center" size="1280,720" title="Weather Loading">
                    <ePixmap pixmap=\"""" + _background_skin_asset_path(_tw_cfg("background", "1"), use_fullhd=False) + """\" position="center,center" size="1280,720" zPosition="0" alphatest="blend"/>
                    <widget name="title" position="0,140" size="1280,48" zPosition="2" valign="center" halign="center" font="Regular;36" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="location" position="0,255" size="1280,44" zPosition="2" valign="center" halign="center" font="Regular;34" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="status" position="160,340" size="960,40" zPosition="2" valign="center" halign="center" font="Regular;28" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/buttons/red26.png" position="560,474" size="26,26" alphatest="blend"/>
                    <widget name="key_red" position="600,469" size="160,30" zPosition="2" font="Regular;26" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""

        self.session = session
        self.location_name = _normalize_location_input(location_name)
        self._fetch_started = False
        self._fetch_done = False
        self._fetch_success = False
        self._closed = False
        self._error_text = ""
        self.skin = _apply_skin_path(skin)
        Screen.__init__(self, session)
        AddNewScreen(self)
        display_location = _location_label(self.location_name)
        self["title"] = Label(_ui_text(_("Weather forecast")))
        self["location"] = Label(_ui_text(display_location))
        self["status"] = Label(_ui_text(_("Connecting to weather server...")))
        self["key_red"] = Label(_ui_text(_("Cancel")))
        self["actions"] = ActionMap(["WizardActions", "ColorActions"], {"back": self.cancel, "red": self.cancel}, -1)
        self._poll_timer = eTimer()
        _connect_timer(self._poll_timer, self._poll_worker)
        self.onLayoutFinish.append(self._start_fetch)
        self.onClose.append(self._cleanup)

    def _start_fetch(self):
        if self._fetch_started or self._closed:
            return
        self._fetch_started = True
        _tw_log("weatherloading start fetch for %s" % str(self.location_name))
        _set_component_text(self["status"], _("Loading weather data..."))
        if _tw_auto_update_minutes() <= 0:
            _tw_log("weatherloading using direct fetch: automatic update disabled")
            self._worker_run()
            self._poll_worker()
            return
        _start_background_thread(self._worker_run)
        _start_timer(self._poll_timer, 200)

    def _worker_run(self):
        try:
            if self.cache_max_age > 0 and _load_weather_cache(self.location_name, self.cache_max_age, False):
                self._fetch_success = True
                _tw_log("weatherloading opened from valid cache window")
            else:
                self._fetch_success = getLocalWeather(self.location_name)
                if not self._fetch_success and _load_weather_cache(self.location_name, None, True):
                    self._fetch_success = True
        except Exception as e:
            self._error_text = str(e)
            self._fetch_success = False
        _tw_log("weatherloading worker done success=%s error=%s" % (str(self._fetch_success), str(self._error_text)))
        self._fetch_done = True

    def _poll_worker(self):
        if self._closed:
            return
        if not self._fetch_done:
            _start_timer(self._poll_timer, 200)
            return
        _tw_log("weatherloading poll done success=%s" % str(self._fetch_success))
        if self._fetch_success:
            try:
                if self.parent_callback:
                    self.session.openWithCallback(self.parent_callback, sevendays)
                else:
                    self.session.open(sevendays)
                _close_screen_instance(self)
            except Exception as e:
                self._error_text = str(e)
                _tw_log("weatherloading open sevendays error: %s" % str(e))
                try:
                    _close_screen_instance(self)
                except Exception:
                    pass
                try:
                    self.session.open(localcityscreen)
                except Exception:
                    pass
            return
        message = _("Download error: No response, try again")
        if self._error_text:
            print("[TheWeather] loader error: " + self._error_text)
        try:
            _close_screen_instance(self)
        except Exception:
            pass
        try:
            self.session.open(localcityscreen)
        except Exception:
            pass

    def _cleanup(self):
        self._closed = True
        try:
            self._poll_timer.stop()
        except Exception:
            pass
        _disconnect_timer(self._poll_timer, self._poll_worker)

    def cancel(self):
        if self._closed:
            return
        self._closed = True
        _close_screen_instance(self)

class locationsearchresultscreen(Screen):

    def __init__(self, session, searchterm, search_results):
        bind_runtime()
        if _use_fullhd_layout():
            skin = """
                    <screen name="locationSearchResultScreen" position="center,center" size="1920,1080" title="Weather Plugin">
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline3.png" position="0,112" size="1920,3" zPosition="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline3.png" position="0,1010" size="1920,3" zPosition="1"/>
                    <widget name="title" position="120,36" size="800,52" zPosition="2" font="Regular;40" transparent="1" halign="left" valign="center" />
                    <widget name="searchterm" position="120,112" size="1680,56" zPosition="2" font="Regular;36" transparent="1" halign="left" valign="center" />
                    <widget name="resultinfo" position="120,168" size="1680,42" zPosition="2" font="Regular;28" transparent="1" halign="left" valign="center" />
                    <widget name="list" position="120,230" size="1680,700" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/list/list97563.png"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/red34.png" position="192,1022" size="34,34" alphatest="blend"/>
                    <widget name="key_red" position="242,1015" size="370,42" zPosition="1" font="Regular;40" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/green34.png" position="628,1022" size="34,34" alphatest="blend"/>
                    <widget name="key_green" position="678,1015" size="370,42" zPosition="1" font="Regular;40" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""
        else:
            skin = """
                    <screen name="locationSearchResultScreen" position="center,center" size="1280,720" title="Weather Plugin">
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline2.png" position="0,88" size="1280,2" zPosition="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline2.png" position="0,650" size="1280,2" zPosition="1"/>
                    <widget name="title" position="60,22" size="560,34" zPosition="2" font="Regular;28" transparent="1" halign="left" valign="center" />
                    <widget name="searchterm" position="60,86" size="1160,34" zPosition="2" font="Regular;24" transparent="1" halign="left" valign="center" />
                    <widget name="resultinfo" position="60,118" size="1160,28" zPosition="2" font="Regular;18" transparent="1" halign="left" valign="center" />
                    <widget name="list" position="60,162" size="1160,430" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/Images/list/list65043.png"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/red26.png" position="145,663" size="26,26" alphatest="blend"/>
                    <widget name="key_red" position="185,663" size="220,28" zPosition="1" font="Regular;24" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/green26.png" position="420,663" size="26,26" alphatest="blend"/>
                    <widget name="key_green" position="460,663" size="220,28" zPosition="1" font="Regular;24" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""

        self.session = session
        self.searchterm = _ensure_text(searchterm).strip()
        self.search_results = list(search_results or [])
        self.res = []
        self._screen_closed = False
        self._result_sent = False
        self.skin = _apply_skin_path(skin)
        Screen.__init__(self, session)
        AddNewScreen(self)
        self["title"] = Label(_ui_text(_("Choose city")))
        self["searchterm"] = Label(_ui_text(self.searchterm))
        self["resultinfo"] = Label(_ui_text(_("Select the correct city from the list")))
        self["key_red"] = Label(_ui_text(_("Cancel")))
        self["key_green"] = Label(_ui_text(_("Select")))

        for result in self.search_results:
            display_label = _ensure_text(result.get("label", "")).strip()
            if display_label:
                self.res.append(_build_location_search_row(result, _use_fullhd_layout()))

        self["list"] = MenuList(self.res, True, eListboxPythonMultiContent)
        if _use_fullhd_layout():
            self["list"].l.setItemHeight(68)
            self["list"].l.setFont(0, _runtime_font(40))
            self["list"].l.setFont(1, _runtime_font(34))
        else:
            self["list"].l.setItemHeight(42)
            self["list"].l.setFont(0, _runtime_font(26))
            self["list"].l.setFont(1, _runtime_font(22))
        self["list"].show()
        self["actions"] = ActionMap(["WizardActions", "MenuActions", "ShortcutActions", "ColorActions"], {"ok": self.select, "back": self.cancel, "red": self.cancel, "green": self.select}, -1)
        self.onClose.append(self._cleanup)

    def _cleanup(self):
        self._screen_closed = True

    def _close_with_result(self, result=None):
        if self._screen_closed or self._result_sent:
            return
        self._result_sent = True
        try:
            self._screen_closed = True
            _close_screen_instance(self, result)
        except Exception as e:
            print("[TheWeather] city result close error: " + str(e))

    def select(self):
        if self._screen_closed:
            return
        if not self.res:
            self._close_with_result(None)
            return
        try:
            index = self["list"].getSelectedIndex()
            selected_data = self.res[index][0]
        except Exception:
            selected_data = None
        if isinstance(selected_data, dict):
            self._close_with_result(selected_data.get("value"))
            return
        self._close_with_result(selected_data)

    def cancel(self):
        self._close_with_result(None)

class localcityscreen(Screen):

    def __init__(self, session, return_selection=False, reopen_via_callback=False):
        bind_runtime()
        global SavedLocalWeather
        vti_font_adjust = 2 if _is_vti_image() else 0
        button_font_adjust = (1 if (_is_openatv_image() or _is_open_source_image()) else 0) + vti_font_adjust
        button_font_hd = 25 + button_font_adjust
        button_font_sd = 19 + button_font_adjust
        favor_font_hd = 25 + vti_font_adjust
        favor_font_sd = 16 + vti_font_adjust
        emptyinfo_font_hd = 18 + vti_font_adjust
        emptyinfo_font_sd = 13 + vti_font_adjust
        try:
            _bootstrap_embedded_default_city()
        except Exception:
            pass
        try:
            _load_saved_locations()
        except Exception:
            pass
        if _use_fullhd_layout():
            skin = """
                    <screen name="TheWeatherIet5ManageFavorites" position="center,center" size="1080,570" title="Manage Favorites - TheWeatherIet5" flags="wfNoBorder" backgroundColor="#232323" transparent="0">
                    <eLabel position="0,0" size="1080,570" backgroundColor="#232323" transparent="0" zPosition="0"/>
                    <eLabel position="0,0" size="1080,46" backgroundColor="#454b50" transparent="0" zPosition="1"/>
                    <widget name="favor" position="18,5" size="800,34" valign="center" halign="left" zPosition="2" font="Regular;{favor_font_hd}" foregroundColor="#00ff00" backgroundColor="#454b50" transparent="0" noWrap="1"/>
                    <eLabel position="18,48" size="1044,2" backgroundColor="#9d6616" transparent="0" zPosition="1"/>
                    <widget name="emptyinfo" position="18,58" size="1044,30" valign="center" halign="center" zPosition="2" font="Regular;{emptyinfo_font_hd}" foregroundColor="#9f9f9f" backgroundColor="#232323" transparent="0" noWrap="1"/>
                    <widget name="list" position="18,94" size="1044,364" zPosition="5" foregroundColor="#ffffff" backgroundColor="#000000" transparent="0" scrollbarMode="showOnDemand"/>
                    <eLabel position="18,474" size="1044,1" backgroundColor="#9d6616" transparent="0" zPosition="1"/>
                    <widget name="key_red" position="42,492" size="210,28" zPosition="3" font="Regular;{button_font_hd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="72,524" size="150,3" backgroundColor="#c5161d" transparent="0" zPosition="3"/>
                    <widget name="key_green" position="304,492" size="210,28" zPosition="3" font="Regular;{button_font_hd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="334,524" size="150,3" backgroundColor="#2ca52c" transparent="0" zPosition="3"/>
                    <widget name="key_yellow" position="566,492" size="210,28" zPosition="3" font="Regular;{button_font_hd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="596,524" size="150,3" backgroundColor="#c5b01b" transparent="0" zPosition="3"/>
                    <widget name="key_blue" position="828,492" size="210,28" zPosition="3" font="Regular;{button_font_hd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="858,524" size="150,3" backgroundColor="#2aa8e7" transparent="0" zPosition="3"/>
                    </screen>""".format(button_font_hd=button_font_hd, favor_font_hd=favor_font_hd, emptyinfo_font_hd=emptyinfo_font_hd)

        else:
            skin = """
                    <screen name="TheWeatherIet5ManageFavorites" position="center,center" size="720,380" title="Manage Favorites - TheWeatherIet5" flags="wfNoBorder" backgroundColor="#232323" transparent="0">
                    <eLabel position="0,0" size="720,380" backgroundColor="#232323" transparent="0" zPosition="0"/>
                    <eLabel position="0,0" size="720,32" backgroundColor="#454b50" transparent="0" zPosition="1"/>
                    <widget name="favor" position="12,3" size="480,24" valign="center" halign="left" zPosition="2" font="Regular;{favor_font_sd}" foregroundColor="#00ff00" backgroundColor="#454b50" transparent="0" noWrap="1"/>
                    <eLabel position="12,34" size="696,1" backgroundColor="#9d6616" transparent="0" zPosition="1"/>
                    <widget name="emptyinfo" position="12,40" size="696,22" valign="center" halign="center" zPosition="2" font="Regular;{emptyinfo_font_sd}" foregroundColor="#9f9f9f" backgroundColor="#232323" transparent="0" noWrap="1"/>
                    <widget name="list" position="12,66" size="696,234" zPosition="5" foregroundColor="#ffffff" backgroundColor="#000000" transparent="0" scrollbarMode="showOnDemand"/>
                    <eLabel position="12,314" size="696,1" backgroundColor="#9d6616" transparent="0" zPosition="1"/>
                    <widget name="key_red" position="24,328" size="150,22" zPosition="3" font="Regular;{button_font_sd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="45,352" size="108,2" backgroundColor="#c5161d" transparent="0" zPosition="3"/>
                    <widget name="key_green" position="198,328" size="150,22" zPosition="3" font="Regular;{button_font_sd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="219,352" size="108,2" backgroundColor="#2ca52c" transparent="0" zPosition="3"/>
                    <widget name="key_yellow" position="372,328" size="150,22" zPosition="3" font="Regular;{button_font_sd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="393,352" size="108,2" backgroundColor="#c5b01b" transparent="0" zPosition="3"/>
                    <widget name="key_blue" position="546,328" size="150,22" zPosition="3" font="Regular;{button_font_sd}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                    <eLabel position="567,352" size="108,2" backgroundColor="#2aa8e7" transparent="0" zPosition="3"/>
                    </screen>""".format(button_font_sd=button_font_sd, favor_font_sd=favor_font_sd, emptyinfo_font_sd=emptyinfo_font_sd)

        self.session = session
        self._screen_closed = False
        self._return_action_block_until = time.time() + (1.20 if return_selection else 0.70)
        self._return_selection = bool(return_selection)
        self._reopen_via_callback = bool(reopen_via_callback)
        self._empty_state_prompt_started = False
        self._editing_location_key = None
        self.skin = _apply_skin_path(skin)
        self.skinName = "TheWeatherIet5ManageFavorites"
        Screen.__init__(self, session)
        AddNewScreen(self)
        self["key_red"] = Label(_ui_text(_("Delete")))
        self["key_green"] = Label(_ui_text(_("Save")))
        self["key_yellow"] = Label(_ui_text(_("Edit")))
        self["key_blue"] = Label(_ui_text(_("Add")))
        self["favor"] = Label(_ui_text(_("Manage Favorites - TheWeatherIet5")))
        self["emptyinfo"] = Label("")
        self._inline_notice_timer = eTimer()
        self._inline_notice_callback = self._clear_inline_notice
        _connect_timer(self._inline_notice_timer, self._inline_notice_callback)
        self.res = []
        self._reload_favorites_view()
        self["list"] = MenuList(self.res, True, eListboxPythonMultiContent)
        self._apply_favorites_list_layout()
        self["list"].show()
        close_action = getattr(self, "cancel", None) or getattr(self, "exit", None) or self.close
        red_action = self.removeLoc
        self["actions"] = ActionMap(
            ["WizardActions", "MenuActions", "ShortcutActions", "OkCancelActions"],
            {
                "ok": self.go,
                "back": close_action,
                "cancel": close_action,
            },
            -1
        )
        self["color_actions"] = ActionMap(
            ["ColorActions"],
            {
                "red": red_action,
                "green": self.go,
                "yellow": self.editLoc,
                "blue": self.addLoc,
            },
            -1
        )
        self.onLayoutFinish.append(self._handle_empty_state_after_layout)
        self.onClose.append(self._cleanup)

    def _cleanup(self):
        self._screen_closed = True
        try:
            if self._inline_notice_timer is not None:
                try:
                    self._inline_notice_timer.stop()
                except Exception:
                    pass
                if self._inline_notice_callback is not None:
                    _disconnect_timer(self._inline_notice_timer, self._inline_notice_callback)
        except Exception:
            pass

    def _default_emptyinfo_text(self):
        return _("Use Blue to add a city.") if not self.res else ""

    def _clear_inline_notice(self):
        if self._screen_closed:
            return
        try:
            self._inline_notice_timer.stop()
        except Exception:
            pass
        _set_component_text(self["emptyinfo"], self._default_emptyinfo_text())

    def _show_inline_notice(self, message, timeout_ms=2500):
        if self._screen_closed:
            return
        _set_component_text(self["emptyinfo"], message)
        try:
            self._inline_notice_timer.stop()
        except Exception:
            pass
        try:
            _start_timer(self._inline_notice_timer, int(timeout_ms))
        except Exception:
            pass

    def _show_notice(self, message, timeout_ms=2500):
        self._show_inline_notice(_ui_text(message), timeout_ms)

    def _plugin_runtime_module(self):
        try:
            return sys.modules.get(getattr(_load_saved_locations, "__module__", ""))
        except Exception:
            return None

    def _plugin_saved_locations(self):
        plugin_runtime = self._plugin_runtime_module()
        if plugin_runtime is not None and hasattr(plugin_runtime, "SavedLocalWeather"):
            return plugin_runtime.SavedLocalWeather
        return SavedLocalWeather

    def _set_saved_locations(self, locations):
        global SavedLocalWeather
        normalized_locations = self._dedupe_locations(locations)
        SavedLocalWeather[:] = normalized_locations
        plugin_runtime = self._plugin_runtime_module()
        if plugin_runtime is not None and hasattr(plugin_runtime, "SavedLocalWeather"):
            try:
                plugin_runtime.SavedLocalWeather[:] = normalized_locations
            except Exception:
                try:
                    plugin_runtime.SavedLocalWeather = normalized_locations
                except Exception:
                    pass
        return SavedLocalWeather

    def _sync_saved_locations_view(self, reload_locations=False):
        global SavedLocalWeather
        if reload_locations:
            try:
                _load_saved_locations()
            except Exception:
                pass
        plugin_runtime = self._plugin_runtime_module()
        if plugin_runtime is not None and hasattr(plugin_runtime, "SavedLocalWeather"):
            if id(SavedLocalWeather) != id(plugin_runtime.SavedLocalWeather):
                SavedLocalWeather[:] = list(plugin_runtime.SavedLocalWeather)

    def _dedupe_locations(self, locations):
        deduped = []
        seen_keys = set()
        for location_name in list(locations or []):
            normalized_location = _normalize_location_input(location_name)
            if not normalized_location:
                continue
            if not _location_has_precise_coords(normalized_location):
                continue
            compare_key = _location_compare_key(normalized_location)
            if compare_key in seen_keys:
                continue
            seen_keys.add(compare_key)
            deduped.append(normalized_location)
        return deduped

    def _persist_favorite_locations(self, locations, preferred_location=None):
        persisted_locations = self._dedupe_locations(locations)
        current_locations = list(self._set_saved_locations(persisted_locations))
        try:
            _write_non_empty_lines(LOCATIONS_FILE, current_locations)
        except Exception:
            pass
        self._sync_saved_locations_view(reload_locations=False)
        self._reload_favorites_view(preferred_location, current_locations)
        return list(current_locations)

    def _block_return_action(self):
        self._return_action_block_until = time.time() + 0.4

    def _handle_empty_state_after_layout(self):
        if self._screen_closed or self.res or self._empty_state_prompt_started:
            return
        self._empty_state_prompt_started = True
        self.addLoc()

    def _apply_favorites_list_layout(self):
        try:
            title_font_boost = 0
            info_font_boost = 0
            row_primary_boost = 0
            row_secondary_boost = 0
            item_height_boost = 0
            if _is_vti_image():
                title_font_boost = 2
                info_font_boost = 2
                row_primary_boost = 3
                row_secondary_boost = 2
                item_height_boost = 4
            # Font size for eLabel widgets (favor, emptyinfo) is controlled by the skin.
            # Do NOT use instance.setFont() on eLabel components - rely on skin font attributes.
            # Only the MultiContent list engine (l.setFont) supports dynamic font overrides.
            if _use_fullhd_layout():
                self["list"].l.setItemHeight(56 + item_height_boost)
                self["list"].l.setFont(0, _runtime_font(32 + row_primary_boost))
                self["list"].l.setFont(1, _runtime_font(26 + row_secondary_boost))
            else:
                self["list"].l.setItemHeight(40 + item_height_boost)
                self["list"].l.setFont(0, _runtime_font(22 + row_primary_boost))
                self["list"].l.setFont(1, _runtime_font(18 + row_secondary_boost))
        except Exception:
            pass

    def _favorite_row(self, location_name):
        if _use_fullhd_layout():
            row_height = 56
            left_margin = 15
            right_margin = 20
            city_width = 450
            coords_width = 564
        else:
            row_height = 40
            left_margin = 10
            right_margin = 15
            city_width = 300
            coords_width = 376
        city_text = _location_label(location_name)
        coords_text = self._favorite_coords_text(location_name)
        _tw_log("Rendering row for: %s | %s " % (city_text, coords_text))
        return [
            location_name,
            MultiContentEntryText(pos=(left_margin, 0), size=(city_width, row_height), font=0, flags=RT_HALIGN_LEFT, text=_ui_text(city_text), color_sel=0x00D2D226),
            MultiContentEntryText(pos=(left_margin + city_width, 0), size=(coords_width - right_margin, row_height), font=1, flags=RT_HALIGN_RIGHT, text=_ui_text(coords_text), color_sel=0x00D2D226),
        ]

    def _favorite_coords_text(self, location_name):
        location_text = _ensure_text(location_name).strip()
        if "@" in location_text:
            coords_text = location_text.rsplit("@", 1)[1].strip()
            if "," in coords_text:
                lat_text, lon_text = [part.strip() for part in coords_text.split(",", 1)]
                if lat_text and lon_text:
                    return _("Lon: %s, Lat: %s") % (lon_text, lat_text)
        return _("No coordinates")

    def _current_selected_location(self):
        if not self.res:
            return None
        try:
            index = int(self["list"].getSelectedIndex())
        except Exception:
            index = 0
        if index < 0 or index >= len(self.res):
            index = 0
        try:
            return _normalize_location_input(self.res[index][0])
        except Exception:
            return None

    def _reload_favorites_view(self, preferred_location=None, locations=None):
        if locations is None:
            self._sync_saved_locations_view(reload_locations=True)
            current_locations = list(self._plugin_saved_locations())
        else:
            current_locations = self._dedupe_locations(locations)
            self._set_saved_locations(current_locations)
        previous_index = 0
        try:
            previous_index = int(self["list"].getSelectedIndex())
        except Exception:
            previous_index = 0
        preferred_key = None
        if preferred_location:
            try:
                preferred_key = _location_compare_key(preferred_location)
            except Exception:
                preferred_key = None
        self.res[:] = []
        _tw_log("Reloading favorites view with %d current locations" % len(current_locations))
        target_index = 0
        for idx, location_name in enumerate(current_locations):
            self.res.append(self._favorite_row(location_name))
            if preferred_key is not None and _location_compare_key(location_name) == preferred_key:
                target_index = idx
        _tw_log("Added %d rows to the list widget" % len(self.res))
        _set_component_text(self["emptyinfo"], _("Use Blue to add a city.") if not current_locations else "")
        try:
            self["list"].setList(self.res)
        except Exception:
            pass
        try:
            self["list"].l.setList(self.res)
        except Exception:
            pass
        try:
            self["list"].show()
        except Exception:
            pass
        if self.res:
            if preferred_key is None:
                target_index = min(max(previous_index, 0), len(self.res) - 1)
            try:
                self["list"].moveToIndex(target_index)
            except Exception:
                pass

    def _consume_return_action(self):
        if time.time() <= self._return_action_block_until:
            self._return_action_block_until = 0.0
            return True
        return False

    def go(self):
        if self._screen_closed:
            return
        if self._consume_return_action():
            return
        if len(self._plugin_saved_locations()) <= 0 or not self.res:
            self.addLoc()
            return
        try:
            index = self["list"].getSelectedIndex()
            selecteddat = _ensure_text(self.res[index][0]).strip()
            if not selecteddat:
                return
            if self._return_selection:
                self._screen_closed = True
                _close_screen_instance(self, selecteddat)
                return
            if self._reopen_via_callback:
                self._screen_closed = True
                _close_screen_instance(self, selecteddat)
                return
            if PY3:
                self._screen_closed = True
                _close_screen_instance(self)
                _open_weather_screen(self.session, selecteddat, allow_async=True)
                return
            else:
                if _open_weather_screen(self.session, selecteddat):
                    self._screen_closed = True
                    _close_screen_instance(self)
                    return
                else:
                    if not self._screen_closed:
                        self._show_notice(_("Download error: Check spelling."))
        except Exception as e:
            print("[TheWeather] location go error: " + str(e))
            if not self._screen_closed:
                self._show_notice(_("Download error: No response, try again"))

    def addLoc(self):
        if self._screen_closed:
            return
        try:
            _open_virtual_keyboard(self.session, self.searchCity, _("Enter cityname e.g. london or cairo"), "")
        except Exception as e:
            print("[TheWeather] keyboard open error: " + str(e))
            if not self._screen_closed:
                self._show_notice(_("Keyboard screen is not available on this image."))

    def editLoc(self):
        if self._screen_closed or len(self._plugin_saved_locations()) <= 0 or not self.res:
            return
        current_location = self._current_selected_location()
        if not current_location:
            return
        if not _location_has_precise_coords(current_location):
            if not self._screen_closed:
                self._show_notice(_("This city entry is invalid and cannot be edited."))
            return
        self._editing_location_key = _location_compare_key(current_location)
        current_label = _display_city_only(current_location)
        try:
            _open_virtual_keyboard(self.session, self._on_edit_city_text, _("Edit cityname"), current_label)
        except Exception as e:
            print("[TheWeather] edit keyboard open error: " + str(e))
            self._editing_location_key = None
            if not self._screen_closed:
                self._show_notice(_("Keyboard screen is not available on this image."))

    def _on_edit_city_text(self, searchterm=None):
        if self._screen_closed:
            return
        searchterm = _ensure_text(searchterm).strip()
        if not searchterm:
            self._editing_location_key = None
            return
        search_results = []
        try:
            from .WeatherProviders import search_locations
            search_results = search_locations(searchterm)
        except Exception as e:
            print("[TheWeather] edit city search error: " + str(e))
        if not search_results:
            self._editing_location_key = None
            if not self._screen_closed:
                self._show_notice(_("No matching cities found. Check spelling."))
            return
        try:
            if not self._screen_closed:
                self.session.openWithCallback(self._return_from_edit_results, locationsearchresultscreen, searchterm, search_results)
        except Exception as e:
            print("[TheWeather] edit city result screen error: " + str(e))

    def _return_from_edit_results(self, selected_location=None):
        if self._screen_closed:
            return
        selected_location = _normalize_location_input(selected_location)
        if not selected_location:
            self._editing_location_key = None
            self._block_return_action()
            return
        self._apply_edited_location(selected_location)

    def _apply_edited_location(self, selected_location):
        editing_key = self._editing_location_key
        self._editing_location_key = None
        if not editing_key:
            return
        selected_location = _normalize_location_input(selected_location)
        if not selected_location:
            return
        try:
            active_locations = list(self._plugin_saved_locations())
            target_index = -1
            old_location = None
            for idx, location_name in enumerate(active_locations):
                if _location_compare_key(location_name) == editing_key:
                    target_index = idx
                    old_location = location_name
                    break
            if target_index < 0:
                return

            updated_locations = []
            new_key = _location_compare_key(selected_location)
            for idx, location_name in enumerate(active_locations):
                current_key = _location_compare_key(location_name)
                if idx == target_index:
                    continue
                if current_key == new_key:
                    continue
                updated_locations.append(location_name)

            insert_at = target_index if target_index <= len(updated_locations) else len(updated_locations)
            updated_locations.insert(insert_at, selected_location)
            current_locations = self._persist_favorite_locations(updated_locations, selected_location)

            current_location = _normalize_location_input(_resolve_start_location())
            if old_location and current_location and _location_compare_key(old_location) == _location_compare_key(current_location):
                _sync_active_location(selected_location, add_to_favorites=True)
        except Exception as e:
            print("[TheWeather] apply edited city error: " + str(e))

    def removeLoc(self):
        if self._screen_closed or len(self._plugin_saved_locations()) <= 0 or not self.res:
            return
        try:
            index = self["list"].getSelectedIndex()
            current_locations = list(self._plugin_saved_locations())
            removed_location = _normalize_location_input(current_locations[index])
            del current_locations[index]
            current_locations = self._persist_favorite_locations(current_locations)
            current_location = _normalize_location_input(_resolve_start_location())
            replacement_location = ""
            if removed_location and current_location and _location_compare_key(removed_location) == _location_compare_key(current_location):
                if current_locations:
                    replacement_location = current_locations[0]
                    _sync_active_location(current_locations[0])
                else:
                    restored_location = _ensure_default_location_available(force=True)
                    replacement_location = restored_location
                    _purge_location_from_config_storage(removed_location, replacement_location)
                    self._reload_favorites_view(restored_location)
                    if not self._screen_closed:
                        self._show_notice(_("Cairo restored as default city."))
                    return
            elif not current_locations:
                restored_location = _ensure_default_location_available(force=True)
                replacement_location = restored_location
                _purge_location_from_config_storage(removed_location, replacement_location)
                self._reload_favorites_view(restored_location)
                if not self._screen_closed:
                    self._show_notice(_("Cairo restored as default city."))
                return
            else:
                replacement_location = current_location
            _purge_location_from_config_storage(removed_location, replacement_location)
        except Exception as e:
            print("[TheWeather] remove location error: " + str(e))

    def searchCity(self, searchterm=None):
        if self._screen_closed:
            return
        searchterm = _ensure_text(searchterm).strip()
        if not searchterm:
            return
        search_results = []
        try:
            from .WeatherProviders import search_locations
            search_results = search_locations(searchterm)
        except Exception as e:
            print("[TheWeather] city search error: " + str(e))
        if not search_results:
            if not self._screen_closed:
                self._show_notice(_("No matching cities found. Check spelling."))
            return
        try:
            if not self._screen_closed:
                self.session.openWithCallback(self._return_from_search_results, locationsearchresultscreen, searchterm, search_results)
        except Exception as e:
            print("[TheWeather] city result screen error: " + str(e))

    def _return_from_search_results(self, selected_location=None):
        if self._screen_closed:
            return
        selected_location = _normalize_location_input(selected_location)
        if not selected_location:
            self._block_return_action()
            return
        self.saveSelectedCity(selected_location)

    def saveSelectedCity(self, selected_location=None):
        if self._screen_closed:
            return
        selected_location = _normalize_location_input(selected_location)
        if not selected_location:
            return
        try:
            if self._return_selection:
                self._screen_closed = True
                _close_screen_instance(self, selected_location)
                return

            compare_key = _location_compare_key(selected_location)
            reordered_locations = [selected_location]
            for saved_location in list(self._plugin_saved_locations()):
                if _location_compare_key(saved_location) == compare_key:
                    continue
                reordered_locations.append(saved_location)
            self._persist_favorite_locations(reordered_locations, selected_location)
            if not self._return_selection and not self._screen_closed:
                self._show_notice(_("City added successfully."))
        except Exception as e:
            print("[TheWeather] save selected city error: " + str(e))

    def exit(self):
        if self._screen_closed:
            return
        if self._consume_return_action():
            return
        if self._return_selection:
            self._screen_closed = True
            _close_screen_instance(self, None)
            return
        self._screen_closed = True
        _close_screen_instance(self)

    def cancel(self):
        self.exit()


class infoscreen(Screen):
    def __init__(self, session):
        bind_runtime()
        if _use_fullhd_layout():
            skin = """
                    <screen name="startScreen" position="center,center" size="1920,1080" title="Weather Plugin">
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline3.png" position="0,112" size="1920,3" zPosition="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline3.png" position="0,1010" size="1920,3" zPosition="1"/>
                    <widget source="global.CurrentTime" render="Label" position="1634,35" size="225,45" transparent="1" zPosition="3" font="Regular;36" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="1409,74" size="450,37" transparent="1" zPosition="3" font="Regular;24" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget source="session.VideoPicture" render="Pig" position="40,170" size="760,428" backgroundColor="#000000" zPosition="1"/>
                    <widget source="session.CurrentService" render="Label" position="40,130" size="760,32" zPosition="1" foregroundColor="white" transparent="1" font="Regular;30" noWrap="1" valign="center" halign="center"><convert type="ServiceName">Name</convert></widget>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/red34.png" position="192,1022" size="34,34" alphatest="blend"/>
                    <widget name="key_red" position="242,1015" size="370,42" zPosition="1" font="Regular;40" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/green34.png" position="628,1022" size="34,34" alphatest="blend"/>
                    <widget name="key_green" position="678,1015" size="370,42" zPosition="1" font="Regular;40" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/yellow34.png" position="1064,1022" size="34,34" alphatest="blend"/>
                    <widget name="key_yellow" position="1114,1015" size="370,42" zPosition="1" font="Regular;40" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="helpinfo" position="880,70" size="900,700" valign="top" halign="left" zPosition="1" font="Regular;38" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="version" position="1280,930" size="620,46" valign="center" halign="left" zPosition="1" font="Regular;38" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""
        else:
            skin = """
                    <screen name="startScreen" position="center,center" size="1280,720" title="Weather Plugin">
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline2.png" position="0,88" size="1280,2" zPosition="1"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/borders/smallline2.png" position="0,630" size="1280,2" zPosition="1"/>
                    <widget source="global.CurrentTime" render="Label" position="1091,12" size="150,55" transparent="1" zPosition="1" font="Regular;24" valign="center" halign="right"><convert type="ClockToText">Format:%-H:%M</convert></widget>
                    <widget source="global.CurrentTime" render="Label" position="941,32" size="300,55" transparent="1" zPosition="1" font="Regular;16" valign="center" halign="right"><convert type="ClockToText">Format:%a %d/%m/%y</convert></widget>
                    <widget source="session.VideoPicture" render="Pig" position="85,110" size="417,243" backgroundColor="#000000" zPosition="1"/>
                    <widget source="session.CurrentService" render="Label" position="85,89" size="417,20" zPosition="1" foregroundColor="white" transparent="1" font="Regular;28" noWrap="1" valign="center" halign="center"><convert type="ServiceName">Name</convert></widget>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/red26.png" position="145,663" size="26,26" alphatest="blend"/>
                    <widget name="key_red" position="185,663" size="220,28" zPosition="1" font="Regular;24" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/green26.png" position="420,663" size="26,26" alphatest="blend"/>
                    <widget name="key_green" position="460,663" size="220,28" zPosition="1" font="Regular;24" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TheWeatherIet5/""" + iconpath + """/buttons/yellow26.png" position="695,663" size="26,26" alphatest="blend"/>
                    <widget name="key_yellow" position="735,663" size="220,28" zPosition="1" font="Regular;24" halign="left" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="helpinfo" position="673,120" size="400,320" valign="center" halign="left" zPosition="1" font="Regular;24" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    <widget name="version" position="900,590" size="400,28" valign="center" halign="left" zPosition="1" font="Regular;24" backgroundColor="#000000" transparent="1" shadowColor="black" shadowOffset="-2,-2"/>
                    </screen>"""

        self.session = session
        self.skin = _apply_skin_path(skin)
        Screen.__init__(self, session)
        self["key_red"] = Label(_ui_text(_("Exit")))
        self["helpinfo"] = Label(_ui_text(_("Manual city entry:\nGo back to \"Location +\" and add your city name, for example:\n\"London\" or \"Dusseldorf\" or \"Cairo\"\nA city selection list will appear so you can choose the correct match.")))
        self["actions"] = ActionMap(["WizardActions"], {"back": self.exit}, -1)
        self["ColorActions"] = ActionMap(["ColorActions"], {"red": self.exit}, -1)
        self["version"] = Label(_ui_text("%s_V_%s" % (PLUGIN_ID, version)))

    def exit(self):
        _close_screen_instance(self, localcityscreen)





