# -*- coding: utf-8 -*-
# Python 2/3 compatibility: print_function ensures print() works as function in Python 2.7
# absolute_import enforces explicit relative imports for Python 2.7 and Python 3.12 compatibility
from __future__ import print_function, absolute_import
#
# TheWeatherSetting.py
# Compatible with Dreambox, Vu+, OpenATV, VTI, OpenPLi and all Enigma2 images
#
from . import _
import os
import sys
from .plugin_utils import (
    _ensure_text,
    _normalize_location_input,
    _runtime_image_family,
    _tw_auto_update_choices,
    _tw_cache_choices,
    _write_non_empty_lines,
    _tw_set_cfg,
    _tw_log,
    _display_city_only,
)
from .WeatherProviders import DEFAULT_WEATHER_SERVICE, WEATHER_SERVICE_CHOICES
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Label import Label
from enigma import eTimer
from .screen_tracking import AddNewScreen, ClosePlugin
try:
    from enigma import gFont, getDesktop
except Exception:
    gFont = None
    try:
        from enigma import getDesktop
    except Exception:
        getDesktop = None

_ICONSET_DEFAULT = "Images"
_SETTINGS_LIST_FONT_SIZE = 22
_SETTINGS_LIST_ITEM_HEIGHT = 42
_SETTINGS_LIST_LABEL_WIDTH = 390
_SETTINGS_CLOSE_SENTINEL = object()


def _use_legacy_settings_view():
    try:
        return bool(_runtime_image_family() == "dreamos" and sys.version_info[0] < 3)
    except Exception:
        return False


def _close_settings_screen(screen, result=_SETTINGS_CLOSE_SENTINEL):
    if screen is None:
        return False
    try:
        _tw_log("Closing settings screen %s on image=%s" % (screen.__class__.__name__, _runtime_image_family()))
    except Exception:
        pass
    try:
        if result is _SETTINGS_CLOSE_SENTINEL:
            ClosePlugin(screen)
        else:
            ClosePlugin(screen, result)
        return True
    except TypeError:
        pass
    except Exception as e:
        try:
            _tw_log("Tracked settings close failed: %s" % str(e))
        except Exception:
            pass
    try:
        if result is _SETTINGS_CLOSE_SENTINEL:
            screen.close()
        else:
            screen.close(result)
        return True
    except Exception as e:
        try:
            _tw_log("Direct settings close failed: %s" % str(e))
        except Exception:
            pass
    return False

_cached_background_choices = None

def _should_refresh_background_choices():
    image_family = _runtime_image_family()
    return bool(image_family in ("dreamos", "vti", "openatv", "open-source", "generic-enigma2"))

def _background_choices():
    global _cached_background_choices
    if _should_refresh_background_choices():
        _cached_background_choices = None
    if _cached_background_choices is not None:
        return _cached_background_choices

    import os
    import re
    choices = set()
    try:
        bg_dir = os.path.join(os.path.dirname(__file__), "Images", "background")
        if os.path.isdir(bg_dir):
            for f in os.listdir(bg_dir):
                match = re.match(r"^backgroundhd\+(\d+)\.png$", f, re.IGNORECASE)
                if match:
                    choices.add(int(match.group(1)))
                else:
                    match_non_hd = re.match(r"^background\+(\d+)\.png$", f, re.IGNORECASE)
                    if match_non_hd:
                        choices.add(int(match_non_hd.group(1)))
        
        if not choices:
            choices.add(1)
            
        sorted_choices = sorted(list(choices))
        _cached_background_choices = [(str(i), _("Background ") + str(i)) for i in sorted_choices]
        return _cached_background_choices
    except Exception:
        return [(str(i), _("Background ") + str(i)) for i in range(1, 17)]


def _sanitize_iconset_value(value):
    try:
        return _sanitize_icon_pack(value)
    except Exception:
        text_value = _ensure_text(value).strip()
        return text_value or _ICONSET_DEFAULT


def _read_saved_iconset():
    try:
        return _read_saved_icon_pack()
    except Exception:
        return ""


def _write_saved_iconset(value):
    try:
        _write_saved_icon_pack(value)
    except Exception as e:
        print("[TheWeatherSetting] failed to write iconset file: " + str(e))


# -----------------------------------------------------------------------
# Read version from TheWeatherIet5's own version.txt
# -----------------------------------------------------------------------
def _read_version():
    try:
        vf = os.path.join(os.path.dirname(__file__), "version.txt")
        with open(vf, "r") as f:
            return f.read().strip()
    except Exception:
        return "1.0"

def _location_setting_label(location_value):
    location_text = _display_city_only(location_value)
    if "," in location_text:
        location_text = location_text.split(",", 1)[0].strip()
    return location_text or _("Not set")


try:
    from Components.config import (
        config,
        getConfigListEntry,
        ConfigYesNo,
        ConfigSubsection,
        ConfigSelection,
        ConfigText,
    )
    from .plugin import (
        DEFAULT_ICON_PACK,
        MESSAGEBOX_TYPE_INFO,
        MessageBox,
        LOCATIONS_FILE,
        _append_unique_location,
        _apply_skin_path,
        _icon_pack_choices,
        _read_saved_icon_pack,
        _scale_font_size_for_runtime,
        _sanitize_icon_pack,
        _open_virtual_keyboard,
        _open_weather_screen,
        _persist_runtime_settings,
        _clear_session_update_timers,
        _sync_active_background,
        _sync_active_location,
        _write_saved_icon_pack,
    )

    _ICONSET_DEFAULT = DEFAULT_ICON_PACK

    if not hasattr(config.plugins, "TheWeatherIet5"):
        config.plugins.TheWeatherIet5 = ConfigSubsection()

    def _ensure_cfg(name, item):
        if not hasattr(config.plugins.TheWeatherIet5, name):
            setattr(config.plugins.TheWeatherIet5, name, item)

    _ensure_cfg("enabled", ConfigYesNo(default=True))
    _ensure_cfg("automatic_update", ConfigSelection(default="0", choices=_tw_auto_update_choices()))
    _ensure_cfg("weatherservice", ConfigSelection(default=DEFAULT_WEATHER_SERVICE, choices=list(WEATHER_SERVICE_CHOICES)))
    _ensure_cfg("weatherlocation", ConfigText(default="", fixed_size=False))
    _ensure_cfg("apikey", ConfigText(default="", fixed_size=False))
    _ensure_cfg("detailLevel", ConfigSelection(default="more", choices=[("more", _("More Details / Smaller font"))]))
    _ensure_cfg("tempUnit", ConfigSelection(default="Celsius", choices=[("Celsius", _("Celsius")), ("Fahrenheit", _("Fahrenheit"))]))
    _ensure_cfg("windspeedMetricUnit", ConfigSelection(default="km/h", choices=[("km/h", "km/h"), ("m/s", "m/s")]))
    _ensure_cfg("background", ConfigSelection(default="1", choices=_background_choices()))
    _ensure_cfg("iconset", ConfigSelection(default=_sanitize_iconset_value(_read_saved_iconset() or _ICONSET_DEFAULT), choices=_icon_pack_choices()))
    _ensure_cfg("trendarrows", ConfigYesNo(default=True))
    _ensure_cfg("cachedata", ConfigSelection(default="30", choices=_tw_cache_choices()))
    _ensure_cfg("debug", ConfigYesNo(default=False))
    try:
        config.plugins.TheWeatherIet5.automatic_update.setChoices(_tw_auto_update_choices(), default="0")
    except Exception:
        try:
            config.plugins.TheWeatherIet5.automatic_update.choices = _tw_auto_update_choices()
        except Exception:
            pass
    try:
        config.plugins.TheWeatherIet5.cachedata.setChoices(_tw_cache_choices(), default="30")
    except Exception:
        try:
            config.plugins.TheWeatherIet5.cachedata.choices = _tw_cache_choices()
        except Exception:
            pass
    try:
        config.plugins.TheWeatherIet5.weatherservice.setChoices(list(WEATHER_SERVICE_CHOICES), default=DEFAULT_WEATHER_SERVICE)
    except Exception:
        try:
            config.plugins.TheWeatherIet5.weatherservice.choices = list(WEATHER_SERVICE_CHOICES)
        except Exception:
            pass
    try:
        saved_iconset = _sanitize_iconset_value(_read_saved_iconset() or getattr(config.plugins.TheWeatherIet5.iconset, "value", _ICONSET_DEFAULT))
        config.plugins.TheWeatherIet5.iconset.setChoices(_icon_pack_choices(saved_iconset), default=saved_iconset)
        config.plugins.TheWeatherIet5.iconset.value = saved_iconset
    except Exception:
        try:
            config.plugins.TheWeatherIet5.iconset.choices = _icon_pack_choices(_ICONSET_DEFAULT)
            config.plugins.TheWeatherIet5.iconset.value = _sanitize_iconset_value(getattr(config.plugins.TheWeatherIet5.iconset, "value", _ICONSET_DEFAULT))
        except Exception:
            pass
    try:
        current_auto_update = _ensure_text(getattr(config.plugins.TheWeatherIet5.automatic_update, "value", "0")).strip().lower()
        valid_auto_update_values = [choice[0] for choice in _tw_auto_update_choices()]
        if current_auto_update in ("true", "yes", "on", "1"):
            config.plugins.TheWeatherIet5.automatic_update.value = "30"
        elif current_auto_update in ("false", "no", "off", ""):
            config.plugins.TheWeatherIet5.automatic_update.value = "0"
        elif current_auto_update not in valid_auto_update_values:
            config.plugins.TheWeatherIet5.automatic_update.value = "0"
    except Exception:
        pass
    try:
        current_cache_value = _ensure_text(getattr(config.plugins.TheWeatherIet5.cachedata, "value", "30")).strip()
        valid_cache_values = [choice[0] for choice in _tw_cache_choices()]
        if current_cache_value not in valid_cache_values:
            try:
                config.plugins.TheWeatherIet5.cachedata.value = "0" if int(current_cache_value) <= 0 else "30"
            except Exception:
                config.plugins.TheWeatherIet5.cachedata.value = "30"
    except Exception:
        pass
    try:
        current_weather_service = _ensure_text(getattr(config.plugins.TheWeatherIet5.weatherservice, "value", DEFAULT_WEATHER_SERVICE)).strip().lower()
        valid_weather_services = [choice[0] for choice in WEATHER_SERVICE_CHOICES]
        if current_weather_service not in valid_weather_services:
            config.plugins.TheWeatherIet5.weatherservice.value = DEFAULT_WEATHER_SERVICE
    except Exception:
        pass

    _OA_OK = True
    _OA_INIT_ERROR = ""
except Exception as _err:
    _OA_OK = False
    _OA_INIT_ERROR = str(_err)
    print("[TheWeatherSetting] TheWeatherIet5 config init failed: " + str(_err))

    def _apply_skin_path(skin):
        return skin

    def _scale_font_size_for_runtime(font_size, minimum=10):
        return font_size


def _plugin_runtime_module():
    try:
        import sys
        return sys.modules.get(getattr(_append_unique_location, "__module__", ""))
    except Exception:
        return None


def _plugin_saved_locations():
    plugin_runtime = _plugin_runtime_module()
    if plugin_runtime is not None and hasattr(plugin_runtime, "SavedLocalWeather"):
        return plugin_runtime.SavedLocalWeather
    return []


def _settings_runtime_font(size):
    if gFont is None:
        return None
    try:
        return gFont("Regular", _scale_font_size_for_runtime(size))
    except Exception:
        return gFont("Regular", size)


def _settings_font_value(size):
    image_family = _runtime_image_family()
    adjusted_size = float(size)
    if image_family == "openatv":
        adjusted_size *= 1.12
        adjusted_size += 1
    elif image_family == "vti":
        adjusted_size *= 1.14
        adjusted_size += 1
    elif image_family == "open-source":
        adjusted_size += 1
    elif image_family == "dreamos":
        adjusted_size *= 0.92
    return int(round(adjusted_size))


def _settings_window_metrics():
    desktop_width = 1280
    desktop_height = 720
    image_family = _runtime_image_family()
    try:
        if getDesktop is not None:
            desktop = getDesktop(0)
            if desktop is not None and desktop.size() is not None:
                desktop_width = int(desktop.size().width())
                desktop_height = int(desktop.size().height())
    except Exception:
        pass

    is_fullhd = desktop_width >= 1800 or desktop_height >= 1000
    if is_fullhd:
        # Match the red box visually on 1920x1080 outputs.
        screen_w, screen_h = 1000, 842
        top_h, strip_h = 50, 10
        margin = 14
        title_font, title_h, meta_font = 26, 36, 24
        list_font, item_h, label_w = 22, 50, 470
        button_font, button_h, button_gap = 25, 38, 8
        version_w = 140
        footer_h = 102
        button_top_padding = 16
    else:
        # Match the red box on 1280x720 outputs.
        screen_w, screen_h = 665, 569
        top_h, strip_h = 34, 8
        margin = 12
        title_font, title_h, meta_font = 18, 28, 16
        list_font, item_h, label_w = 16, 34, 310
        button_font, button_h, button_gap = 19, 28, 8
        version_w = 96
        footer_h = 74
        button_top_padding = 12

    title_font = _settings_font_value(title_font)
    meta_font = _settings_font_value(meta_font)
    list_font = _settings_font_value(list_font)
    button_font = _settings_font_value(button_font)
    if image_family == "vti":
        item_h += 4 if not is_fullhd else 6
        button_h += 2

    content_w = screen_w - (margin * 2)
    meta_y = top_h + strip_h + 8
    meta_h = 28 if is_fullhd else 20
    if image_family == "vti":
        meta_h += 2
    rule_y = meta_y + meta_h + 10
    panel_y = rule_y + 2
    panel_bottom_y = screen_h - footer_h
    button_y = panel_bottom_y + button_top_padding
    panel_h = panel_bottom_y - panel_y
    config_y = panel_y + (10 if is_fullhd else 8)
    config_h = panel_bottom_y - config_y - (8 if is_fullhd else 6)
    button_x = 6
    button_w = int((screen_w - (button_x * 2) - (button_gap * 3)) / 4)
    underline_w = 127 if is_fullhd else 101
    underline_y = button_y + button_h + 6

    return {
        "screen_w": screen_w,
        "screen_h": screen_h,
        "top_h": top_h,
        "strip_h": strip_h,
        "margin": margin,
        "content_w": content_w,
        "title_font": title_font,
        "title_h": title_h,
        "meta_font": meta_font,
        "list_font": list_font,
        "item_h": item_h,
        "label_w": label_w,
        "button_font": button_font,
        "button_h": button_h,
        "button_y": button_y,
        "meta_y": meta_y,
        "meta_h": meta_h,
        "rule_y": rule_y,
        "panel_y": panel_y,
        "panel_h": panel_h,
        "config_y": config_y,
        "config_h": config_h,
        "panel_bottom_y": panel_bottom_y,
        "version_x": screen_w - margin - version_w,
        "version_w": version_w,
        "button_red_x": button_x,
        "button_green_x": button_x + button_w + button_gap,
        "button_yellow_x": button_x + ((button_w + button_gap) * 2),
        "button_blue_x": button_x + ((button_w + button_gap) * 3),
        "button_w": button_w,
        "button_blue_w": screen_w - (button_x + ((button_w + button_gap) * 3)) - button_x,
        "underline_w": underline_w,
        "underline_y": underline_y,
        "underline_red_x": button_x + int((button_w - underline_w) / 2),
        "underline_green_x": button_x + button_w + button_gap + int((button_w - underline_w) / 2),
        "underline_yellow_x": button_x + ((button_w + button_gap) * 2) + int((button_w - underline_w) / 2),
        "underline_blue_x": button_x + ((button_w + button_gap) * 3) + int(((screen_w - (button_x + ((button_w + button_gap) * 3)) - button_x) - underline_w) / 2),
    }


class WeatherSettingsViewNew(ConfigListScreen, Screen):
    def __init__(self, session):
        _tw_log("[WeatherSettingsViewNew] __init__ start")
        metrics = _settings_window_metrics()
        self._legacy_settings_view = _use_legacy_settings_view()
        self._list_font_size = metrics["list_font"]
        self._list_item_height = metrics["item_h"]
        self._list_label_width = metrics["label_w"]
        if self._legacy_settings_view:
            self.skin = _apply_skin_path("""
            <screen name="WeatherSettingsViewNew" position="center,center" size="{screen_w},{screen_h}" title="TheWeatherIet5 - Settings" backgroundColor="#232323" flags="wfNoBorder">
                <eLabel position="0,0" size="{screen_w},{screen_h}" backgroundColor="#232323" zPosition="0" />
                <eLabel position="0,0" size="{screen_w},{top_h}" backgroundColor="#454b50" zPosition="1" />
                <eLabel text="TheWeatherIet5 - Settings" position="{margin},8" size="{content_w},30" font="Regular;{title_font}" foregroundColor="#00ff00" backgroundColor="#454b50" transparent="1" zPosition="2" />
                <eLabel position="0,{top_h}" size="{screen_w},{strip_h}" backgroundColor="#111111" transparent="0" zPosition="1" />

                <eLabel text="Modified by iet5" position="{margin},{meta_y}" size="260,{meta_h}" font="Regular;{meta_font}" foregroundColor="#ff0000" transparent="1" zPosition="2" />
                <widget name="version" position="{version_x},{meta_y}" size="{version_w},{meta_h}" font="Regular;{meta_font}" foregroundColor="#ff0000" halign="right" transparent="1" zPosition="2" />

                <eLabel position="{margin},{rule_y}" size="{content_w},2" backgroundColor="#9d6616" zPosition="2" />
                <eLabel position="{margin},{panel_y}" size="{content_w},{panel_h}" backgroundColor="#000000" zPosition="1" />

                <widget name="config" position="{margin},{config_y}" size="{content_w},{config_h}" scrollbarMode="showOnDemand" transparent="1" zPosition="3" />

                <eLabel position="{margin},{panel_bottom_y}" size="{content_w},2" backgroundColor="#9d6616" zPosition="2" />

                <widget name="key_red" position="{button_red_x},{button_y}" size="{button_w},{button_h}" zPosition="3" font="Regular;{button_font}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                <eLabel position="{underline_red_x},{underline_y}" size="{underline_w},3" backgroundColor="#c11620" transparent="0" zPosition="3"/>

                <widget name="key_green" position="{button_green_x},{button_y}" size="{button_w},{button_h}" zPosition="3" font="Regular;{button_font}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                <eLabel position="{underline_green_x},{underline_y}" size="{underline_w},3" backgroundColor="#1b9e4a" transparent="0" zPosition="3"/>

                <widget name="key_yellow" position="{button_yellow_x},{button_y}" size="{button_w},{button_h}" zPosition="3" font="Regular;{button_font}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                <eLabel position="{underline_yellow_x},{underline_y}" size="{underline_w},3" backgroundColor="#c5b01b" transparent="0" zPosition="3"/>

                <widget name="key_blue" position="{button_blue_x},{button_y}" size="{button_blue_w},{button_h}" zPosition="3" font="Regular;{button_font}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                <eLabel position="{underline_blue_x},{underline_y}" size="{underline_w},3" backgroundColor="#2aa8e7" transparent="0" zPosition="3"/>
            </screen>""".format(**metrics))
        else:
            self.skin = _apply_skin_path("""
            <screen name="WeatherSettingsViewNew" position="center,center" size="{screen_w},{screen_h}" title="TheWeatherIet5 - Settings" backgroundColor="#232323" flags="wfNoBorder">
                <eLabel position="0,0" size="{screen_w},{screen_h}" backgroundColor="#232323" zPosition="0" />
                <eLabel position="0,0" size="{screen_w},{top_h}" backgroundColor="#454b50" zPosition="1" />
                <eLabel text="TheWeatherIet5 - Settings" position="{margin},8" size="{content_w},30" font="Regular;{title_font}" foregroundColor="#00ff00" backgroundColor="#454b50" transparent="1" zPosition="2" />
                <eLabel position="0,{top_h}" size="{screen_w},{strip_h}" backgroundColor="#111111" transparent="0" zPosition="1" />

                <eLabel text="Modified by iet5" position="{margin},{meta_y}" size="260,{meta_h}" font="Regular;{meta_font}" foregroundColor="#ff0000" transparent="1" zPosition="2" />
                <widget name="version" position="{version_x},{meta_y}" size="{version_w},{meta_h}" font="Regular;{meta_font}" foregroundColor="#ff0000" halign="right" transparent="1" zPosition="2" />

                <eLabel position="{margin},{rule_y}" size="{content_w},2" backgroundColor="#9d6616" zPosition="2" />
                <eLabel position="{margin},{panel_y}" size="{content_w},{panel_h}" backgroundColor="#000000" zPosition="1" />

                <widget name="config" position="{margin},{config_y}" size="{content_w},{config_h}" font="Regular;{list_font}" itemHeight="{item_h}" selectionColor="#332b24" scrollbarMode="showOnDemand" transparent="1" zPosition="3" />

                <eLabel position="{margin},{panel_bottom_y}" size="{content_w},2" backgroundColor="#9d6616" zPosition="2" />

                <widget name="key_red" position="{button_red_x},{button_y}" size="{button_w},{button_h}" zPosition="3" font="Regular;{button_font}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                <eLabel position="{underline_red_x},{underline_y}" size="{underline_w},3" backgroundColor="#c11620" transparent="0" zPosition="3"/>

                <widget name="key_green" position="{button_green_x},{button_y}" size="{button_w},{button_h}" zPosition="3" font="Regular;{button_font}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                <eLabel position="{underline_green_x},{underline_y}" size="{underline_w},3" backgroundColor="#1b9e4a" transparent="0" zPosition="3"/>

                <widget name="key_yellow" position="{button_yellow_x},{button_y}" size="{button_w},{button_h}" zPosition="3" font="Regular;{button_font}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                <eLabel position="{underline_yellow_x},{underline_y}" size="{underline_w},3" backgroundColor="#c5b01b" transparent="0" zPosition="3"/>

                <widget name="key_blue" position="{button_blue_x},{button_y}" size="{button_blue_w},{button_h}" zPosition="3" font="Regular;{button_font}" halign="center" valign="center" backgroundColor="#232323" foregroundColor="#f0f0f0" transparent="0"/>
                <eLabel position="{underline_blue_x},{underline_y}" size="{underline_w},3" backgroundColor="#2aa8e7" transparent="0" zPosition="3"/>
            </screen>""".format(**metrics))

        _tw_log("[WeatherSettingsViewNew] calling Screen initiation")
        self.skinName = "WeatherSettingsViewNew"
        Screen.__init__(self, session)
        self._screen_closed = False
        try:
            AddNewScreen(self)
        except Exception:
            pass
        try:
            self.setTitle(_("TheWeatherIet5 - Settings"))
        except Exception:
            pass
        _tw_log("[WeatherSettingsViewNew] calling ConfigListScreen initiation")
        ConfigListScreen.__init__(self, [], session=session)
        _tw_log("[WeatherSettingsViewNew] base components initialized")

        self["version"] = Label("Ver. " + _read_version())
        self["key_red"] = Label(_("Select location"))
        self["key_green"] = Label(_("Save"))
        self["key_yellow"] = Label(_("Add City"))
        self["key_blue"] = Label(_("Manage Favorites"))
        self._defer_open_timer = None
        self._defer_open_callback = None
        self["actions"] = ActionMap(["WizardActions", "MenuActions", "ShortcutActions", "OkCancelActions"], {
            "save": self.keySave,
            "cancel": self.keyCancel,
            "back": self.keyCancel,
            "ok": self.keyOK,
            "left": self.keyLeft,
            "right": self.keyRight,
        }, -2)
        self["color_actions"] = ActionMap(["ColorActions"], {
            "red": self.keyRed,
            "green": self.keyGreen,
            "yellow": self.keyYellow,
            "blue": self.keyBlue,
        }, -1)
        self.onClose.append(self._cleanup_settings_view)
        self._apply_config_list_layout()
        _tw_log("[WeatherSettingsViewNew] __init__ end")

    def _cleanup_settings_view(self):
        self._screen_closed = True
        try:
            if self._defer_open_timer is not None:
                self._defer_open_timer.stop()
        except Exception:
            pass
        self._defer_open_timer = None
        self._defer_open_callback = None

    def _close_view(self, result=_SETTINGS_CLOSE_SENTINEL):
        if self._screen_closed:
            return
        self._screen_closed = True
        _close_settings_screen(self, result)

    def _apply_config_list_layout(self):
        try:
            config_widget = self["config"]
        except Exception:
            return
        list_item_height = getattr(self, "_list_item_height", _SETTINGS_LIST_ITEM_HEIGHT)
        list_font_size = getattr(self, "_list_font_size", _SETTINGS_LIST_FONT_SIZE)
        list_label_width = getattr(self, "_list_label_width", _SETTINGS_LIST_LABEL_WIDTH)
        try:
            listbox = getattr(config_widget, "l", None)
            if listbox is not None:
                if hasattr(listbox, "setItemHeight"):
                    try:
                        listbox.setItemHeight(list_item_height)
                    except Exception:
                        pass
                if gFont is not None and hasattr(listbox, "setFont"):
                    for font_index in (0, 1, 2):
                        try:
                            runtime_font = _settings_runtime_font(list_font_size)
                            if runtime_font is not None:
                                listbox.setFont(font_index, runtime_font)
                        except Exception:
                            pass
                if hasattr(listbox, "setLabelWidth"):
                    try:
                        listbox.setLabelWidth(list_label_width)
                    except Exception:
                        pass
        except Exception:
            pass

    def _defer_screen_open(self, callback, delay_ms=500):
        try:
            self._defer_open_callback = callback
            timer = eTimer()
            self._defer_open_timer = timer

            def _run_deferred():
                try:
                    timer.stop()
                except Exception:
                    pass
                deferred = getattr(self, "_defer_open_callback", None)
                self._defer_open_callback = None
                self._defer_open_timer = None
                if callable(deferred):
                    deferred()

            try:
                timer.callback.append(_run_deferred)
            except Exception:
                try:
                    timer.timeout.connect(_run_deferred)
                except Exception:
                    callback()
                    return
            timer.start(int(delay_ms), True)
        except Exception:
            try:
                callback()
            except Exception:
                pass

    def keyOK(self):
        try:
            current = self["config"].getCurrent()
            if current and len(current) > 1 and hasattr(current[1], "toggle"):
                current[1].toggle()
                self.createSetup()
        except Exception:
            pass

    def keyLeft(self):
        try:
            ConfigListScreen.keyLeft(self)
        except Exception:
            pass

    def keyRight(self):
        try:
            ConfigListScreen.keyRight(self)
        except Exception:
            pass

    def keyUp(self):
        try:
            ConfigListScreen.keyUp(self)
        except Exception:
            pass

    def keyDown(self):
        try:
            ConfigListScreen.keyDown(self)
        except Exception:
            pass

    def keySave(self):
        selected_loc = ""
        try:
            c = config.plugins.TheWeatherIet5
            if hasattr(self, "city_selection"):
                selected_loc = _normalize_location_input(getattr(self.city_selection, "value", ""))
                if selected_loc:
                    _sync_active_location(selected_loc, add_to_favorites=True)
                    try:
                        _tw_set_cfg("weatherlocation", selected_loc)
                    except Exception:
                        pass
            try:
                c.save()
            except Exception:
                pass
        except Exception as e:
            print("[TheWeatherSetting] keySave error: " + str(e))
        if selected_loc:
            self._close_view(selected_loc)
            return
        self._close_view(True)

    def keyCancel(self):
        self._close_view()

    def keyRed(self):
        pass

    def keyGreen(self):
        pass

    def keyYellow(self):
        pass

    def keyBlue(self):
        pass


_Base = WeatherSettingsViewNew


if _OA_OK:
    class TheweatherSetting(_Base):
        def __init__(self, session):
            _tw_log("[TheweatherSetting] __init__ start")
            global _cached_background_choices
            _cached_background_choices = None
            try:
                from . import plugin
                plugin._cached_background_values = None
            except Exception:
                pass
            _Base.__init__(self, session)
            _tw_log("[TheweatherSetting] base __init__ done, calling apply choices")
            self._apply_background_choices()
            self._background_choice_signature = tuple(choice[0] for choice in _background_choices())
            try:
                self.initial_background = config.plugins.TheWeatherIet5.background.value
            except Exception:
                self.initial_background = ""
            try:
                self.initial_weatherservice = config.plugins.TheWeatherIet5.weatherservice.value
            except Exception:
                self.initial_weatherservice = DEFAULT_WEATHER_SERVICE
            try:
                self.initial_iconset = config.plugins.TheWeatherIet5.iconset.value
            except Exception:
                self.initial_iconset = _ICONSET_DEFAULT
            try:
                self.initial_location = _normalize_location_input(config.plugins.TheWeatherIet5.weatherlocation.value)
            except Exception:
                self.initial_location = ""
            # Track temperature and wind speed units so a change triggers an
            # immediate in-plugin screen refresh without requiring a full restart.
            try:
                self.initial_tempUnit = _ensure_text(config.plugins.TheWeatherIet5.tempUnit.value).strip()
            except Exception:
                self.initial_tempUnit = "Celsius"
            try:
                self.initial_windspeedUnit = _ensure_text(config.plugins.TheWeatherIet5.windspeedMetricUnit.value).strip()
            except Exception:
                self.initial_windspeedUnit = "km/h"
            _tw_log("[TheweatherSetting] calling createSetup")
            self.createSetup()
            _tw_log("[TheweatherSetting] createSetup done")
            self.onShow.append(self._refresh_background_choices_for_runtime)

            try:
                if "version" in self:
                    self["version"].setText("Ver. " + _read_version())
            except Exception:
                pass
            _tw_log("[TheweatherSetting] __init__ end")

        def createSetup(self):
            _tw_log("[TheweatherSetting] createSetup start")
            try:
                self.editListEntry = None
                self.list = []
                c = config.plugins.TheWeatherIet5
                _tw_log("[TheweatherSetting] config accessed")

                self.list.append(getConfigListEntry(_("Weather service"), c.weatherservice))
                
                current_loc = _normalize_location_input(getattr(c.weatherlocation, "value", ""))
                choices = []
                seen_keys = set()
                for loc in list(_plugin_saved_locations() or []):
                    normalized_loc = _normalize_location_input(loc)
                    if not normalized_loc:
                        continue
                    compare_key = normalized_loc.lower()
                    if compare_key in seen_keys:
                        continue
                    seen_keys.add(compare_key)
                    display_name = _location_setting_label(normalized_loc)
                    if display_name:
                        choices.append((normalized_loc, display_name))

                if current_loc:
                    current_key = current_loc.lower()
                    if current_key not in seen_keys:
                        display_name = _location_setting_label(current_loc)
                        choices.insert(0, (current_loc, display_name or _("Default City")))
                        seen_keys.add(current_key)
                
                if not choices:
                    display_name = _location_setting_label(current_loc) or _("Default City")
                    choices = [(current_loc, display_name)]

                selected_default = current_loc
                available_values = [choice[0] for choice in choices]
                if selected_default not in available_values:
                    selected_default = available_values[0]
                    try:
                        _sync_active_location(selected_default, add_to_favorites=True)
                    except Exception:
                        pass
                    try:
                        _tw_set_cfg("weatherlocation", selected_default)
                    except Exception:
                        pass

                self.city_selection = ConfigSelection(default=selected_default, choices=choices)
                try:
                    self.city_selection.value = selected_default
                except Exception:
                    pass
                self.list.append(getConfigListEntry(_("Weather city name"), self.city_selection))

                self.list.append(getConfigListEntry(_("Temperature unit"), c.tempUnit))
                self.list.append(getConfigListEntry(_("Metric unit for wind speed"), c.windspeedMetricUnit))
                self.list.append(getConfigListEntry(_("Weather background"), c.background))
                self.list.append(getConfigListEntry(_("Show trend arrows for moon data"), c.trendarrows))
                self.list.append(getConfigListEntry(_("Auto Update"), c.automatic_update))
                self.list.append(getConfigListEntry(_("Cache data"), c.cachedata))
                self.list.append(getConfigListEntry(_("Enable Debug"), c.debug))
                _tw_log("[TheweatherSetting] list populated with " + str(len(self.list)) + " items")

                if hasattr(self["config"], "setList"):
                    self["config"].setList(self.list)
                elif hasattr(self["config"], "l"):
                    self["config"].l.setList(self.list)

                if hasattr(self["config"], "list"):
                    self["config"].list = self.list
                self._apply_config_list_layout()
                _tw_log("[TheweatherSetting] createSetup successful")
            except Exception as e:
                _tw_log("[TheweatherSetting] createSetup error: " + str(e))
                print("[TheWeatherSetting] createSetup error: " + str(e))

        def _apply_background_choices(self):
            try:
                c = config.plugins.TheWeatherIet5
                current_value = getattr(c.background, "value", "1")
                bg_choices = _background_choices()
                available_values = [choice[0] for choice in list(bg_choices or [])]
                normalized_value = _ensure_text(current_value).strip()
                if normalized_value not in available_values:
                    normalized_value = available_values[0] if available_values else "1"
                try:
                    c.background.setChoices(bg_choices, default=normalized_value)
                except Exception:
                    try:
                        c.background.choices = bg_choices
                    except Exception:
                        pass
                c.background.value = normalized_value
                self._background_choice_signature = tuple(choice[0] for choice in list(bg_choices or []))
            except Exception as e:
                print("[TheWeatherSetting] _apply_background_choices error: " + str(e))

        def _refresh_background_choices_for_runtime(self):
            if not _should_refresh_background_choices():
                return
            try:
                c = config.plugins.TheWeatherIet5
                bg_choices = _background_choices()
                latest_signature = tuple(choice[0] for choice in list(bg_choices or []))
                current_value = _ensure_text(getattr(c.background, "value", "1")).strip()
                if latest_signature == getattr(self, "_background_choice_signature", ()) and current_value in latest_signature:
                    return
                self._apply_background_choices()
                self.createSetup()
            except Exception as e:
                print("[TheWeatherSetting] _refresh_background_choices_for_runtime error: " + str(e))

        def _cycle_background(self, step):
            try:
                c = config.plugins.TheWeatherIet5
                current = self["config"].getCurrent()
                if not current or current[1] is not c.background:
                    return False

                available_values = [choice[0] for choice in _background_choices()]
                current_value = str(c.background.value)
                try:
                    idx = available_values.index(current_value)
                except (ValueError, IndexError):
                    idx = 0

                new_idx = (idx + step) % len(available_values)
                c.background.value = available_values[new_idx]
                self.createSetup()
                return True
            except Exception:
                pass
            return False

        def keyLeft(self):
            if not self._cycle_background(-1):
                _Base.keyLeft(self)

        def keyRight(self):
            if not self._cycle_background(1):
                _Base.keyRight(self)

        def _save_all_config(self):
            selected_loc = _normalize_location_input(getattr(getattr(self, "city_selection", None), "value", ""))
            try:
                for x in self["config"].list:
                    if len(x) > 1 and hasattr(x[1], "save"):
                        x[1].save()
            except Exception:
                pass
            if selected_loc:
                try:
                    _sync_active_location(selected_loc, add_to_favorites=True)
                except Exception:
                    pass
                try:
                    _tw_set_cfg("weatherlocation", selected_loc)
                except Exception:
                    pass
            try:
                _sync_active_background(getattr(config.plugins.TheWeatherIet5.background, "value", "1"))
            except Exception:
                pass
            try:
                _write_saved_iconset(config.plugins.TheWeatherIet5.iconset.value)
            except Exception:
                pass
            try:
                _persist_runtime_settings()
            except Exception:
                pass
            return selected_loc

        def keySave(self):
            dreambox_direct_refresh = False
            try:
                from . import isDreambox as _pkg_is_dreambox
                from .plugin_utils import RUNTIME_PROFILE, _is_dreambox_image, _is_vti_image, _is_openatv_image, _is_open_source_image
                # Image family must take precedence here: OpenATV/open-source/VTI
                # should follow the restart path even when running on Dreambox
                # hardware. DreamOS keeps the direct in-plugin refresh path.
                runtime_box_model = _ensure_text(RUNTIME_PROFILE.get("box_model", "")).lower()
                runtime_image_distro = _ensure_text(RUNTIME_PROFILE.get("image_distro", "")).lower()
                restart_sensitive_image = bool(_is_vti_image() or _is_openatv_image() or _is_open_source_image())
                dreambox_hints = (
                    _pkg_is_dreambox or
                    _is_dreambox_image() or
                    runtime_image_distro == "dreamos" or
                    runtime_box_model.startswith("dm") or
                    ("dream" in runtime_box_model)
                )
                dreambox_direct_refresh = bool(dreambox_hints and not restart_sensitive_image)
                requires_restart = bool(restart_sensitive_image)
            except Exception:
                requires_restart = False

            selected_loc = self._save_all_config()
            try:
                auto_update_value = _ensure_text(getattr(config.plugins.TheWeatherIet5.automatic_update, "value", "0")).strip().lower()
                if auto_update_value in ("0", "false", "no", "off", ""):
                    _clear_session_update_timers(self.session)
                    _tw_log("[TheweatherSetting] Deferred background timers cleared because automatic update is disabled")
            except Exception:
                pass

            # Dreambox must keep the old direct background-change behavior without
            # forcing a plugin restart. Restart remains limited to OpenATV and
            # open-source images only.
            try:
                new_background = config.plugins.TheWeatherIet5.background.value
            except Exception:
                new_background = ""
            background_changed = (getattr(self, "initial_background", "") != new_background)
            try:
                new_weather_service = _ensure_text(config.plugins.TheWeatherIet5.weatherservice.value).strip().lower()
            except Exception:
                new_weather_service = DEFAULT_WEATHER_SERVICE
            try:
                new_iconset = _ensure_text(config.plugins.TheWeatherIet5.iconset.value).strip()
            except Exception:
                new_iconset = _ICONSET_DEFAULT
            try:
                active_location = _normalize_location_input(selected_loc or config.plugins.TheWeatherIet5.weatherlocation.value)
            except Exception:
                active_location = _normalize_location_input(selected_loc)
            provider_changed = (getattr(self, "initial_weatherservice", DEFAULT_WEATHER_SERVICE) != new_weather_service)
            iconset_changed = (getattr(self, "initial_iconset", _ICONSET_DEFAULT) != new_iconset)
            location_changed = (getattr(self, "initial_location", "") != active_location)
            # Detect temperature unit (C/F) and wind speed unit changes.
            # These are display-only units: the raw data in cache stays as Celsius/km/h,
            # and _tw_temp_suffix() / _tw_convert_temp() convert at render time.
            # A reload_weather_screen signal refreshes all visible labels via updateFrameselect()
            # without discarding the cache or restarting the plugin.
            try:
                new_tempUnit = _ensure_text(config.plugins.TheWeatherIet5.tempUnit.value).strip()
            except Exception:
                new_tempUnit = getattr(self, "initial_tempUnit", "Celsius")
            try:
                new_windspeedUnit = _ensure_text(config.plugins.TheWeatherIet5.windspeedMetricUnit.value).strip()
            except Exception:
                new_windspeedUnit = getattr(self, "initial_windspeedUnit", "km/h")
            tempunit_changed = (getattr(self, "initial_tempUnit", "Celsius") != new_tempUnit)
            windspeedunit_changed = (getattr(self, "initial_windspeedUnit", "km/h") != new_windspeedUnit)
            requires_screen_reopen = bool(
                provider_changed or iconset_changed or location_changed or
                tempunit_changed or windspeedunit_changed
            )

            if requires_restart and background_changed:
                _tw_log("[TheweatherSetting] Background change detected on a restart-sensitive image, signaling restart")
                self._close_view("RESTART_PLUGIN")
                return
            if dreambox_direct_refresh and background_changed:
                _tw_log("[TheweatherSetting] Background change detected on Dreambox, requesting in-plugin refresh")
                try:
                    self.session._tw_settings_refresh_city = selected_loc or _normalize_location_input(_tw_cfg("weatherlocation", ""))
                except Exception:
                    pass
                self._close_view("action:refresh_background")
                return

            if requires_screen_reopen:
                _tw_log("[TheweatherSetting] Weather provider/iconset/location changed, requesting in-plugin weather screen reopen")
                self._close_view(("reload_weather_screen", active_location))
                return

            if selected_loc:
                self._close_view(selected_loc)
                return
            self._close_view(True)

        def keyCancel(self):
            try:
                for x in self["config"].list:
                    if len(x) > 1 and hasattr(x[1], "cancel"):
                        x[1].cancel()
            except Exception:
                pass
            self._close_view()

        def keyGreen(self):
            self.keySave()

        def keyRed(self):
            try:
                self._open_select_location_flow()
            except Exception as e:
                print("[TheWeatherSetting] keyRed/select location error: " + str(e))
                try:
                    self.session.open(MessageBox, _("City selection screen could not be opened."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass

        def keyYellow(self):
            try:
                _open_virtual_keyboard(self.session, self._on_add_city_text, _("Enter cityname e.g. london or cairo"), "")
            except Exception as e:
                print("[TheWeatherSetting] keyYellow/add city error: " + str(e))
                try:
                    self.session.open(MessageBox, _("Keyboard screen is not available on this image."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass

        def keyBlue(self):
            try:
                from .plugin_screens import localcityscreen
                self.session.openWithCallback(self._on_manage_favorites_closed, localcityscreen, return_selection=True)
            except Exception as e:
                print("[TheWeatherSetting] keyBlue/manage favorites error: " + str(e))
                try:
                    self.session.open(MessageBox, _("Favorites screen could not be opened."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass

        def _on_location_picked(self, selected_location=None):
            selected_location = _normalize_location_input(selected_location)
            if not selected_location:
                return
            try:
                _sync_active_location(selected_location, add_to_favorites=True)
            except Exception:
                pass
            try:
                _tw_set_cfg("weatherlocation", selected_location)
            except Exception:
                pass
            self.createSetup()

        def _on_manage_favorites_closed(self, selected_location=None, *args, **kwargs):
            selected_location = _normalize_location_input(selected_location)
            if selected_location:
                try:
                    _sync_active_location(selected_location, add_to_favorites=True)
                except Exception:
                    pass
                try:
                    _tw_set_cfg("weatherlocation", selected_location)
                except Exception:
                    pass
            try:
                self.createSetup()
            except Exception:
                pass

        def _open_select_location_flow(self):
            try:
                current_value = ""
                try:
                    current_value = getattr(config.plugins.TheWeatherIet5.weatherlocation, "value", "")
                except Exception:
                    current_value = ""
                searchterm = _display_city_only(current_value)
                saved_locations = list(_plugin_saved_locations())
                if (not searchterm or searchterm == _("Not set")) and saved_locations:
                    searchterm = _display_city_only(saved_locations[0])
                searchterm = _ensure_text(searchterm).strip()
                if not searchterm or searchterm == _("Not set"):
                    try:
                        self.session.open(MessageBox, _("No saved city available to search."), MESSAGEBOX_TYPE_INFO)
                    except Exception:
                        pass
                    return
                self._on_select_location_text(searchterm)
            except Exception as e:
                print("[TheWeatherSetting] open select location flow error: " + str(e))
                try:
                    self.session.open(MessageBox, _("City selection screen could not be opened."), MESSAGEBOX_TYPE_INFO)
                except Exception:
                    pass

        def _on_select_location_text(self, searchterm=None):
            searchterm = _ensure_text(searchterm).strip()
            if not searchterm:
                return
            try:
                from .WeatherProviders import search_locations
                from .plugin_screens import locationsearchresultscreen
                results = search_locations(searchterm) or []
                if not results:
                    try:
                        self.session.open(MessageBox, _("No matching cities found. Check spelling."), MESSAGEBOX_TYPE_INFO)
                    except Exception:
                        pass
                    return
                self.session.openWithCallback(self._on_location_selected, locationsearchresultscreen, searchterm, results)
            except Exception as e:
                print("[TheWeatherSetting] _on_select_location_text error: " + str(e))

        def _on_add_city_text(self, searchterm=None):
            searchterm = _ensure_text(searchterm).strip()
            if not searchterm:
                return
            try:
                from .WeatherProviders import search_locations
                from .plugin_screens import locationsearchresultscreen
                results = search_locations(searchterm) or []
                if not results:
                    try:
                        self.session.open(MessageBox, _("No matching cities found. Check spelling."), MESSAGEBOX_TYPE_INFO)
                    except Exception:
                        pass
                    return
                self.session.openWithCallback(self._on_location_selected, locationsearchresultscreen, searchterm, results)
            except Exception as e:
                print("[TheWeatherSetting] _on_add_city_text error: " + str(e))

        def _on_location_selected(self, selected_location=None):
            selected_location = _normalize_location_input(selected_location)
            if not selected_location:
                return
            try:
                _append_unique_location(selected_location)
            except Exception:
                pass
            try:
                _sync_active_location(selected_location, add_to_favorites=True)
            except Exception:
                pass
            try:
                _write_non_empty_lines(LOCATIONS_FILE, _plugin_saved_locations())
            except Exception:
                pass
            try:
                _tw_set_cfg("weatherlocation", selected_location)
            except Exception:
                pass
            self.createSetup()
            try:
                self.session.open(MessageBox, _("City added successfully."), MESSAGEBOX_TYPE_INFO)
            except Exception:
                pass

else:
    from Components.ActionMap import ActionMap
    from Components.Label import Label
    from Screens.Screen import Screen

    class TheweatherSetting(Screen):
        def __init__(self, session):
            metrics = _settings_window_metrics()
            self.skin = """
<screen name="TheweatherSetting" position="center,center" size="{screen_w},{screen_h}"
        backgroundColor="#232323" flags="wfNoBorder">
    <eLabel position="0,0" size="{screen_w},{screen_h}" backgroundColor="#232323" zPosition="0"/>
    <eLabel position="0,0" size="{screen_w},48" backgroundColor="#454b50" zPosition="1"/>
    <eLabel text="TheWeatherIet5 - Settings" position="20,8" size="{title_w},32"
            font="Regular;22" foregroundColor="#d48c1f" backgroundColor="#454b50"
            transparent="1" valign="center" zPosition="2"/>
    <eLabel position="18,82" size="{frame_w},2" backgroundColor="#9d6616" zPosition="2"/>
    <eLabel position="18,84" size="{frame_w},{frame_h}" backgroundColor="#000000" zPosition="1"/>
    <widget name="msg1" position="20,118" size="{msg_w},40" font="Regular;24"
            foregroundColor="#ffffff" transparent="1" valign="center" halign="center"/>
    <widget name="msg2" position="20,178" size="{msg_w},120" font="Regular;20"
            foregroundColor="#aaaaaa" transparent="1" valign="center" halign="center"/>
    <widget name="key_red" position="{button_x},{button_y}" size="{button_w},42" font="Regular;22"
            foregroundColor="#ffffff" backgroundColor="#cc0000"
            transparent="0" valign="center" halign="center"/>
</screen>""".format(
                screen_w=metrics["screen_w"],
                screen_h=metrics["screen_h"],
                title_w=metrics["screen_w"] - 40,
                frame_w=metrics["screen_w"] - 36,
                frame_h=metrics["screen_h"] - 190,
                msg_w=metrics["screen_w"] - 40,
                button_x=int((metrics["screen_w"] - 320) / 2),
                button_y=metrics["screen_h"] - 72,
                button_w=320,
            )
            Screen.__init__(self, session)
            self["msg1"] = Label("Settings initialization failed")
            self["msg2"] = Label(_OA_INIT_ERROR or "Check TheWeatherIet5 imports on the receiver")
            self["key_red"] = Label("Close")
            self["actions"] = ActionMap(
                ["ColorActions", "OkCancelActions"],
                {"red": self.close, "cancel": self.close, "ok": self.close},
                -1
            )
